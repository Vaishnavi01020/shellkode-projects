"""
service.py — Business logic handlers for /ingest and /query endpoints.

Imports all classes, constants, and session from retriver.py.
Called by app.py routes only.
"""

import os
import json
import shutil
import tempfile
import logging
import boto3
from datetime import datetime
from typing import List, AsyncGenerator

from fastapi import HTTPException
from fastapi.responses import JSONResponse
from langchain_aws import BedrockEmbeddings

from retriver import (
    # constants
    REGION, S3_BUCKET, OPENSEARCH_ENDPOINT, OPENSEARCH_INDEX,
    S3_VECTOR_BUCKET_ARN, S3_VECTOR_INDEX_ARN,
    PG_HOST, PG_PORT, PG_DATABASE, PG_USER, PG_PASSWORD,
    S3_FOLDER_MAP,
    # session
    _session, _save_session,
    # enums
    VectorDB, LLMModel,
    # classes
    LangChainDocumentProcessor, VectorStoreManager, VectorRetriever,
)
from prompt import SYSTEM_PROMPT

logger = logging.getLogger("rag.service")


# ═══════════════════════════════════════════════════════════════════════════
# INGEST HANDLER
# ═══════════════════════════════════════════════════════════════════════════

async def handle_ingest(vector_db: VectorDB, s3_folder_name: str, files: List) -> JSONResponse:
    import time

    db = vector_db.value

    if not s3_folder_name or not s3_folder_name.strip():
        raise HTTPException(
            422,
            "s3_folder_name is required. "
            "Please provide a subfolder name (e.g. 'project-docs')."
        )

    s3_folder  = f"{S3_FOLDER_MAP[db]}/{s3_folder_name.strip().strip('/')}"
    tmp_dir    = tempfile.mkdtemp()
    file_names = [f.filename for f in files]
    logger.info("=" * 60)
    logger.info(f"POST /ingest | vector_db={db} | s3_folder={s3_folder} | files={file_names}")
    t_start = time.time()

    try:
        file_paths = []
        for upload in files:
            dest = os.path.join(tmp_dir, upload.filename)
            with open(dest, "wb") as f:
                shutil.copyfileobj(upload.file, f)
            size_kb = os.path.getsize(dest) / 1024
            logger.info(f"  Received: {upload.filename} ({size_kb:.1f} KB)")
            file_paths.append(dest)

        processor = LangChainDocumentProcessor(
            bucket_name=S3_BUCKET, s3_folder=s3_folder, region_name=REGION)
        results = processor.process_files(file_paths)

        if not results["all_chunks"]:
            errors = results.get("extract_errors", [])
            logger.error(f"No chunks created. Errors: {errors}")
            raise HTTPException(422, "No chunks created. " +
                                (" Errors: " + " | ".join(errors) if errors else ""))

        manager = VectorStoreManager(
            region_name=          REGION,
            opensearch_endpoint=  OPENSEARCH_ENDPOINT if db == "opensearch" else None,
            opensearch_index=     OPENSEARCH_INDEX,
            pg_host=              PG_HOST        if db == "pgvector" else None,
            pg_port=              PG_PORT,
            pg_database=          PG_DATABASE    if db == "pgvector" else None,
            pg_user=              PG_USER        if db == "pgvector" else None,
            pg_password=          PG_PASSWORD    if db == "pgvector" else None,
            s3_vector_bucket_arn= S3_VECTOR_BUCKET_ARN if db == "s3vectors" else None,
            s3_vector_index_arn=  S3_VECTOR_INDEX_ARN  if db == "s3vectors" else None,
        )
        vector_data = manager.create_embeddings(results["all_chunks"])

        if db == "opensearch":
            store_result = manager.store_in_opensearch(vector_data)
        elif db == "pgvector":
            store_result = manager.store_in_pgvector(vector_data)
        else:
            store_result = manager.store_in_s3_vector_bucket(vector_data)

        _session["vector_db"]        = db
        _session["opensearch_index"] = OPENSEARCH_INDEX
        _save_session(_session)

        elapsed = time.time() - t_start
        logger.info(
            f"POST /ingest DONE | files={len(results['file_details'])} | "
            f"chunks={len(results['all_chunks'])} | vectors={len(vector_data)} | "
            f"total={elapsed:.1f}s"
        )
        logger.info("=" * 60)

        return JSONResponse({
            "status":          "success",
            "vector_db":       db,
            "append_mode":     True,
            "s3_folder":       f"s3://{S3_BUCKET}/{s3_folder}/",
            "files_processed": len(results["file_details"]),
            "file_details":    results["file_details"],
            "chunks_created":  len(results["all_chunks"]),
            "vectors_stored":  len(vector_data),
            "s3_files":        results["uploaded_files"],
            "store_result":    store_result,
            "extract_errors":  results.get("extract_errors", []),
        })
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"POST /ingest FAILED: {e}")
        raise HTTPException(500, str(e))
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


# ═══════════════════════════════════════════════════════════════════════════
# QUERY HANDLER
# ═══════════════════════════════════════════════════════════════════════════

async def handle_query(query: str, llm_model: LLMModel) -> AsyncGenerator:
    import time

    top_k = 5
    db    = _session.get("vector_db")
    logger.info("=" * 60)
    logger.info(f"POST /query (streaming) | vector_db={db} | top_k={top_k} | model={llm_model.value}")
    logger.info(f"  Query: {query[:120]}{'...' if len(query) > 120 else ''}")

    # ── No session → Normal chatbot ────────────────────────────────────────
    if not db:
        logger.info("  No active session — falling back to normal chatbot mode")

        async def normal_chat_stream() -> AsyncGenerator[str, None]:
            t0     = time.time()
            client = boto3.client("bedrock-runtime", region_name=REGION)

            yield f"data: {json.dumps({'event': 'metadata', 'query': query, 'vector_store': None, 'model': llm_model.value, 'mode': 'normal_chat', 'timestamp': datetime.now().isoformat()})}\n\n"

            try:
                response = client.converse_stream(
                    modelId=llm_model.value,
                    system=[{"text": SYSTEM_PROMPT}],
                    messages=[{"role": "user", "content": [{"text": query}]}],
                    inferenceConfig={"temperature": 0.1, "topP": 0.9, "maxTokens": 300},
                )

                full_answer = []
                for event in response["stream"]:
                    if "contentBlockDelta" in event:
                        delta = event["contentBlockDelta"].get("delta", {})
                        token = delta.get("text", "")
                        if token:
                            full_answer.append(token)
                            yield f"data: {json.dumps({'event': 'chunk', 'text': token})}\n\n"

                    elif "messageStop" in event:
                        stop_reason = event["messageStop"].get("stopReason", "end_turn")
                        elapsed     = time.time() - t0
                        logger.info(f"  ✓ Normal chat complete | stop={stop_reason} | time={elapsed:.1f}s")
                        yield f"data: {json.dumps({'event': 'done', 'stop_reason': stop_reason, 'elapsed_s': round(elapsed, 2)})}\n\n"

            except Exception as e:
                logger.exception(f"Normal chat streaming error: {e}")
                yield f"data: {json.dumps({'event': 'error', 'detail': str(e)})}\n\n"

            logger.info("=" * 60)

        return normal_chat_stream()

    # ── 1. Embed query ─────────────────────────────────────────────────────
    try:
        emb_model       = BedrockEmbeddings(model_id="amazon.titan-embed-text-v2:0", region_name=REGION)
        query_embedding = emb_model.embed_query(query)
        logger.info(f"  ✓ Query embedded (dim={len(query_embedding)})")
    except Exception as e:
        logger.exception(f"Embedding failed: {e}")
        raise HTTPException(500, f"Embedding failed: {e}")

    # ── 2. Retrieve docs ───────────────────────────────────────────────────
    try:
        opensearch_index = _session.get("opensearch_index", OPENSEARCH_INDEX)
        retriever = VectorRetriever(
            region_name=          REGION,
            opensearch_endpoint=  OPENSEARCH_ENDPOINT if db == "opensearch" else None,
            opensearch_index=     opensearch_index,
            pg_host=              PG_HOST        if db == "pgvector" else None,
            pg_port=              PG_PORT,
            pg_database=          PG_DATABASE    if db == "pgvector" else None,
            pg_user=              PG_USER        if db == "pgvector" else None,
            pg_password=          PG_PASSWORD    if db == "pgvector" else None,
            s3_vector_bucket_arn= S3_VECTOR_BUCKET_ARN if db == "s3vectors" else None,
            s3_vector_index_arn=  S3_VECTOR_INDEX_ARN  if db == "s3vectors" else None,
        )

        if db == "opensearch":
            docs = retriever.search_opensearch(query_embedding, top_k)
        elif db == "pgvector":
            docs = retriever.search_pgvector(query_embedding, top_k)
        else:
            docs = retriever.search_s3_vector_bucket(query_embedding, top_k)

        logger.info(f"  ✓ Retrieved {len(docs)} doc(s) from {db}")
    except Exception as e:
        logger.exception(f"Retrieval failed: {e}")
        raise HTTPException(500, f"Retrieval failed: {e}")

    # ── 3. Build prompt ────────────────────────────────────────────────────
    context = "\n\n".join(
        f"Document {i+1} (from {d.get('metadata', {}).get('file_name', 'Unknown')}):\n{d.get('text', '')}"
        for i, d in enumerate(docs)
    )
    user_message = f"Retrieved Documents:\n{context}\n\nUser Question: {query}"

    # ── 4. Stream via Bedrock converse_stream API ──────────────────────────
    async def event_stream() -> AsyncGenerator[str, None]:
        t0     = time.time()
        client = boto3.client("bedrock-runtime", region_name=REGION)

        yield f"data: {json.dumps({'event': 'metadata', 'query': query, 'vector_store': db, 'model': llm_model.value, 'top_k': top_k, 'timestamp': datetime.now().isoformat()})}\n\n"

        try:
            response = client.converse_stream(
                modelId=llm_model.value,
                system=[{"text": SYSTEM_PROMPT}],
                messages=[{"role": "user", "content": [{"text": user_message}]}],
                inferenceConfig={"temperature": 0.1, "topP": 0.9, "maxTokens": 300},
            )

            full_answer = []
            for event in response["stream"]:
                if "contentBlockDelta" in event:
                    delta = event["contentBlockDelta"].get("delta", {})
                    token = delta.get("text", "")
                    if token:
                        full_answer.append(token)
                        yield f"data: {json.dumps({'event': 'chunk', 'text': token})}\n\n"

                elif "messageStop" in event:
                    stop_reason = event["messageStop"].get("stopReason", "end_turn")
                    elapsed     = time.time() - t0
                    logger.info(f"  ✓ Stream complete | stop={stop_reason} | time={elapsed:.1f}s")
                    yield f"data: {json.dumps({'event': 'done', 'stop_reason': stop_reason, 'elapsed_s': round(elapsed, 2)})}\n\n"

        except Exception as e:
            logger.exception(f"Streaming LLM error: {e}")
            yield f"data: {json.dumps({'event': 'error', 'detail': str(e)})}\n\n"

        logger.info("=" * 60)

    return event_stream()