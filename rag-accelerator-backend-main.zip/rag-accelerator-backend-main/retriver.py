"""
FastAPI RAG Pipeline — LangChain Loaders Only
main.py  → classes, constants, session, enums (no FastAPI routes)
app.py   → FastAPI app and all API endpoints (imports from main.py)
.env     → all configuration values
Supported file types (pip only):
  PDF, DOCX, XLSX, CSV, PPTX, HTML, JSON, JSONL, XML,
  RTF, ODT, EPUB, EML, MSG, TXT, MD, Images (OCR), and all code files
"""

import os
import json
import time
import uuid
import logging
import numpy as np
from typing import List, Dict
from pathlib import Path
from datetime import datetime
from enum import Enum

import boto3
import nltk
from dotenv import load_dotenv

# ── Load .env ──────────────────────────────────────────────────────────────
load_dotenv()


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(),
    ],
)
for _noisy in ("urllib3", "botocore", "boto3", "opensearch", "httpx", "httpcore"):
    logging.getLogger(_noisy).setLevel(logging.WARNING)

logger = logging.getLogger("rag")
logger.info("=" * 70)
logger.info("RAG Pipeline starting up")
logger.info("=" * 70)

# ── pytesseract Windows path ───────────────────────────────────────────────
try:
    import pytesseract
    pytesseract.pytesseract.    tesseract_cmd = os.getenv(
        "TESSERACT_CMD",
        r"C:\Users\DS\Downloads\tesseract-ocr-w64-setup-5.5.0.20241111.exe"
    )
    logger.info("✓ pytesseract configured")
except ImportError:
    logger.info("  pytesseract not installed (optional, EasyOCR preferred)")

# ── NLTK ───────────────────────────────────────────────────────────────────
for _pkg in ["averaged_perceptron_tagger_eng", "averaged_perceptron_tagger",
             "punkt", "punkt_tab", "stopwords"]:
    try:
        nltk.download(_pkg, quiet=True)
    except Exception:
        pass

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

# ── Optional library flags ─────────────────────────────────────────────────
try:
    from langchain_unstructured import UnstructuredLoader
    UNSTRUCTURED_NEW = True
    UNSTRUCTURED_AVAILABLE = True
    logger.info("✓ langchain-unstructured (new) available")
except ImportError:
    UNSTRUCTURED_NEW = False
    try:
        from langchain_community.document_loaders import UnstructuredFileLoader
        UNSTRUCTURED_AVAILABLE = True
        logger.info("✓ UnstructuredFileLoader (community) available")
    except ImportError:
        UNSTRUCTURED_AVAILABLE = False
        logger.warning("✗ Unstructured not available")

try:
    from opensearchpy import OpenSearch, RequestsHttpConnection
    from requests_aws4auth import AWS4Auth
    OPENSEARCH_AVAILABLE = True
    logger.info("✓ OpenSearch available")
except ImportError:
    OPENSEARCH_AVAILABLE = False
    logger.warning("✗ OpenSearch not available")

try:
    import psycopg2
    from pgvector.psycopg2 import register_vector
    PGVECTOR_AVAILABLE = True
    logger.info("✓ pgvector available")
except ImportError:
    PGVECTOR_AVAILABLE = False
    logger.warning("✗ pgvector not available")

try:
    from langchain_aws import BedrockEmbeddings, ChatBedrock
    BEDROCK_AVAILABLE = True
    logger.info("✓ langchain-aws (Bedrock) available")
except ImportError:
    BEDROCK_AVAILABLE = False
    logger.warning("✗ langchain-aws not available")

REGION               = os.environ["REGION"]
S3_BUCKET            = os.environ["S3_BUCKET"]
OPENSEARCH_ENDPOINT  = os.environ["OPENSEARCH_ENDPOINT"]
OPENSEARCH_INDEX     = os.environ["OPENSEARCH_INDEX"]
S3_VECTOR_BUCKET_ARN = os.environ["S3_VECTOR_BUCKET_ARN"]
S3_VECTOR_INDEX_ARN  = os.environ["S3_VECTOR_INDEX_ARN"]
PG_HOST              = os.environ["PG_HOST"]
PG_PORT              = int(os.environ["PG_PORT"])
PG_DATABASE          = os.environ["PG_DATABASE"]
PG_USER              = os.environ["PG_USER"]
PG_PASSWORD          = os.environ["PG_PASSWORD"]
LLM_MODEL            = os.environ["LLM_MODEL"]
TESSERACT_CMD        = os.environ["TESSERACT_CMD"]
S3_FOLDER_MAP = {
    "opensearch": "opensearch",
    "pgvector":   "pg-vector",
    "s3vectors":  "S3-bucket",
}


# ── Session ────────────────────────────────────────────────────────────────
_SESSION_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rag_session.json")

def _load_session():
    try:
        with open(_SESSION_FILE) as f:
            return json.load(f)
    except Exception:
        return {"vector_db": None, "opensearch_index": OPENSEARCH_INDEX}


def _save_session(data):
    with open(_SESSION_FILE, "w") as f:
        json.dump(data, f)

_session = _load_session()
if _session.get("vector_db"):
    logger.info(f"Restored session → vector_db={_session['vector_db']}")

# ── Enums ──────────────────────────────────────────────────────────────────
class VectorDB(str, Enum):
    opensearch = "opensearch"
    pgvector   = "pgvector"
    s3vectors  = "s3vectors"

class LLMModel(str, Enum):
    claude_37_sonnet = "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
    claude_35_sonnet = "us.anthropic.claude-3-5-sonnet-20241022-v2:0"
    claude_35_haiku  = "us.anthropic.claude-3-5-haiku-20241022-v1:0"
    claude_3_sonnet  = "us.anthropic.claude-3-sonnet-20240229-v1:0"
    claude_3_haiku   = "us.anthropic.claude-3-haiku-20240307-v1:0"


# ═══════════════════════════════════════════════════════════════════════════
# UNIVERSAL LANGCHAIN FILE LOADER
# ═══════════════════════════════════════════════════════════════════════════

class UniversalFileLoader:
    """
    Routes any file to the correct LangChain loader.
    Fallback chain:
      1. LangChain native (by extension)
      2. OCR for images → EasyOCR → pytesseract (no Textract)
      3. Unstructured (if installed)
      4. Plain text (last resort)
    """

    IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tiff", ".tif", ".bmp", ".webp"}
    _log = logging.getLogger("rag.loader")

    def load(self, file_path: str) -> List[Document]:
        fp, ext, name = str(file_path), Path(file_path).suffix.lower(), Path(file_path).name
        self._log.info(f"Loading: {name}  (ext={ext})")
        self._log.info(f"  IMAGE_EXTENSIONS check: {ext} in {self.IMAGE_EXTENSIONS} = {ext in self.IMAGE_EXTENSIONS}")

        # Images → OCR pipeline (no Textract)
        if ext in self.IMAGE_EXTENSIONS:
            self._log.info(f"  → Image detected, running OCR on {name}")
            docs = self._ocr_image(fp)
            if docs:
                self._log.info(f"  ✓ OCR success: {len(docs)} doc(s) from {name}")
                return self._tag(docs, name, ext, "ocr")
            raise RuntimeError(
                f"OCR could not extract text from: {name}. "
                f"Install EasyOCR (pip install easyocr) or pytesseract."
            )

        # All other files → LangChain native first
        docs = self._langchain_native(fp, ext)
        if docs:
            self._log.info(f"  ✓ LangChain native: {len(docs)} doc(s) from {name}")
            return self._tag(docs, name, ext, "langchain")

        if UNSTRUCTURED_AVAILABLE:
            self._log.info(f"  → Trying Unstructured for {name}")
            docs = self._unstructured(fp)
            if docs:
                self._log.info(f"  ✓ Unstructured: {len(docs)} doc(s) from {name}")
                return self._tag(docs, name, ext, "unstructured")

        self._log.info(f"  → Trying plain text fallback for {name}")
        docs = self._plaintext(fp)
        if docs:
            self._log.info(f"  ✓ Plain text fallback: {len(docs)} doc(s) from {name}")
            return self._tag(docs, name, ext, "plaintext")

        raise RuntimeError(f"Cannot extract text from: {name}")

    def _ocr_image(self, fp: str) -> List[Document]:
        """OCR for image files. EasyOCR first, pytesseract fallback."""

        # ── EasyOCR ────────────────────────────────────────────────────────
        try:
            import easyocr
            self._log.info("  → EasyOCR: loading model (first run downloads ~100MB)...")
            t0      = time.time()
            reader  = easyocr.Reader(["en"], gpu=False, verbose=False)
            results = reader.readtext(fp, detail=0, paragraph=True)
            text    = "\n".join(r for r in results if r.strip())
            if text.strip():
                self._log.info(
                    f"  ✓ EasyOCR: {len(results)} block(s) in {time.time()-t0:.1f}s"
                )
                return [Document(page_content=text, metadata={"source": "easyocr"})]
            else:
                self._log.warning("  ✗ EasyOCR: no text found in image")
        except ImportError:
            self._log.info("  → EasyOCR not installed, trying pytesseract...")
        except Exception as e:
            self._log.warning(f"  ✗ EasyOCR error: {e}")

        # ── pytesseract (Windows path set at startup) ──────────────────────
        try:
            import pytesseract
            from PIL import Image
            self._log.info("  → pytesseract: running OCR...")
            t0   = time.time()
            img  = Image.open(fp)
            text = pytesseract.image_to_string(img)
            if text.strip():
                self._log.info(
                    f"  ✓ pytesseract: text extracted in {time.time()-t0:.1f}s"
                )
                return [Document(page_content=text, metadata={"source": "pytesseract"})]
            else:
                self._log.warning("  ✗ pytesseract: no text found in image")
        except ImportError:
            self._log.warning("  ✗ pytesseract not installed (pip install pytesseract)")
        except Exception as e:
            self._log.warning(f"  ✗ pytesseract error: {e}")

        return []

    def _langchain_native(self, fp: str, ext: str) -> List[Document]:
        try:
            # PDF
            if ext == ".pdf":
                try:
                    from langchain_community.document_loaders import PyPDFLoader
                    docs = PyPDFLoader(fp).load()
                    if docs and any(d.page_content.strip() for d in docs):
                        return docs
                except Exception:
                    pass
                try:
                    import pdfplumber
                    pages = []
                    with pdfplumber.open(fp) as pdf:
                        for i, page in enumerate(pdf.pages):
                            text = page.extract_text() or ""
                            tbl  = "\n".join(
                                " | ".join(str(c) if c else "" for c in row)
                                for table in page.extract_tables() for row in table)
                            content = (text + "\n" + tbl).strip()
                            if content:
                                pages.append(Document(page_content=content,
                                                      metadata={"page": i+1}))
                    return pages
                except Exception:
                    pass
                return []

            # DOCX / DOC
            elif ext in (".docx", ".doc"):
                try:
                    from langchain_community.document_loaders import Docx2txtLoader
                    docs = Docx2txtLoader(fp).load()
                    if docs and any(d.page_content.strip() for d in docs):
                        return docs
                except Exception:
                    pass
                try:
                    import docx as python_docx
                    doc     = python_docx.Document(fp)
                    paras   = [p.text for p in doc.paragraphs if p.text.strip()]
                    tables  = [" | ".join(c.text for c in row.cells)
                               for table in doc.tables for row in table.rows]
                    content = "\n".join(paras + tables)
                    if content.strip():
                        return [Document(page_content=content)]
                except Exception:
                    pass
                return []

            # XLSX / XLS
            elif ext in (".xlsx", ".xls"):
                try:
                    import pandas as pd
                    xl   = pd.ExcelFile(fp)
                    docs = []
                    for sheet in xl.sheet_names:
                        df   = xl.parse(sheet)
                        text = f"Sheet: {sheet}\n{df.to_string(index=False)}"
                        docs.append(Document(page_content=text, metadata={"sheet": sheet}))
                    return docs
                except Exception:
                    pass
                return []

            # CSV
            elif ext == ".csv":
                try:
                    from langchain_community.document_loaders import CSVLoader
                    docs = CSVLoader(fp).load()
                    if docs:
                        return docs
                except Exception:
                    pass
                try:
                    import pandas as pd
                    return [Document(page_content=pd.read_csv(fp).to_string(index=False))]
                except Exception:
                    pass
                return []

            # PPTX / PPT
            elif ext in (".pptx", ".ppt"):
                try:
                    from pptx import Presentation
                    prs    = Presentation(fp)
                    slides = []
                    for i, slide in enumerate(prs.slides):
                        texts = [shape.text.strip() for shape in slide.shapes
                                 if hasattr(shape, "text") and shape.text.strip()]
                        if texts:
                            slides.append(Document(page_content="\n".join(texts),
                                                   metadata={"slide": i+1}))
                    return slides
                except Exception:
                    pass
                return []

            # HTML / HTM
            elif ext in (".html", ".htm"):
                try:
                    from langchain_community.document_loaders import BSHTMLLoader
                    docs = BSHTMLLoader(fp).load()
                    if docs and any(d.page_content.strip() for d in docs):
                        return docs
                except Exception:
                    pass
                try:
                    from bs4 import BeautifulSoup
                    with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                        text = BeautifulSoup(f.read(), "html.parser").get_text("\n")
                    if text.strip():
                        return [Document(page_content=text)]
                except Exception:
                    pass
                return []

            # JSON / JSONL
            elif ext in (".json", ".jsonl"):
                try:
                    with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                        if ext == ".jsonl":
                            text = "\n".join(json.dumps(json.loads(l), indent=2)
                                             for l in f if l.strip())
                        else:
                            text = json.dumps(json.load(f), indent=2)
                    if text.strip():
                        return [Document(page_content=text)]
                except Exception:
                    pass
                return []

            # XML
            elif ext == ".xml":
                try:
                    import xml.etree.ElementTree as ET
                    tree = ET.parse(fp)
                    text = "\n".join(e.text for e in tree.iter() if e.text and e.text.strip())
                    if text.strip():
                        return [Document(page_content=text)]
                except Exception:
                    pass
                return []

            # RTF
            elif ext == ".rtf":
                try:
                    from striprtf.striprtf import rtf_to_text
                    with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                        text = rtf_to_text(f.read())
                    if text.strip():
                        return [Document(page_content=text)]
                except Exception:
                    pass
                return []

            # ODT
            elif ext == ".odt":
                try:
                    from odf.opendocument import load as odf_load
                    from odf.text import P
                    doc  = odf_load(fp)
                    text = "\n".join(str(p) for p in doc.getElementsByType(P) if str(p).strip())
                    if text.strip():
                        return [Document(page_content=text)]
                except Exception:
                    pass
                return []

            # EPUB
            elif ext == ".epub":
                try:
                    import ebooklib
                    from ebooklib import epub
                    from bs4 import BeautifulSoup
                    book = epub.read_epub(fp)
                    docs = []
                    for item in book.get_items():
                        if item.get_type() == ebooklib.ITEM_DOCUMENT:
                            text = BeautifulSoup(item.get_content(), "html.parser").get_text()
                            if text.strip():
                                docs.append(Document(page_content=text))
                    return docs
                except Exception:
                    pass
                return []

            # EML
            elif ext == ".eml":
                try:
                    import email
                    with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                        msg = email.message_from_file(f)
                    parts = []
                    for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            payload = part.get_payload(decode=True)
                            if payload:
                                parts.append(payload.decode("utf-8", errors="ignore"))
                    text = "\n".join(parts)
                    if text.strip():
                        return [Document(page_content=text)]
                except Exception:
                    pass
                return []

            # MSG (Outlook)
            elif ext == ".msg":
                try:
                    import extract_msg
                    msg  = extract_msg.Message(fp)
                    text = f"Subject: {msg.subject}\nFrom: {msg.sender}\nBody:\n{msg.body}"
                    if text.strip():
                        return [Document(page_content=text)]
                except Exception:
                    pass
                return []

            # TXT / MD / code
            elif ext in (
                ".txt", ".md", ".log", ".py", ".js", ".ts", ".jsx", ".tsx",
                ".css", ".scss", ".yaml", ".yml", ".ini", ".cfg", ".toml",
                ".sh", ".bash", ".sql", ".r", ".rb", ".php", ".java", ".cpp",
                ".c", ".h", ".go", ".rs", ".swift", ".kt", ".scala", ".ipynb",
            ):
                try:
                    from langchain_community.document_loaders import TextLoader
                    docs = TextLoader(fp, autodetect_encoding=True).load()
                    if docs and any(d.page_content.strip() for d in docs):
                        return docs
                except Exception:
                    pass
                return []
            else:
                return None

        except Exception as e:
            self._log.warning(f"Native loader error: {e}")
        return []

    def _unstructured(self, fp: str) -> List[Document]:
        try:
            loader = (UnstructuredLoader(fp, mode="elements", strategy="fast")
                      if UNSTRUCTURED_NEW
                      else UnstructuredFileLoader(fp, mode="elements", strategy="fast"))
            docs = loader.load()
            if docs and any(d.page_content.strip() for d in docs):
                return docs
        except Exception as e:
            self._log.warning(f"Unstructured error: {e}")
        return []

    def _plaintext(self, fp: str) -> List[Document]:
        try:
            with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
            if text.strip():
                return [Document(page_content=text)]
        except Exception:
            pass
        return []

    def _tag(self, docs, name, ext, loader):
        for d in docs:
            d.metadata.update({"file_name": name, "file_type": ext, "loader_used": loader})
        return docs


# ═══════════════════════════════════════════════════════════════════════════
# DOCUMENT PROCESSOR
# ═══════════════════════════════════════════════════════════════════════════

class LangChainDocumentProcessor:
    _log = logging.getLogger("rag.processor")

    def __init__(self, bucket_name, s3_folder, region_name="us-east-1"):
        self.bucket_name  = bucket_name
        self.s3_folder    = s3_folder.rstrip("/") + "/" if s3_folder else ""
        self.s3_client    = boto3.client("s3", region_name=region_name)
        self.file_loader  = UniversalFileLoader()
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000, chunk_overlap=100,
            length_function=len, separators=["\n\n", "\n", " ", ""],
        )

    def upload_to_s3(self, fp: str) -> str:
        s3_key = f"{self.s3_folder}{Path(fp).name}"
        self._log.info(f"Uploading to S3: s3://{self.bucket_name}/{s3_key}")
        self.s3_client.upload_file(fp, self.bucket_name, s3_key)
        self._log.info(f"  ✓ Upload complete: {Path(fp).name}")
        return f"s3://{self.bucket_name}/{s3_key}"

    def process_files(self, file_paths: List[str]) -> Dict:
        self._log.info(f"Processing {len(file_paths)} file(s)")
        results = {"uploaded_files": [], "all_documents": [], "all_chunks": [],
                   "file_details": [], "extract_errors": []}

        for fp in file_paths:
            try:
                results["uploaded_files"].append(self.upload_to_s3(fp))
            except Exception as e:
                self._log.error(f"S3 upload failed [{Path(fp).name}]: {e}")

        for i, fp in enumerate(file_paths):
            name = Path(fp).name
            try:
                t0          = time.time()
                docs        = self.file_loader.load(fp)
                loader_used = docs[0].metadata.get("loader_used", "unknown") if docs else "none"
                elapsed     = time.time() - t0
                results["all_documents"].extend(docs)
                results["file_details"].append({
                    "file_name": Path(fp).name, "file_type": Path(fp).suffix.lower(),
                    "document_count": len(docs), "loader_used": loader_used,
                    "s3_uri": results["uploaded_files"][i]
                              if i < len(results["uploaded_files"]) else None,
                })
                self._log.info(
                    f"  ✓ {name}: {len(docs)} doc(s) via [{loader_used}] in {elapsed:.1f}s"
                )
            except Exception as e:
                err = f"{name}: {e}"
                self._log.error(f"  ✗ Extraction failed [{name}]: {e}")
                results["extract_errors"].append(err)

        if results["all_documents"]:
            t0 = time.time()
            results["all_chunks"] = self.text_splitter.split_documents(results["all_documents"])
            self._log.info(
                f"Chunking: {len(results['all_documents'])} doc(s) → "
                f"{len(results['all_chunks'])} chunk(s) in {time.time()-t0:.1f}s"
            )
        else:
            self._log.warning("No documents extracted — no chunks created")

        return results


# ═══════════════════════════════════════════════════════════════════════════
# VECTOR STORE MANAGER (ingest)
# ═══════════════════════════════════════════════════════════════════════════

class VectorStoreManager:
    _log = logging.getLogger("rag.vectorstore")

    def __init__(self, region_name, opensearch_endpoint=None,
                 opensearch_index=OPENSEARCH_INDEX,
                 pg_host=None, pg_port=5433, pg_database=None,
                 pg_user=None, pg_password=None, pg_table="vectors",
                 s3_vector_bucket_arn=None, s3_vector_index_arn=None):
        self.region_name      = region_name
        self.opensearch_index = opensearch_index
        self.pg_table         = pg_table

        self.opensearch_client = None
        if opensearch_endpoint and OPENSEARCH_AVAILABLE:
            self._log.info(f"Connecting to OpenSearch: {opensearch_endpoint}")
            creds    = boto3.Session().get_credentials().get_frozen_credentials()
            aws_auth = AWS4Auth(creds.access_key, creds.secret_key, region_name, "aoss",
                                session_token=creds.token)
            host = opensearch_endpoint.replace("https://", "").replace("http://", "")
            self.opensearch_client = OpenSearch(
                hosts=[{"host": host, "port": 443}], http_auth=aws_auth,
                use_ssl=True, verify_certs=True, connection_class=RequestsHttpConnection,
                timeout=120, max_retries=3, retry_on_timeout=True,
            )
            self._log.info("  ✓ OpenSearch client ready")

        self.pg_conn = None
        if pg_host and PGVECTOR_AVAILABLE:
            self._log.info(f"Connecting to PostgreSQL: {pg_host}:{pg_port}/{pg_database}")
            try:
                self.pg_conn = psycopg2.connect(host=pg_host, port=pg_port,
                    database=pg_database, user=pg_user, password=pg_password)
                cur = self.pg_conn.cursor()
                try:
                    cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
                    self.pg_conn.commit()
                except Exception:
                    self.pg_conn.rollback()
                cur.close()
                register_vector(self.pg_conn)
                self._log.info("  ✓ PostgreSQL connection ready")
            except Exception as e:
                self._log.error(f"  ✗ PostgreSQL connection failed: {e}")

        self.s3vectors_client = None
        if s3_vector_bucket_arn:
            self._log.info(f"Initialising S3 Vectors: {s3_vector_bucket_arn}")
            self.s3vectors_client = boto3.client("s3vectors", region_name="us-east-1")
            # ARN format: arn:aws:s3vectors:region:account:bucket/<bucket>
            # Index ARN:  arn:aws:s3vectors:region:account:bucket/<bucket>/index/<index>
            self._s3v_bucket = s3_vector_bucket_arn.split("bucket/")[1].split("/")[0]
            self._s3v_index  = s3_vector_index_arn.split("index/")[1].split("/")[0] if s3_vector_index_arn else None
            self._log.info(
                f"  ✓ S3 Vectors ready (bucket={self._s3v_bucket}, index={self._s3v_index})"
            )

    def create_embeddings(self, chunks: List[Document]) -> List[Dict]:
        if not BEDROCK_AVAILABLE:
            raise ImportError("Install: pip install langchain-aws")
        self._log.info(f"Embedding {len(chunks)} chunk(s) via Bedrock Titan...")
        t0         = time.time()
        model      = BedrockEmbeddings(model_id="amazon.titan-embed-text-v2:0",
                                       region_name=self.region_name)
        embeddings = model.embed_documents([c.page_content for c in chunks])
        dim        = len(embeddings[0]) if embeddings else 0
        self._log.info(
            f"  ✓ {len(embeddings)} embedding(s) | dim={dim} | time={time.time()-t0:.1f}s"
        )

        # ✅ Unique batch ID per ingest → guarantees APPEND, never overwrites old vectors
        batch_id = uuid.uuid4().hex[:12]
        self._log.info(f"  ✓ Batch ID: {batch_id} (all IDs unique across ingestions)")

        return [{"id": f"{batch_id}_{i}", "text": c.page_content,
                 "embedding": emb, "metadata": c.metadata}
                for i, (c, emb) in enumerate(zip(chunks, embeddings))]

    def store_in_opensearch(self, vector_data: List[Dict]) -> Dict:
        dim = len(vector_data[0]["embedding"])
        self._log.info(
            f"Storing {len(vector_data)} vector(s) → OpenSearch [{self.opensearch_index}] dim={dim}"
        )
        if not self.opensearch_client.indices.exists(index=self.opensearch_index):
            self._log.info(f"  Creating index [{self.opensearch_index}]...")
            self.opensearch_client.indices.create(index=self.opensearch_index, body={
                "settings": {"index": {"knn": True, "knn.algo_param.ef_search": 512}},
                "mappings": {"properties": {
                    "text":      {"type": "text"},
                    "embedding": {"type": "knn_vector", "dimension": dim,
                                  "method": {"name": "hnsw", "space_type": "l2", "engine": "nmslib"}},
                    "metadata":  {"type": "object", "enabled": True},
                }},
            })
            self._log.info("  ✓ Index created")

        # ✅ OpenSearch: uses {"index": {...}} action → always APPENDS new documents
        t0    = time.time()
        count = 0
        total_batches = (len(vector_data) + 49) // 50
        for batch_num, i in enumerate(range(0, len(vector_data), 50), 1):
            batch     = vector_data[i:i+50]
            bulk_body = []
            for item in batch:
                bulk_body.append({"index": {"_index": self.opensearch_index}})
                bulk_body.append({"text": item["text"], "embedding": item["embedding"],
                                  "metadata": item["metadata"]})
            try:
                resp   = self.opensearch_client.bulk(body=bulk_body)
                stored = len(batch) if not resp.get("errors") else sum(
                    1 for r in resp["items"]
                    if r.get("index", {}).get("result") in ["created", "updated"])
                count += stored
                self._log.info(f"  Batch {batch_num}/{total_batches}: {stored}/{len(batch)} stored")
            except Exception as e:
                self._log.error(f"  ✗ Bulk error (batch {batch_num}): {e}")
        self._log.info(f"  ✓ OpenSearch done: {count} doc(s) in {time.time()-t0:.1f}s")
        return {"index": self.opensearch_index, "documents": count}

    def store_in_pgvector(self, vector_data: List[Dict]) -> Dict:
        dim = len(vector_data[0]["embedding"])
        self._log.info(
            f"Storing {len(vector_data)} vector(s) → pgvector [{self.pg_table}] dim={dim}"
        )
        cur = self.pg_conn.cursor()
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {self.pg_table} (
                id TEXT PRIMARY KEY, content TEXT,
                embedding vector({dim}), metadata JSONB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
        self.pg_conn.commit()
        t0    = time.time()
        count = 0
        for item in vector_data:
            try:
                # ✅ ON CONFLICT DO NOTHING → pure APPEND, never overwrites existing rows
                cur.execute(f"""
                    INSERT INTO {self.pg_table} (id, content, embedding, metadata)
                    VALUES (%s,%s,%s,%s)
                    ON CONFLICT (id) DO NOTHING""",
                    (item["id"], item["text"],
                     np.array(item["embedding"], dtype=np.float32),
                     json.dumps(item["metadata"])))
                count += 1
            except Exception as e:
                self._log.error(f"  ✗ Insert error [{item['id']}]: {e}")
                self.pg_conn.rollback()
        self.pg_conn.commit()
        if count > 0:
            try:
                lists = max(1, count // 100)
                self._log.info(f"  Creating IVFFlat index (lists={lists})...")
                cur.execute(f"""
                    CREATE INDEX IF NOT EXISTS {self.pg_table}_embedding_idx
                    ON {self.pg_table} USING ivfflat (embedding vector_l2_ops)
                    WITH (lists = {lists})""")
                self.pg_conn.commit()
                self._log.info("  ✓ IVFFlat index created")
            except Exception as e:
                self._log.warning(f"  Index creation skipped: {e}")
                self.pg_conn.rollback()
        cur.close()
        self._log.info(f"  ✓ pgvector done: {count} row(s) in {time.time()-t0:.1f}s")
        return {"table": self.pg_table, "documents": count}

    def store_in_s3_vector_bucket(self, vector_data: List[Dict]) -> Dict:
        # ✅ S3 Vectors: unique batch_id prefix in IDs from create_embeddings → always APPENDS
        self._log.info(
            f"Storing {len(vector_data)} vector(s) → S3 Vectors "
            f"[bucket={self._s3v_bucket}, index={self._s3v_index}]"
        )
        t0     = time.time()
        total  = 0
        errors = []
        total_batches = (len(vector_data) + 99) // 100
        for batch_num, i in enumerate(range(0, len(vector_data), 100), 1):
            batch   = vector_data[i:i+100]
            payload = []
            for item in batch:
                meta = {"text": item["text"][:2000]}
                meta.update({str(k): str(v)[:500] for k, v in item.get("metadata", {}).items()})
                payload.append({
                    "key":      item["id"],
                    # ✅ S3 Vectors requires plain Python list[float] — convert from numpy/any type
                    "data":     {"float32": [float(x) for x in item["embedding"]]},
                    "metadata": meta,
                })
            try:
                self.s3vectors_client.put_vectors(
                    vectorBucketName=self._s3v_bucket,
                    indexName=self._s3v_index,
                    vectors=payload,
                )
                total += len(batch)
                self._log.info(f"  Batch {batch_num}/{total_batches}: {len(batch)} stored")
            except Exception as e:
                err_msg = (
                    f"S3 Vectors put_vectors failed (batch {batch_num}/{total_batches}): {e} | "
                    f"bucket={self._s3v_bucket} index={self._s3v_index}"
                )
                self._log.error(f"  ✗ {err_msg}")
                errors.append(err_msg)

        elapsed = time.time() - t0
        if errors:
            self._log.error(
                f"  ✗ S3 Vectors: {len(errors)} batch(es) failed — "
                f"{total}/{len(vector_data)} stored in {elapsed:.1f}s"
            )
        else:
            self._log.info(f"  ✓ S3 Vectors done: {total} vector(s) in {elapsed:.1f}s")

        return {
            "index_name":   self._s3v_index,
            "vector_count": total,
            "location":     f"s3vectors://{self._s3v_bucket}/{self._s3v_index}",
            "errors":       errors,
        }


# ═══════════════════════════════════════════════════════════════════════════
# RETRIEVER
# ═══════════════════════════════════════════════════════════════════════════

class VectorRetriever:
    _log = logging.getLogger("rag.retriever")

    def __init__(self, region_name, opensearch_endpoint=None,
                 opensearch_index=OPENSEARCH_INDEX,
                 pg_host=None, pg_port=5433, pg_database=None,
                 pg_user=None, pg_password=None, pg_table="vectors",
                 s3_vector_bucket_arn=None, s3_vector_index_arn=None):
        self.opensearch_index = opensearch_index
        self.pg_table         = pg_table

        self.opensearch_client = None
        if opensearch_endpoint and OPENSEARCH_AVAILABLE:
            creds    = boto3.Session().get_credentials().get_frozen_credentials()
            aws_auth = AWS4Auth(creds.access_key, creds.secret_key, region_name, "aoss",
                                session_token=creds.token)
            host = opensearch_endpoint.replace("https://", "").replace("http://", "")
            self.opensearch_client = OpenSearch(
                hosts=[{"host": host, "port": 443}], http_auth=aws_auth,
                use_ssl=True, verify_certs=True, connection_class=RequestsHttpConnection,
                timeout=120, max_retries=3, retry_on_timeout=True,
            )

        self.pg_conn = None
        if pg_host and PGVECTOR_AVAILABLE:
            try:
                self.pg_conn = psycopg2.connect(host=pg_host, port=pg_port,
                    database=pg_database, user=pg_user, password=pg_password)
                register_vector(self.pg_conn)
            except Exception as e:
                self._log.error(f"PostgreSQL connection failed: {e}")

        self.s3vectors_client = None
        self.s3_bucket_name   = None
        self.s3_index_name    = None
        if s3_vector_bucket_arn:
            self.s3vectors_client = boto3.client("s3vectors", region_name="us-east-1")
            # ARN format: arn:aws:s3vectors:region:account:bucket/<bucket>
            # Index ARN:  arn:aws:s3vectors:region:account:bucket/<bucket>/index/<index>
            self.s3_bucket_name = s3_vector_bucket_arn.split("bucket/")[1].split("/")[0]
            self.s3_index_name  = s3_vector_index_arn.split("index/")[1].split("/")[0] if s3_vector_index_arn else None

    def search_opensearch(self, emb, top_k):
        self._log.info(f"Searching OpenSearch [{self.opensearch_index}] top_k={top_k}")
        t0   = time.time()
        resp = self.opensearch_client.search(
            index=self.opensearch_index,
            body={"size": top_k,
                  "query": {"knn": {"embedding": {"vector": emb, "k": top_k}}},
                  "_source": ["text", "metadata"]})
        hits = resp["hits"]["hits"]
        self._log.info(f"  ✓ {len(hits)} hit(s) in {time.time()-t0:.2f}s")
        return [{"score": h["_score"], "text": h["_source"].get("text", ""),
                 "metadata": h["_source"].get("metadata", {})}
                for h in hits]

    def search_pgvector(self, emb, top_k):
        self._log.info(f"Searching pgvector [{self.pg_table}] top_k={top_k}")
        t0  = time.time()
        cur = self.pg_conn.cursor()
        e   = "[" + ",".join(map(str, emb)) + "]"
        cur.execute(f"""SELECT id, content, metadata, embedding <-> %s::vector AS distance
                        FROM {self.pg_table} ORDER BY distance LIMIT %s""", (e, top_k))
        rows = cur.fetchall(); cur.close()
        self._log.info(f"  ✓ {len(rows)} row(s) in {time.time()-t0:.2f}s")
        return [{"id": r[0], "text": r[1],
                 "metadata": r[2] if isinstance(r[2], dict) else json.loads(r[2]),
                 "distance": float(r[3])} for r in rows]
    def search_s3_vector_bucket(self, emb, top_k):
        self._log.info(
            f"Searching S3 Vectors [bucket={self.s3_bucket_name}, index={self.s3_index_name}] top_k={top_k}"
        )
        t0 = time.time()
        try:
            emb_list = [float(x) for x in emb]
            resp = self.s3vectors_client.query_vectors(
                vectorBucketName=self.s3_bucket_name,
                indexName=self.s3_index_name,
                queryVector={"float32": emb_list},
                topK=top_k,
                returnMetadata=True,
            )
            vectors = resp.get("vectors", [])
            self._log.info(f"  ✓ {len(vectors)} match(es) in {time.time()-t0:.2f}s")
            return [
                {
                    "id":       m.get("key"),
                    "score":    m.get("score"),
                    "text":     m.get("metadata", {}).get("text", ""),
                    "metadata": {k: v for k, v in m.get("metadata", {}).items() if k != "text"},
                }
                for m in vectors
            ]
        except Exception as e:
            self._log.error(
                f"  ✗ S3 Vectors query_vectors failed: {e} | "
                f"bucket={self.s3_bucket_name} index={self.s3_index_name}"
            )
            return []


# ═══════════════════════════════════════════════════════════════════════════
# BEDROCK LLM MANAGER
# ═══════════════════════════════════════════════════════════════════════════

class BedrockLLMManager:
    _log = logging.getLogger("rag.llm")

    def __init__(self, region_name, model_id):
        self._log.info(f"Initialising LLM: {model_id}")
        self.llm = ChatBedrock(model_id=model_id, region_name=region_name,
                               model_kwargs={"temperature": 0.1, "top_p": 0.9, "max_tokens": 2000})

    def generate_answer(self, query: str, docs: List[Dict], system_prompt: str = "") -> str:
        """
        Generates a grounded answer using retrieved docs and a dynamic system prompt.
        Uses SystemMessage + HumanMessage for proper ChatBedrock invocation.
        The system_prompt should be built via build_dynamic_system_prompt() from prompt.py.
        """
        from langchain_core.messages import SystemMessage, HumanMessage

        self._log.info(f"Generating answer from {len(docs)} doc(s)...")

        context = "\n\n".join(
            f"Document {i+1} (from {d.get('metadata', {}).get('file_name', 'Unknown')}):\n{d.get('text', '')}"
            for i, d in enumerate(docs)
        )

        messages = []
        if system_prompt:
            messages.append(SystemMessage(content=system_prompt))

        messages.append(HumanMessage(content=(
            f"Retrieved context:\n{context}\n\n"
            f"Question: {query}"
        )))

        t0     = time.time()
        answer = self.llm.invoke(messages).content
        self._log.info(f"  ✓ LLM response: {len(answer)} chars in {time.time()-t0:.1f}s")
        return answer