"""
app.py — FastAPI app and all API endpoints.

All classes, constants, session helpers, and enums live in retriver.py.
Run with: uvicorn app:app --reload --host 0.0.0.0 --port 8000
"""

import logging
from typing import List

from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware

from retriver import VectorDB, LLMModel, _session
from service import handle_ingest, handle_query

# ── App & logger ───────────────────────────────────────────────────────────
app      = FastAPI(title="RAG Pipeline API — LangChain Loaders Only", version="3.0.0")
_api_log = logging.getLogger("rag.api")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ═══════════════════════════════════════════════════════════════════════════
# GET /
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/")
def root():
    return {
        "status":  "running",
        "version": "3.0.0",
        "loaders": "LangChain native → OCR (EasyOCR/pytesseract) → Unstructured (optional) → Plain text",
        "no_textract": True,
        "append_mode": True,
        "supported_formats": [
            "PDF (text-based)", "DOCX/DOC", "XLSX/XLS (all sheets)", "CSV",
            "PPTX/PPT (all slides)", "HTML/HTM", "JSON/JSONL", "XML",
            "RTF", "ODT", "EPUB", "EML", "MSG (Outlook)",
            "TXT/MD/LOG", "Python/JS/TS/SQL/Go/Rust/Java/C++/... (all code files)",
            "Images: JPG/JPEG/PNG/TIFF/BMP/WEBP (OCR via EasyOCR or pytesseract)",
        ],
        "endpoints": {
            "POST /ingest":  "Upload files → chunk → embed → store (APPEND mode)",
            "POST /query":   "Ask question → retrieve → Bedrock answer (SSE streaming)",
            "GET  /session": "Check active vector DB",
            "GET  /docs":    "Swagger UI",
        },
    }


# ═══════════════════════════════════════════════════════════════════════════
# GET /session
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/session")
def get_session():
    return {
        "vector_db":        _session.get("vector_db"),
        "opensearch_index": _session.get("opensearch_index"),
    }


# ═══════════════════════════════════════════════════════════════════════════
# POST /ingest
# ═══════════════════════════════════════════════════════════════════════════

@app.post("/ingest")
async def ingest(
    vector_db:      VectorDB         = Form(...),
    s3_folder_name: str              = Form(...),
    files:          List[UploadFile] = File(...),
):
    return await handle_ingest(vector_db, s3_folder_name, files)


# ═══════════════════════════════════════════════════════════════════════════
# POST /query  — SSE Streaming
# ═══════════════════════════════════════════════════════════════════════════

@app.post("/query")
async def query(
    query:     str      = Form(...),
    llm_model: LLMModel = Form(LLMModel.claude_37_sonnet),
):
    return StreamingResponse(
        await handle_query(query, llm_model),
        media_type="text/event-stream",
        headers={
            "Cache-Control":     "no-cache",
            "X-Accel-Buffering": "no",
            "Connection":        "keep-alive",
        },
    )