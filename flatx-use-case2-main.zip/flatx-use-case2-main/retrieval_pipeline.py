from __future__ import annotations
import json
import asyncio
from typing import List
from langchain_core.documents import Document
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest

import query_processor as qp
from query_processor import (
    init_clients, close_clients,
    init_db_pool, close_db_pool,
    process_query,
    EMBED_URL, AWS_REGION,
)

#parameters  (To control retrieval behaviour)

SIMILARITY_THRESHOLD = 0.20  # flats which have similarity score more than the given value will appear

TOP_K = 20    # Total values to fetch from db after applying similarity threshold.

PAGE_SIZE = 5  # results per page


# Retrieval Function 
async def run_retrieval(
    query_result: dict,
    page: int = 1,
    page_size: int = PAGE_SIZE,
    top_k: int = TOP_K,
    similarity_threshold: float = SIMILARITY_THRESHOLD,
    seen_ids: set | None = None,
) -> List[Document]:
    """
    Takes the output of process_query() and runs the full retrieval pipeline.
    Args:
        query_result:         dict returned by process_query()
        page:                 1-based page number to retrieve
        page_size:            number of results per page
        top_k:                max total results to consider across all pages
        similarity_threshold: minimum cosine similarity score to include a result
        seen_ids:             set of listing IDs already shown on previous pages
                              (mutated in-place to track duplicates across calls)

    Returns:
        List of matching Document objects for the requested page.
    """
    if seen_ids is None:
        seen_ids = set()

    offset = (page - 1) * page_size
    search_query = query_result["search_query"]
    where_sql    = query_result["where_sql"]
    where_params = query_result["where_params"]

    print(f"\n")
    print(f"QUERY            : {query_result['user_query']}")
    print(f"{'\n'}")
    if page == 1:
        print(f"EXTRACTED FILTERS: {json.dumps(query_result['intents_extracted_from_query'], indent=2)}")
        print(f"BASELINE FILTERS : {json.dumps(query_result.get('baseline_filters', {}), indent=2)}")
        print(f"MERGED FILTERS   : {json.dumps(query_result['merged_filters'], indent=2)}")
        print(f"SEARCH QUERY     : {search_query}")
        print(f"WHERE CLAUSE     : {where_sql or '(none)'}")
        print(f"WHERE PARAMS     : {where_params}")
        print(f"{'\n'}")

    # Embed the search query via Amazon Titan 
    embedding_request_body = json.dumps({"inputText": search_query})

    # Sign the embedding request with AWS SigV4
    signed_embed_request = AWSRequest(
        method="POST", url=EMBED_URL,
        data=embedding_request_body.encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    SigV4Auth(qp._credentials, "bedrock", AWS_REGION).add_auth(signed_embed_request)

    async with qp._http_session.post(
        EMBED_URL,
        headers=dict(signed_embed_request.headers),
        data=embedding_request_body,
    ) as embedding_api_response:
        query_embedding_vector: list[float] = (await embedding_api_response.json(content_type=None))["embedding"]

    # Format vector as a PostgreSQL-compatible string literal
    query_vector_literal = "[" + ",".join(str(value) for value in query_embedding_vector) + "]"


    # pgvector cosine similarity search 

    #  parameter indices placed as placeholders in sql command
    where_param_count          = len(where_params)
    param_index_similarity_score  = where_param_count + 1   # used in SELECT for similarity score
    param_index_threshold_vector  = where_param_count + 2   # used in WHERE similarity >= threshold
    param_index_threshold_value   = where_param_count + 3   # the threshold value itself
    param_index_order_vector      = where_param_count + 4   # used in ORDER BY
    param_index_top_k_limit       = where_param_count + 5   # LIMIT (top_k) — inner query
    param_index_page_offset       = where_param_count + 6   # OFFSET (page-based) — outer query

    # Build the base filter: combine SQL WHERE clause with embeddings null-check
    base_where_clause = (
        f"WHERE ({where_sql}) AND embeddings IS NOT NULL"
        if where_sql else
        "WHERE embeddings IS NOT NULL"
    )

    # Exclude IDs already shown on previous pages to guarantee no duplicates
    exclude_seen_ids_clause = ""
    exclude_seen_ids_params: list = []
    if seen_ids:
        import uuid as uuid_module
        param_index_excluded_ids  = where_param_count + 5   # single array param
        param_index_top_k_limit   = where_param_count + 6   # top_k — inner query
        param_index_page_offset   = where_param_count + 7   # offset — outer query

        exclude_seen_ids_clause = f"AND id != ALL(${param_index_excluded_ids}::uuid[])"
        exclude_seen_ids_params = [[uuid_module.UUID(listing_id) for listing_id in seen_ids]]

    param_index_page_size = param_index_top_k_limit + 1    # page_size — outer query slice
    param_index_page_offset = param_index_top_k_limit + 2  # offset — outer query

    similarity_search_sql = f"""
        SELECT *
        FROM (
            SELECT
                id, title, description, area, city, location_details,
                floor, block, room_number, nearby_localities,
                bedroom_count, bathroom_count, monthly_rent, security_deposit,
                available_from, is_furnished, furnishing_details,
                amenities, house_rules, additional_charges,
                gender_preference, max_flatmates, current_flatmates,
                cover_image_url, created_at, bumped_at,
                1 - (embeddings <=> ${param_index_similarity_score}::vector) AS similarity
            FROM listings
            {base_where_clause}
              AND 1 - (embeddings <=> ${param_index_threshold_vector}::vector) >= ${param_index_threshold_value}
              {exclude_seen_ids_clause}
            ORDER BY embeddings <=> ${param_index_order_vector}::vector
            LIMIT ${param_index_top_k_limit}
        ) ranked
        LIMIT  ${param_index_page_size}
        OFFSET ${param_index_page_offset}
    """

    all_query_params = [
        *where_params,
        query_vector_literal,    # $param_index_similarity_score  — similarity score in SELECT
        query_vector_literal,    # $param_index_threshold_vector  — similarity filter in WHERE
        similarity_threshold,    # $param_index_threshold_value
        query_vector_literal,    # $param_index_order_vector      — ordering
        *exclude_seen_ids_params,# uuid[] array param (only present when seen_ids non-empty)
        top_k,                   # $param_index_top_k_limit       — inner query cap
        page_size,               # $param_index_page_size         — outer query page slice
        offset,                  # $param_index_page_offset       — outer query offset
    ]

    database_connection = await qp._db_pool.acquire()
    try:
        database_rows = list(await database_connection.fetch(similarity_search_sql, *all_query_params))
    finally:
        await qp._db_pool.release(database_connection)

    #Convert database rows to Document objects 
    retrieved_listings: List[Document] = []

    for row in database_rows:
        # Parse JSONB fields — may arrive as dict or raw JSON string
        amenities_data      = row["amenities"]         or {}
        house_rules_data    = row["house_rules"]        or {}
        nearby_data         = row["nearby_localities"]  or {}
        furnishing_data     = row["furnishing_details"] or {}
        additional_charges_data = row["additional_charges"] or {}

        if isinstance(amenities_data,          str): amenities_data          = json.loads(amenities_data)
        if isinstance(house_rules_data,        str): house_rules_data        = json.loads(house_rules_data)
        if isinstance(nearby_data,             str): nearby_data             = json.loads(nearby_data)
        if isinstance(furnishing_data,         str): furnishing_data         = json.loads(furnishing_data)
        if isinstance(additional_charges_data, str): additional_charges_data = json.loads(additional_charges_data)

        listing_metadata = {
            "id":                 str(row["id"]),
            "title":              row["title"] or "",
            "area":               row["area"],
            "city":               row["city"],
            "location_details":   row["location_details"] or "",
            "floor":              row["floor"],
            "block":              row["block"],
            "room_number":        row["room_number"],
            "nearby_localities_str": ", ".join(nearby_data.keys()) if isinstance(nearby_data, dict) else str(nearby_data),
            "bedroom_count":      row["bedroom_count"],
            "bathroom_count":     row["bathroom_count"],
            "rent":               float(row["monthly_rent"])     if row["monthly_rent"]     else None,
            "deposit":            float(row["security_deposit"]) if row["security_deposit"] else None,
            "available_from":     str(row["available_from"])     if row["available_from"]   else None,
            "is_furnished":       row["is_furnished"],
            "furnishing_details": ", ".join(f"{k}: {v}" for k, v in furnishing_data.items()) if furnishing_data else "",
            "amenities_str":      ", ".join(key for key, enabled in amenities_data.items()   if enabled),
            "rules_str":          ", ".join(key for key, enabled in house_rules_data.items() if enabled),
            "additional_charges": ", ".join(f"{k}: {v}" for k, v in additional_charges_data.items()) if additional_charges_data else "",
            "gender_preference":  str(row["gender_preference"]),
            "max_flatmates":      row["max_flatmates"],
            "current_flatmates":  row["current_flatmates"],
            "cover_image_url":    row["cover_image_url"] or "",
            "created_at":         str(row["created_at"]) if row["created_at"] else "",
            "bumped_at":          str(row["bumped_at"])  if row["bumped_at"]  else "",
            "similarity":         float(row["similarity"] or 0),
        }
        retrieved_listings.append(Document(page_content=row["description"] or "", metadata=listing_metadata))

    #Print formatted results 

    print(f"\n[PAGE {page}] {len(retrieved_listings)} listings found (page_size={page_size}, offset={offset}):\n")
    for page_result_index, listing in enumerate(retrieved_listings, 1):
        listing_display_meta = listing.metadata
        global_result_index = offset + page_result_index
        seen_ids.add(listing_display_meta["id"])   # register so future pages skip this flat
        print(f"\n  #{global_result_index}  [Page {page}] [{listing_display_meta.get('id')}]")
        print(f"       Title     : {listing_display_meta.get('title', 'N/A')}")
        print(f"       Location  : {listing_display_meta.get('area')}, {listing_display_meta.get('city')} | Floor: {listing_display_meta.get('floor', 'N/A')} | Block: {listing_display_meta.get('block', 'N/A')}")
        print(f"       Details   : {listing_display_meta.get('location_details', 'N/A')}")
        print(f"       BHK: {listing_display_meta.get('bedroom_count')} | Bathrooms: {listing_display_meta.get('bathroom_count')} | Gender: {listing_display_meta.get('gender_preference')}")
        print(f"       Rent      : ₹{listing_display_meta.get('rent')} | Deposit: ₹{listing_display_meta.get('deposit')} | Available: {listing_display_meta.get('available_from', 'N/A')}")
        print(f"       Furnished : {listing_display_meta.get('is_furnished')} | {listing_display_meta.get('furnishing_details', '')}")
        print(f"       Flatmates : Max {listing_display_meta.get('max_flatmates')} | Current {listing_display_meta.get('current_flatmates')}")
        print(f"       Amenities : {listing_display_meta.get('amenities_str', 'N/A')}")
        print(f"       Rules     : {listing_display_meta.get('rules_str', 'N/A')}")
        print(f"       Charges   : {listing_display_meta.get('additional_charges', 'N/A')}")
        print(f"       Nearby    : {listing_display_meta.get('nearby_localities_str', 'N/A')}")
        print(f"       Desc      : {listing.page_content[:200]}{'...' if len(listing.page_content) > 200 else ''}")
        print(f"       Similarity: {listing_display_meta.get('similarity', 0):.4f}")
    print("\n")

    return retrieved_listings


#main function
async def main() -> None:
    """Initialize shared resources and run the interactive query loop."""
    await asyncio.gather(init_clients(), init_db_pool())
    print("FlatX Search — type 'exit' to quit.")

    running_event_loop = asyncio.get_running_loop()
    try:
        seen_ids: set = set()
        current_query_result = None

        while True:
            user_input = await running_event_loop.run_in_executor(
                None, lambda: input("\nEnter query (or 'page <n>' to paginate, 'exit' to quit): ").strip()
            )
            if not user_input:
                continue
            if user_input.lower() == "exit":
                print("Bye!")
                break

            # Allow "page <n>" to paginate the last query without re-processing
            if user_input.lower().startswith("page ") and current_query_result is not None:
                try:
                    requested_page_number = int(user_input.split()[1])
                except (IndexError, ValueError):
                    print("Usage: page <number>")
                    continue
                await run_retrieval(
                    current_query_result,
                    page=requested_page_number,
                    page_size=PAGE_SIZE,
                    top_k=TOP_K,
                    similarity_threshold=SIMILARITY_THRESHOLD,
                    seen_ids=seen_ids,
                )
            else:
                # New query — reset pagination state
                seen_ids = set()
                current_query_result = await process_query(user_input)
                await run_retrieval(
                    current_query_result,
                    page=1,
                    page_size=PAGE_SIZE,
                    top_k=TOP_K,
                    similarity_threshold=SIMILARITY_THRESHOLD,
                    seen_ids=seen_ids,
                )

    except KeyboardInterrupt:
        print("\nBye!")
    finally:
        await asyncio.gather(close_clients(), close_db_pool())


if __name__ == "__main__":
    asyncio.run(main())
