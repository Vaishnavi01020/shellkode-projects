## Semantic Property Search — Vector Search Pipeline

A semantic search system for property listings built on PostgreSQL with pgvector extension, Amazon Bedrock (Titan & Nova Pro models), and asyncpg. It converts natural-language queries into structured SQL filters + vector embeddings and retrieves the most relevant listings using cosine similarity.


## Project Structure
```
FOLDER
├── .env                    # Environment variables & credentials
├── embeddings.py           # Generates and stores vector embeddings for listings
├── query_processor.py      # Parses natural-language queries into SQL filters
├── retrieval_pipeline.py   # Runs end-to-end vector similarity search
└── requirements.txt        # Python dependencies

```

## Key Components

# `embeddings.py`: 
Reads all unembedded listings from PostgreSQL, generates 1024-dimension vectors using `Amazon Bedrock Titan`, and writes them back to the database.

  Functions in embeddings.py :
 
1.generate_embeddings_for_listings() - Main entry point; processes listings in configurable batches 
2._build_embedding_text() - Converts a DB row (dict) into a clean text string for embedding 
3._generate_embedding() -  Calls Bedrock Titan and returns a `list[float]` vector 


# `query_processor.py`: 
Converts a raw user query into a parameterized PostgreSQL `WHERE` clause using an LLM.

Three-stage pipeline:
1. LLM Call — Sends query to Amazon Nova Pro (Bedrock) to extract filters and a semantic search sentence
2. JSON Parsing — Parses the LLM response with multiple fallback strategies
3. WHERE Clause Build — Merges extracted filters with baseline filters and builds parameterized SQL


# `retrieval_pipeline.py`
The core retrieval engine. Runs an interactive async query loop with pagination.

Three-stage retrieval:
1. Embedding — Embeds `search_query` via Amazon Titan (SigV4-signed)
2. Vector Search — Combines WHERE clause filters with pgvector cosine similarity (`<=>`) and applies similarity threshold + top-K limit
3. Row → Document — Parses JSONB fields and converts each row into a `Document` object

Interactive `main()` loop supports:
- New queries 
- `page <n>` commands (for pagination; eg: page 2 for 2nd page.)
- `exit` (for clean shutdown)


# Setup & Installation

## Prerequisites

- Python 3.9+
- PostgreSQL 13+ with the pgvector extension
- AWS account with Bedrock access (Titan + Nova Pro models)
- Git

1. Enable pgvector

Linux / macOS:

```bash

cd /tmp
git clone --branch v0.8.0 https://github.com/pgvector/pgvector.git
cd pgvector
make
make install  # may need sudo

```

Windows(run as Administrator in x64 Native Tools Command Prompt for VS):

```cmd

set "PGROOT=C:\Program Files\PostgreSQL\17"
cd %TEMP%
git clone --branch v0.8.0 https://github.com/pgvector/pgvector.git
cd pgvector
nmake /F Makefile.win
nmake /F Makefile.win install

```

> Windows requires Visual Studio with the "Desktop development with C++" workload installed.

>Then enable the extension in your target database using the below command:

```sql

CREATE EXTENSION vector;

```


2. Create a Virtual Environment

```bash

python -m venv .venv

```

Activate it:


Windows (CMD)  -   .venv\Scripts\activate
Windows (PowerShell) - .\.venv\Scripts\Activate.ps1
macOS / Linux  - source .venv/bin/activate

Install dependencies:

```bash

pip install -r requirements.txt

```


3. Configure Environment Variables

Create a `.env` file in the project root with the below credentials:

```
AWS_ACCESS_KEY_ID=<your_aws_access_key>
AWS_SECRET_ACCESS_KEY=<your_aws_secret_key>
AWS_REGION=<aws_region>               # e.g. ap-south-1

DB_HOST=<your_db_host>
DB_NAME=<your_db_name>
DB_USER=<your_db_user>
DB_PASSWORD=<your_db_password>
DB_PORT=<your_db_port>                # e.g. 5432
DB_DSN=postgresql://<DB_USER>:<DB_PASSWORD>@<DB_HOST>:<DB_PORT>/<DB_NAME>


```

> Production note: For production environments, prefer AWS Secrets Manager over a `.env` file.

##Running the Pipeline

### Step 1 — Generate Embeddings

```bash

python embeddings.py

```
###Step 2 — Run the Retrieval Pipeline

```bash

python retrieval_pipeline.py

```

This starts an interactive search loop. Type a natural-language property query to get results, use `page <n>` to paginate, and `exit` to quit.

Example queries:

```
> 2 BHK apartment in Chennai under 20000 with AC and WiFi
> page 2
> exit

```

