from __future__ import annotations
import json
import re
import os
from typing import Tuple
from dotenv import load_dotenv
import aiohttp
import asyncpg
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.credentials import Credentials

load_dotenv()

#Configuration

AWS_REGION    = "ap-south-1"
AWS_ACCESS_KEY = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")

LLM_MODEL_ID = "apac.amazon.nova-pro-v1:0"
EMBED_URL    = f"https://bedrock-runtime.{AWS_REGION}.amazonaws.com/model/amazon.titan-embed-text-v2:0/invoke"
LLM_URL      = f"https://bedrock-runtime.{AWS_REGION}.amazonaws.com/model/{LLM_MODEL_ID}/invoke"

DB_DSN = os.getenv("DB_DSN")

# Baseline filters applied to queries regardless of user input.
BASELINE_FILTERS: dict = {}

# Intent Extraction Prompt 

INTENT_PROMPT = """You are an intent extraction API for FlatX, a flat/flatmate search platform.

Task:
Given a user query, return ONLY a JSON object with exactly two keys:
- "filters": JSON object for SQL WHERE clause (numeric/boolean constraints).
- "search_query": one natural-language sentence for vector similarity search.

Rules:
- Only include fields explicitly mentioned by the user. If none, use "filters": {}.
- If the user mentions a specific area/locality, extract it as "area" (string) in filters AND include it in "search_query".
- "search_query" MUST NOT contain rent, deposit, BHK, amenities, floor, furnishing, or flatmate counts.
- "search_query" SHOULD include area/locality, lifestyle/vibe/proximity cues (NOT gender — gender goes in filters).
- Use these numeric fields (only when mentioned):
  exact_bhk, min_bhk, max_bhk,
  exact_rent, min_rent, max_rent,
  exact_deposit, min_deposit, max_deposit,
  exact_bathroom_count, min_bathroom_count, max_bathroom_count,
  exact_max_flatmates, min_max_flatmates, max_max_flatmates,
  exact_current_flatmates, min_current_flatmates, max_current_flatmates,
  exact_floor, min_floor, max_floor,
  is_furnished (boolean),
  gender_preference (string: "male", "female", or "any"),
  area (string: neighbourhood/locality name, title-cased, e.g. "Indiranagar", "HSR Layout"),
  amenities (string[]).

Conventions:
- "20k" → 20000, "1.5L" → 150000, "between X and Y" → min + max.
- Amenities must be lowercase snake_case: ac, geyser, washing_machine, tv, wifi, parking,
  refrigerator, microwave, power_backup, water_heater, lift, balcony.
- Expand lifestyle terms naturally in search_query: for example
  "cozy" → "warm comfortable homely atmosphere",
  "quiet" → "peaceful away from traffic noise",
  "sunlit" → "natural light bright well-ventilated".

Output format:
Return ONLY a single JSON object, no explanations, no extra keys.

Examples:

Q: "2bhk in hsr layout with ac, rent less than 30k, peaceful cozy flat with natural sunlight, quiet neighborhood away from main roads"
A: {"filters": {"exact_bhk": 2, "max_rent": 30000, "amenities": ["ac"], "area": "HSR Layout"}, "search_query": "flat in HSR Layout peaceful cozy natural sunlight well-ventilated quiet neighbourhood away from main roads"}

Q: "need 2bhk flat in whitefield, male, rent under 25k, friendly community"
A: {"filters": {"exact_bhk": 2, "max_rent": 25000, "gender_preference": "male", "area": "Whitefield"}, "search_query": "flat in Whitefield friendly community warm welcoming environment"} """


# AWS SigV4 credentials used for signing all Bedrock requests
_credentials: Credentials          = Credentials(access_key=AWS_ACCESS_KEY, secret_key=AWS_SECRET_KEY)
_http_session: aiohttp.ClientSession | None = None
_db_pool:      asyncpg.Pool | None          = None


async def init_clients() -> None:
    """Initialize the shared aiohttp session for Bedrock API calls."""
    global _http_session
    connector = aiohttp.TCPConnector(limit=200, ttl_dns_cache=300)
    _http_session = aiohttp.ClientSession(connector=connector)
    print("[INFO] HTTP session initialized")


async def close_clients() -> None:
    """Close and clean up the shared aiohttp session."""
    global _http_session
    if _http_session:
        await _http_session.close()
        _http_session = None


async def init_db_pool() -> None:
    """Initialize the asyncpg connection pool for PostgreSQL."""
    global _db_pool
    if _db_pool is None:
        try:
            _db_pool = await asyncpg.create_pool(dsn=DB_DSN, min_size=30, max_size=100)
            print("[INFO] Database pool initialized successfully")
        except Exception as error:
            print(f"[ERROR] Failed to connect to database: {error}")
            raise


async def close_db_pool() -> None:
    """Close and clean up the asyncpg connection pool."""
    global _db_pool
    if _db_pool:
        await _db_pool.close()
        _db_pool = None


#Query Processing Function 
async def process_query(user_query: str) -> dict:
    """
    Stage 1: Extract intent and build search parameters from a raw user query.

    Steps:
        1. Call Bedrock LLM to extract structured filters and a semantic search sentence.
        2. Parse the JSON response with sanitization fallbacks.
        3. Merge extracted filters with any configured baseline filters.
        4. Build a parameterized PostgreSQL WHERE clause from the merged filters.

    Returns a dict with:
        - user_query:                    original query string
        - search_query:                  LLM-generated semantic search sentence
        - intents_extracted_from_query:  raw filters extracted by the LLM
        - merged_filters:                filters after merging with baseline defaults
        - where_sql:                     parameterized SQL WHERE clause string
        - where_params:                  ordered list of parameter values for the WHERE clause
    """

    #Call Bedrock LLM for intent extraction 

    llm_request_body = json.dumps({
        "system": [{"text": INTENT_PROMPT}],
        "messages": [{"role": "user", "content": [{"text": user_query}]}],
        "inferenceConfig": {"temperature": 0, "maxTokens": 400},
    })

    # Sign the request with AWS SigV4 before sending
    signed_aws_request = AWSRequest(
        method="POST", url=LLM_URL,
        data=llm_request_body.encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    SigV4Auth(_credentials, "bedrock", AWS_REGION).add_auth(signed_aws_request)
    signed_headers = dict(signed_aws_request.headers)

    async with _http_session.post(LLM_URL, headers=signed_headers, data=llm_request_body) as llm_response:
        llm_response_text = (await llm_response.json(content_type=None))["output"]["message"]["content"][0]["text"]

    # Parse JSON from LLM response 
    def sanitize_json_string(raw_text: str) -> str:
        """Escape unescaped control characters inside JSON string values."""
        output, inside_string, escape_next_char = [], False, False
        for character in raw_text:
            if escape_next_char:
                output.append(character); escape_next_char = False; continue
            if character == "\\":
                output.append(character); escape_next_char = True; continue
            if character == '"':
                inside_string = not inside_string; output.append(character); continue
            if inside_string:
                if   character == "\n": output.append("\\n")
                elif character == "\r": output.append("\\r")
                elif character == "\t": output.append("\\t")
                else:                   output.append(character)
            else:
                output.append(character)
        return "".join(output)

    # Strip markdown code fences if the LLM wrapped the JSON in them
    cleaned_response = re.sub(r"```(?:json)?\s*", "", llm_response_text).replace("```", "").strip()

    parsed_intent = None

   
    for json_candidate in [cleaned_response, sanitize_json_string(cleaned_response)]:
        try:
            parsed_intent = json.loads(json_candidate)
            break
        except json.JSONDecodeError:
            pass

    
    if parsed_intent is None:
        json_match = re.search(r"\{.*\}", cleaned_response, re.DOTALL)
        if json_match:
            for json_candidate in [json_match.group(0), sanitize_json_string(json_match.group(0))]:
                try:
                    parsed_intent = json.loads(json_candidate)
                    break
                except json.JSONDecodeError:
                    pass

    if not parsed_intent:
        print(f"[ERROR] Intent extraction JSON parse failed.\n{llm_response_text[:400]}")
        parsed_intent = {}

    # Extract filters and sanitize the search query 
    intents_extracted_from_query = parsed_intent.get("filters", {})
    search_query = " ".join(parsed_intent.get("search_query", user_query).split())

    # Merge extracted filters with baseline defaults 

    merged_filters = dict(BASELINE_FILTERS)
    for filter_key, filter_value in intents_extracted_from_query.items():
        # Merge amenity lists rather than overwriting
        if filter_key == "amenities" and "amenities" in merged_filters:
            merged_filters["amenities"] = list(
                set(merged_filters["amenities"] + (filter_value if isinstance(filter_value, list) else []))
            )
        else:
            merged_filters[filter_key] = filter_value

    #Build parameterized SQL WHERE clause 

    where_conditions: list[str] = []
    where_params:     list      = []

    # Boolean filter: furnished status
    if merged_filters.get("is_furnished") is not None:
        where_conditions.append("is_furnished = $__IDX__")
        where_params.append(bool(merged_filters["is_furnished"]))

    # Enum filter: gender preference
    if merged_filters.get("gender_preference") is not None:
        gender_value = merged_filters["gender_preference"].lower().strip()
        if gender_value in ("male", "female", "any"):
            where_conditions.append("gender_preference = $__IDX__::gender_preference")
            where_params.append(gender_value)

    # String filter: area/locality (skip if user said "Bangalore" — that's the city, not an area)
    if merged_filters.get("area") and merged_filters["area"].strip().lower() != "bangalore":
        where_conditions.append("area ILIKE $__IDX__")
        where_params.append(merged_filters["area"].strip())

    # Numeric range/exact filters for all supported fields
    numeric_field_map = [
        ("bhk",               "bedroom_count"),
        ("rent",              "monthly_rent"),
        ("deposit",           "security_deposit"),
        ("bathroom_count",    "bathroom_count"),
        ("max_flatmates",     "max_flatmates"),
        ("current_flatmates", "current_flatmates"),
    ]
    for field_name, column_name in numeric_field_map:
        exact_value = merged_filters.get(f"exact_{field_name}")
        min_value   = merged_filters.get(f"min_{field_name}")
        max_value   = merged_filters.get(f"max_{field_name}")
        if exact_value is not None:
            where_conditions.append(f"{column_name} = $__IDX__")
            where_params.append(exact_value)
        else:
            if min_value is not None:
                where_conditions.append(f"{column_name} >= $__IDX__")
                where_params.append(min_value)
            if max_value is not None:
                where_conditions.append(f"{column_name} <= $__IDX__")
                where_params.append(max_value)

    # JSONB amenity filters: check each amenity key is true
    for amenity in (merged_filters.get("amenities") or []):
        where_conditions.append("(amenities->$__IDX__)::boolean = true")
        where_params.append(amenity.lower().replace(" ", "_"))

    # Replace $__IDX__ placeholders with sequential $1, $2, ... positional params
    finalized_conditions: list[str] = []
    param_index = 1
    for condition in where_conditions:
        finalized_conditions.append(condition.replace("$__IDX__", f"${param_index}", 1))
        param_index += 1

    where_sql = " AND ".join(finalized_conditions)


    return {
        "user_query":                   user_query,
        "search_query":                 search_query,
        "intents_extracted_from_query": intents_extracted_from_query,
        "baseline_filters":             dict(BASELINE_FILTERS),
        "merged_filters":               merged_filters,
        "where_sql":                    where_sql,
        "where_params":                 where_params,
    }
