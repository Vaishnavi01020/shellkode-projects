import boto3
import psycopg2
from psycopg2.extras import RealDictCursor
import json
import os
import logging
import sys
from typing import Optional, List, Dict, Any
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('embeddings.log')
    ]
)
logger = logging.getLogger(__name__)

# CONFIGURATION
AWS_REGION           = os.getenv("AWS_REGION", "ap-south-1")

#Batch size = 50 :  will embedd 50 rows in the table and then the embeddings will be updated in the table.change the value to 1 for single embedding + update that in the table.
EMBEDDING_BATCH_SIZE = 50

DB_CONFIG = {
    "host":     os.getenv("DB_HOST", "localhost"),
    "database": os.getenv("DB_NAME", "flatx"),
    "user":     os.getenv("DB_USER", "postgres"),
    "password": os.getenv("DB_PASSWORD", ""),
    "port":     int(os.getenv("DB_PORT", 5432)),
}


def generate_embeddings_for_listings(
    db_config: Dict[str, str] = None,
    aws_region: str = None,
    batch_size: int = None,
) -> dict:
    """
    Counts listings with NULL embeddings and generates embeddings for all of them
    using Amazon Titan embedding model. Returns a summary dict.

    Args:
        db_config:  DB connection dict (defaults to env-based DB_CONFIG)
        aws_region: AWS region for Bedrock (defaults to env AWS_REGION)
        batch_size: Rows per batch 
    """
    db_config  = db_config  or DB_CONFIG
    aws_region = aws_region or AWS_REGION
    batch_size = batch_size or EMBEDDING_BATCH_SIZE

    conn = None
    try:
        bedrock_client = boto3.client(
            service_name='bedrock-runtime',
            region_name=aws_region
        )

        conn = psycopg2.connect(**db_config)
        cur  = conn.cursor(cursor_factory=RealDictCursor)

        # Ensure pgvector extension exists
        try:
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
            conn.commit()
        except Exception as e:
            logger.warning(f"Could not create vector extension: {e}")

        # Ensure embeddings column exists
        cur.execute("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = 'listings' AND column_name = 'embeddings'
        """)
        if not cur.fetchone():
            cur.execute("ALTER TABLE listings ADD COLUMN embeddings VECTOR(1024)")
            conn.commit()
            logger.info("Embeddings column created")

        # Count rows that need embeddings
        cur.execute("SELECT COUNT(*) as count FROM listings WHERE embeddings IS NULL")
        null_count = cur.fetchone()['count']
        logger.info(f"Found {null_count} listings without embeddings")

        if null_count == 0:
            logger.info("All listings already have embeddings")
            return {"total": 0, "successful": 0, "failed": 0}

        total_successful = 0
        total_failed     = 0
        batch_number     = 0

        while True:
            batch_number += 1
            logger.info(f"Fetching batch {batch_number} (up to {batch_size} listings)...")

            cur.execute("""
                SELECT
                    id, title, description, area, city,
                    location_details, nearby_localities,
                    gender_preference, is_furnished,
                    amenities, house_rules
                FROM listings
                WHERE embeddings IS NULL
                ORDER BY created_at
                LIMIT %s
            """, (batch_size,))

            listings_batch = cur.fetchall()
            if not listings_batch:
                break

            batch_successful = 0
            batch_failed     = 0

            for row_index, listing in enumerate(listings_batch, 1):
                try:
                    embedding_text   = _build_embedding_text(listing)
                    embedding_vector = _generate_embedding(bedrock_client, embedding_text)

                    if embedding_vector:
                        if not isinstance(embedding_vector, list) or len(embedding_vector) != 1024:
                            logger.error(f"Invalid embedding dimensions for listing {listing['id']}")
                            batch_failed += 1
                            continue

                        cur.execute(
                            "UPDATE listings SET embeddings = %s::vector WHERE id = %s",
                            (embedding_vector, listing['id'])
                        )
                        logger.info(f"[{row_index}/{len(listings_batch)}] Embedded listing id={listing['id']}")
                        batch_successful += 1
                        total_successful += 1

                        if total_successful % 10 == 0:
                            logger.info(f"Progress: {total_successful} done, {total_failed} failed")
                    else:
                        logger.warning(f"No embedding returned for listing {listing['id']}")
                        batch_failed += 1
                        total_failed += 1

                except Exception as e:
                    logger.error(f"Error processing listing {listing['id']}: {e}", exc_info=True)
                    batch_failed += 1
                    total_failed += 1

            conn.commit()
            logger.info(f"Batch {batch_number} done: {batch_successful} successful, {batch_failed} failed")

            cur.execute("SELECT COUNT(*) as count FROM listings WHERE embeddings IS NULL")
            remaining_count = cur.fetchone()['count']
            logger.info(f"Remaining: {remaining_count}")
            if remaining_count == 0:
                break

        logger.info(f"=== SUMMARY: {total_successful} successful, {total_failed} failed ===")
        return {"total": null_count, "successful": total_successful, "failed": total_failed}

    except Exception as e:
        logger.error(f"Fatal error: {e}")
        if conn:
            conn.rollback()
        raise
    finally:
        if conn:
            conn.close()


def _build_embedding_text(listing: Dict[str, Any]) -> str:
    """Builds the text string for embedding from listing fields."""
    title             = listing.get('title', '')
    description       = listing.get('description', '')
    area              = listing.get('area', '')
    city              = listing.get('city', '')
    location_details  = listing.get('location_details', '')
    gender_preference = listing.get('gender_preference', 'any')
    is_furnished      = listing.get('is_furnished', False)

    nearby_localities = listing.get('nearby_localities', [])
    if isinstance(nearby_localities, str):
        try:
            nearby_localities = json.loads(nearby_localities)
        except:
            nearby_localities = []
    nearby_locality_names = []
    if isinstance(nearby_localities, list):
        nearby_locality_names = [
            loc.get('name', '') if isinstance(loc, dict) else str(loc)
            for loc in nearby_localities
        ]

    amenities = listing.get('amenities', [])
    if isinstance(amenities, str):
        try:
            amenities = json.loads(amenities)
        except:
            amenities = []
    amenities_list = [str(a) for a in amenities if a] if isinstance(amenities, list) else []

    house_rules = listing.get('house_rules', [])
    if isinstance(house_rules, str):
        try:
            house_rules = json.loads(house_rules)
        except:
            house_rules = []
    house_rules_list = [str(r) for r in house_rules if r] if isinstance(house_rules, list) else []

    embedding_text = (
        f"Title: {title}\n\n"
        f"Description: {description}\n\n"
        f"Location: {area}, {city}\n"
        + (f"Location Details: {location_details}\n" if location_details else "")
        + (f"Nearby: {', '.join(nearby_locality_names)}\n" if nearby_locality_names else "")
        + f"\nGender Preference: {gender_preference}\n"
        f"Furnishing: {'Furnished' if is_furnished else 'Unfurnished'}\n"
        + (f"Amenities: {', '.join(amenities_list)}\n" if amenities_list else "")
        + (f"House Rules: {', '.join(house_rules_list)}\n" if house_rules_list else "")
    )
    return embedding_text.strip()


def _generate_embedding(bedrock_client, text: str) -> Optional[List[float]]:
    """Generates a 1024-dim embedding vector via Amazon Titan."""
    try:
        request_body = json.dumps({
            "inputText": text,
            "dimensions": 1024,
            "normalize": True
        })
        bedrock_response = bedrock_client.invoke_model(
            modelId="amazon.titan-embed-text-v2:0",
            contentType="application/json",
            accept="application/json",
            body=request_body
        )
        response_body    = json.loads(bedrock_response['body'].read())
        embedding_vector = response_body.get('embedding')
        if not embedding_vector:
            logger.error(f"Bedrock response missing 'embedding' field: {response_body}")
        return embedding_vector
    except Exception as e:
        logger.error(f"Error generating embedding: {e}", exc_info=True)
        return None


if __name__ == "__main__":
    generate_embeddings_for_listings()
