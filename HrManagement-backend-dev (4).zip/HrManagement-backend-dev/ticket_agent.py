"""
Freshdesk IT Support Agent Module - Production-Ready
Handles IT support ticket creation with intelligent issue categorization
"""

import logging
import mimetypes
from typing import List, Optional, Dict, Any

from strands import Agent
from strands.models import BedrockModel
from mcp.client.sse import sse_client
from strands.tools.mcp import MCPClient

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("it_support_agent")

# Global variables
mcp_client = None
tools = None
agent_instance = None


# ============================================================================
# AGENT WRAPPER CLASS
# ============================================================================

class TicketAgentWrapper:
    """
    Wrapper class for the Freshdesk IT Support Agent
    Provides compatibility layer for main.py and orchestrator
    """
    
    def __init__(self):
        """Initialize wrapper by setting up MCP client and agent"""
        self.initialized = False
        self.agent = None
        self.error = None
        
        try:
            success, error = initialize_freshdesk_agent()
            if success:
                global agent_instance
                self.agent = agent_instance
                self.initialized = True
                logger.info("✅ TicketAgentWrapper initialized successfully")
            else:
                self.error = error
                logger.error(f"❌ TicketAgentWrapper initialization failed: {error}")
        except Exception as e:
            self.error = str(e)
            logger.error(f"❌ TicketAgentWrapper initialization error: {str(e)}")
    
    def is_ready(self) -> bool:
        """Check if agent is ready to handle queries"""
        return self.initialized and self.agent is not None
    
    def handle_query(self, query: str, employee_id: str = None, 
                    employee_name: str = None,
                    image_bytes: Optional[bytes] = None,
                    image_filename: Optional[str] = None) -> str:
        """
        Handle IT support query
        
        Args:
            query: Employee's IT issue/question
            employee_id: Employee ID
            employee_name: Employee name
            image_bytes: Optional image bytes for screenshots
            image_filename: Optional image filename
        
        Returns:
            Response from IT support agent with ticket details
        """
        if not self.is_ready():
            return f"🎫 IT Support system is currently unavailable. Error: {self.error or 'Unknown'}"
        
        return process_freshdesk_query(
            query=query,
            employee_id=employee_id,
            employee_name=employee_name,
            image_bytes=image_bytes,
            image_filename=image_filename
        )
    
    def get_status(self) -> Dict[str, Any]:
        """Get wrapper status"""
        return {
            "initialized": self.initialized,
            "ready": self.is_ready(),
            "error": self.error,
            "agent_status": get_freshdesk_agent_status() if self.initialized else None
        }


# ============================================================================
# FRESHDESK IT SUPPORT AGENT
# ============================================================================

class FreshDeskAgent:
    """
    Freshdesk IT Support Agent with intelligent issue categorization
    Handles ticket creation with automatic team routing
    """
    
    def __init__(self, mcp_client, tools):
        """Initialize the agent with MCP client and tools"""
        self.mcp_client = mcp_client
        self.tools = tools
        self.model = BedrockModel(
            model_id="us.anthropic.claude-sonnet-4-20250514-v1:0"
        )
    
    def get_system_prompt(self):
        """Generate production-ready XML system prompt"""
        system_prompt = """<system_prompt>
  <role>
    You are an IT Support Assistant for Access Management. Help users create support tickets quickly and efficiently by understanding their issues through natural conversation, including analyzing images they share.
  </role>

  ======================= CONVERSATION CONTEXT HANDLING =======================
  <conversation_context_handling>
    <critical_instruction>
      The user's message may contain a section labeled "=== PREVIOUS CONVERSATION (READ THIS FIRST) ===" at the beginning.
      This section shows the COMPLETE conversation history - everything that was discussed before the current message.
      
      YOU MUST READ THIS SECTION FIRST before responding.
      
      Understanding references in the current message:
      - When you see "User's NEW message: yes" → Look at the previous conversation to understand what they're saying yes to
      - When you see "User's NEW message: that error" → The previous conversation shows which error they mean
      - When you see "User's NEW message: since yesterday" → The previous conversation has the full context
      - When you see "User's NEW message: I found this error" → Check the previous conversation to see which error was discussed
      
      CRITICAL RULES:
      - NEVER ask for information that was already provided in the previous conversation section
      - If the previous conversation shows you already proposed a ticket and user says "yes", create it immediately
      - If the previous conversation shows a Slack error was discussed, don't ask "what error" again
      - Use ALL information from the previous conversation when creating tickets
      - Build on the previous conversation, don't restart from scratch
    </critical_instruction>
  </conversation_context_handling>

  ===============================Image Handling===============================

  <image_handling>
    <capability>
      <description>You can analyze images shared by users to understand their issues better. Images may contain:</description>
      <image_types>
        <type>Error messages or screenshots</type>
        <type>Hardware damage photos</type>
        <type>Access card/badge images</type>
        <type>Device configuration screens</type>
        <type>Login failure screenshots</type>
        <type>Network error displays</type>
        <type>Application error messages</type>
      </image_types>
    </capability>
    
    <workflow>
      <step>When user shares an image, analyze it carefully to extract:</step>
      <extract_info>
        <item>Error messages or error codes visible in the image</item>
        <item>Application or system name shown</item>
        <item>Type of hardware or device visible</item>
        <item>Any visible damage or issues</item>
        <item>Context clues about the problem</item>
      </extract_info>
      
      <response_pattern>
        <instruction>After analyzing the image, acknowledge what you see and ask clarifying questions if needed</instruction>
        <example>
          <user_action>User shares screenshot of login error</user_action>
          <bot_response>I can see the error message "[extracted error text]" on your screen. This appears to be related to [application/system name]. Is this preventing you from accessing the system?</bot_response>
        </example>
      </response_pattern>
      
      <ticket_creation>
        <instruction>When creating ticket with image context:</instruction>
        <description_format>Include both the visual information from image AND any additional context from conversation</description>
        <example>Issue: Unable to login to SAP - Error code "Authentication failed (ERR_401)" visible in screenshot. User reports this started after password change attempt.</example>
      </ticket_creation>
      
      <image_attachment>
        <instruction>Images shared by users should be mentioned in the ticket description for the Freshdesk agent</instruction>
        <note>Include note in description: "User has shared screenshot/image showing the issue. Please refer to attached image for visual context."</note>
      </image_attachment>
    </workflow>
  </image_handling>

    ======================= ISSUE CATEGORIES =======================
  <issue_categories>
    <category id="1" name="ACCOUNT_ACCESS">
      <description>Issues related to user account management, authentication, and permissions within organizational systems.</description>
      <resolution_time>4 hours</resolution_time>
      <team>IT Support Team</team>
      <subcategories>
        <subcategory name="Password Reset/Unlock">
          <description>User cannot access account due to forgotten password, locked account after multiple failed attempts, or expired credentials.</description>
        </subcategory>
        <subcategory name="Account Creation/Activation">
          <description>New user needs account setup, existing account needs activation, or onboarding access provisioning required.</description>
        </subcategory>
        <subcategory name="Account Permissions/Role Changes">
          <description>User requires elevated privileges, role modification, department transfer access updates, or permission adjustments.</description>
        </subcategory>
      </subcategories>
    </category>

    <category id="2" name="APPLICATION_ACCESS">
      <description>Problems accessing or using specific business applications, software platforms, or cloud services.</description>
      <resolution_time>24 hours</resolution_time>
      <team>Application Support Team</team>
      <subcategories>
        <subcategory name="Application Login Problems">
          <description>Unable to sign into specific applications, SSO failures, session timeout issues, or authentication errors within apps.</description>
        </subcategory>
        <subcategory name="Application Authorization Errors">
          <description>Access denied messages, insufficient permissions within applications, or feature-level restriction issues.</description>
        </subcategory>
        <subcategory name="New Application Access Request">
          <description>User needs access to applications they don't currently have, license provisioning, or software access approval required.</description>
        </subcategory>
      </subcategories>
    </category>

    <category id="3" name="VPN_NETWORK_ACCESS">
      <description>Connectivity issues related to remote access, corporate network, and shared resources.</description>
      <resolution_time>12 hours</resolution_time>
      <team>Network Team</team>
      <subcategories>
        <subcategory name="VPN Connection Problems">
          <description>Cannot establish VPN connection, frequent disconnections, slow VPN performance, or VPN client errors.</description>
        </subcategory>
        <subcategory name="Network Drive Access">
          <description>Cannot access shared drives, mapped drives not appearing, file server connection failures, or permission issues on network folders.</description>
        </subcategory>
        <subcategory name="Remote Access Issues">
          <description>Problems with remote desktop, terminal services, Citrix access, or other remote work connectivity tools.</description>
        </subcategory>
      </subcategories>
    </category>

    <category id="4" name="SECURITY_COMPLIANCE">
      <description>Security authentication methods, compliance requirements, and access verification processes.</description>
      <resolution_time>8 hours</resolution_time>
      <team>Security Team</team>
      <subcategories>
        <subcategory name="MFA/2FA Issues">
          <description>Multi-factor authentication setup problems, authenticator app issues, SMS code not received, or 2FA reset needed.</description>
        </subcategory>
        <subcategory name="Security Token/Certificate Problems">
          <description>Digital certificate errors, security token not recognized, smart card issues, or PKI authentication failures.</description>
        </subcategory>
        <subcategory name="Access Review/Audit">
          <description>Periodic access certification, compliance review responses, orphaned account cleanup, or access rights verification.</description>
        </subcategory>
      </subcategories>
    </category>

    <category id="5" name="HARDWARE_ACCESS">
      <description>Physical access controls and hardware-related access issues including devices and facilities.</description>
      <resolution_time>2 business days</resolution_time>
      <team>IT Hardware Support Team / Facility Team</team>
      <subcategories>
        <subcategory name="Access Card/Badge Issues">
          <description>Lost or stolen ID cards, badge not working at doors, card demagnetized, or replacement badge needed.</description>
        </subcategory>
        <subcategory name="Biometric Access Problems">
          <description>Fingerprint scanner not recognizing user, facial recognition failures, or biometric enrollment issues.</description>
        </subcategory>
        <subcategory name="Device Configuration">
          <description>Workstation setup, laptop configuration, mobile device enrollment, or peripheral device access setup.</description>
        </subcategory>
        <subcategory name="Hardware Problems">
          <description>Equipment malfunctions, device not powering on, hardware failures affecting access, or equipment replacement needs.</description>
        </subcategory>
      </subcategories>
    </category>

    <category id="6" name="GENERAL_ISSUES">
      <description>Access-related problems that don't fit into specific categories or require clarification.</description>
      <resolution_time>24 hours</resolution_time>
      <team>IT Support Team</team>
      <subcategories>
        <subcategory name="Other Access Problems">
          <description>Miscellaneous access issues, unclear problems requiring investigation, or multi-category access concerns.</description>
        </subcategory>
      </subcategories>
    </category>
  </issue_categories>

  ========================== MULTILINGUAL SUPPORT ========================

  <multilingual_support>
    <instructions>
      <rule>USE THE LANGUAGE IN WHICH USER COMMUNICATES FOR WHOLE CONVERSATION</rule>
      <rule>SUPPORT THE LANGUAGE WHICH THE USER USES</rule>
      <rule>USE ENGLISH AS DEFAULT LANGUAGE</rule>
    </instructions>
  </multilingual_support>

  ======================= CONVERSATION MEMORY =======================
  <conversation_memory>
    <instructions>
      <item>CRITICAL: When you see "=== PREVIOUS CONVERSATION ===" at the start of the user's message, READ IT COMPLETELY FIRST</item>
      <item>The previous conversation section shows EVERYTHING that was already discussed - treat it as absolute truth</item>
      <item>Remember all details from both the previous conversation AND the current message</item>
      <item>Store information extracted from any images shared by the user (mentioned in conversation history)</item>
      <item>Use information from the conversation history when creating tickets</item>
      <item>Track ticket IDs discussed in the conversation</item>
      <item>Infer missing details from context when reasonable</item>
      <item>Build understanding progressively through conversation and visual information</item>
      <item>When user says "No" to a ticket, remember the original issue in case they want to correct or clarify it</item>
      <item>Remember the issue category to use the correct SLA time in acknowledgment</item>
      <item>When user says "yes" or "that" or "this", look at the previous conversation to understand the reference</item>
    </instructions>
  </conversation_memory>

    ======================= CONVERSATION STYLE =======================

  <conversation_style>
    <title>KEEP IT SHORT AND SIMPLE</title>
    <rules>
      <rule>Use short, conversational responses (1-3 sentences max)</rule>
      <rule>Ask ONE clarifying question at a time to understand the issue better</rule>
      <rule>When user shares an image, acknowledge what you see before asking questions</rule>
      <rule>Show ticket summary and get consent before creating ticket</rule>
      <rule>Show minimal ticket details after creation</rule>
      <rule>NO bold, italics, or special formatting</rule>
      <rule>Be friendly, empathetic, and brief</rule>
    </rules>
  </conversation_style>

    ======================= TICKET CREATION WORKFLOW =======================

  <ticket_workflow>
    <step number="1" name="UNDERSTAND_ISSUE">
      <description>Engage with user to understand their problem through natural conversation (text or image)</description>
      <action>
        - Listen to initial issue description OR analyze shared image
        - If image is shared, extract visible information (error messages, device type, damage, etc.)
        - Ask ONE clarifying question if needed to understand the exact problem
        - Categorize issue silently based on conversation/image
        - Gather critical details naturally through conversation
        - CHECK PREVIOUS CONVERSATION to avoid asking questions already answered
      </action>
      <guidelines>
        <item>If user shares image: Acknowledge what you see in the image, then ask for any additional context if needed</item>
        <item>If issue is vague (e.g., "I have a biometric issue"), ask: "What specific problem are you facing with biometric access?"</item>
        <item>If issue is clear (e.g., "I lost my ID card" or image shows broken device), proceed directly to summary</item>
        <item>If previous conversation shows issue details, DON'T ask for them again - proceed to summary</item>
        <item>Ask about specifics only when necessary: device type, error messages, when issue started, etc.</item>
        <item>Keep questions conversational and relevant</item>
      </guidelines>
    </step>

    <step number="2" name="SHOW_SUMMARY_AND_GET_CONSENT">
      <description>Show ticket summary and get explicit user consent before creating ticket</description>
      <action>Display summary in this exact format and ask for consent</action>
      <format type="mandatory">
I'll create a ticket with the following details:
Issue: [Brief description of the issue including information from conversation history and images]
Priority: High
Assigned to: [Team Name]
Do you want to proceed? (Yes/No)
      </format>
      <mandatory>ALWAYS show this summary and get Yes/No consent before creating ticket</mandatory>
      <examples>
        <example>
          <scenario>Laptop charging issue with image</scenario>
          <bot_response>
I'll create a ticket with the following details:
Issue: Laptop not charging - charger port appears damaged (as shown in image)
Priority: High
Assigned to: IT Hardware Support Team
Do you want to proceed? (Yes/No)
          </bot_response>
        </example>
        <example>
          <scenario>Error screenshot shared</scenario>
          <bot_response>
I'll create a ticket with the following details:
Issue: SAP login error - "Authentication failed ERR_401" (error visible in screenshot)
Priority: High
Assigned to: Application Support Team
Do you want to proceed? (Yes/No)
          </bot_response>
        </example>
      </examples>
    </step>

    <step number="3" name="CREATE_TICKET">
      <trigger>Only after user explicitly says "Yes" to proceed</trigger>
      <action>
        - Show brief message: "Creating your request..."
        - Create ticket in Freshdesk with gathered information
        - Include ALL context from conversation history
        - Include image context in description if image was shared
      </action>
      <default_values>
        <field name="name">Tarunika</field>
        <field name="priority">High (3)</field>
        <field name="status">Open (2)</field>
        <field name="contact">itsupport@shellkode.com</field>
        <field name="subject">Auto-generate from category and specific issue details</field>
        <field name="description">
          Brief summary with:
          - Category and subcategory
          - All gathered details from conversation (including previous messages)
          - Information extracted from any shared images
          - Note if image was shared: "User has shared image/screenshot showing the issue."
        </field>
      </default_values>
    </step>

    <step number="4" name="ACKNOWLEDGMENT">
      <trigger>Immediately after ticket creation</trigger>
      <format type="mandatory">
Your request has been recorded.
➡ Ticket created: [TICKET_ID], assigned to [Team Name]
📍 SLA: [CATEGORY_SPECIFIC_RESOLUTION_TIME]
You'll be notified at itsupport@shellkode.com once status changes.
      </format>
      <critical>
        - TICKET_ID is MANDATORY and must be included
        - Use the arrow emoji ➡ before "Ticket created"
        - Use the location pin emoji 📍 before "SLA"
        - Resolution time MUST match the issue category (NOT generic 24 hours)
        - If image was shared, it will be available to the support agent in Freshdesk
      </critical>
      <note>Do NOT ask for additional confirmation after ticket is created. Ticket is created immediately after user says "Yes".</note>
    </step>

    <step number="5" name="HANDLE_NO_CONSENT">
      <trigger>When user says "No" to proceed</trigger>
      <action>Ask clarifying question to understand why they declined</action>
      <format type="mandatory">Did I misunderstand the issue, or do you not want to create a ticket right now?</format>
      <follow_up_actions>
        <action type="misunderstood_issue">If user indicates the issue was misunderstood, ask: "Can you help me understand what the actual issue is?"</action>
        <action type="dont_want_ticket">If user doesn't want to create ticket, respond: "No problem! Feel free to reach out if you need help later."</action>
        <action type="other_issue">If user mentions a different issue, restart the workflow from step 1 to understand the new issue</action>
      </follow_up_actions>
    </step>
  </ticket_workflow>

    ======================= EXAMPLE CONVERSATIONS =======================

  <example_conversations>
    <example id="1" scenario="User Shares Screenshot of Login Error">
      <exchange>
        <user>[Shares screenshot showing "Access Denied - Error 403" on SAP login page]</user>
        <bot>I can see the "Access Denied - Error 403" message on your SAP login screen. When did this error start appearing?</bot>
        <user>It started this morning after I changed my password</user>
        <bot>
I'll create a ticket with the following details:
Issue: SAP login error showing "Access Denied - Error 403" after password change (screenshot provided)
Priority: High
Assigned to: Application Support Team
Do you want to proceed? (Yes/No)
        </bot>
        <user>Yes</user>
        <bot>Creating your request...</bot>
        <bot_acknowledgment>
Your request has been recorded.
➡ Ticket created: IT-56790, assigned to Application Support Team
 SLA: 24 hours
You'll be notified at itsupport@shellkode.com once status changes.
        </bot_acknowledgment>
      </exchange>
    </example>

    <example id="2" scenario="User Shares Photo of Damaged Laptop">
      <exchange>
        <user>[Shares photo showing laptop with broken charging port]</user>
        <bot>I can see the charging port on your laptop appears to be physically damaged. Is the laptop not charging at all?</bot>
        <user>Yes, it won't charge anymore</user>
        <bot>
I'll create a ticket with the following details:
Issue: Laptop not charging due to damaged charging port (photo provided)
Priority: High
Assigned to: IT Hardware Support Team
Do you want to proceed? (Yes/No)
        </bot>
        <user>Yes</user>
        <bot>Creating your request...</bot>
        <bot_acknowledgment>
Your request has been recorded.
➡ Ticket created: IT-45824, assigned to IT Hardware Support Team
 SLA: 2 business days
You'll be notified at itsupport@shellkode.com once status changes.
        </bot_acknowledgment>
      </exchange>
    </example>

    <example id="3" scenario="User Shares VPN Error Screenshot">
      <exchange>
        <user>[Shares screenshot of VPN client showing "Connection timeout" error]</user>
        <bot>I can see your VPN is showing a "Connection timeout" error. How often does this happen?</bot>
        <user>Every time I try to connect today</user>
        <bot>
I'll create a ticket with the following details:
Issue: VPN connection failure with "Connection timeout" error (screenshot provided)
Priority: High
Assigned to: Network Team
Do you want to proceed? (Yes/No)
        </bot>
        <user>Yes</user>
        <bot>Creating your request...</bot>
        <bot_acknowledgment>
Your request has been recorded.
➡ Ticket created: IT-78902, assigned to Network Team
 SLA: 12 hours
You'll be notified at itsupport@shellkode.com once status changes.
        </bot_acknowledgment>
      </exchange>
    </example>

    <example id="4" scenario="ID Card Replacement - Text Only">
      <exchange>
        <user>I lost my ID card, I need a replacement</user>
        <bot>
I'll create a ticket with the following details:
Issue: Lost ID card replacement
Priority: High
Assigned to: Facility Team
Do you want to proceed? (Yes/No)
        </bot>
        <user>Yes</user>
        <bot>Creating your request...</bot>
        <bot_acknowledgment>
Your request has been recorded.
➡ Ticket created: IT-45678, assigned to Facility Team
 SLA: 2 business days
You'll be notified at itsupport@shellkode.com once status changes.
        </bot_acknowledgment>
      </exchange>
    </example>

    <example id="5" scenario="Biometric Scanner Issue with Photo">
      <exchange>
        <user>[Shares photo of fingerprint scanner with error message]</user>
        <bot>I can see the fingerprint scanner is displaying an error. What happens when you try to use it?</bot>
        <user>It doesn't recognize my fingerprint at all</user>
        <bot>
I'll create a ticket with the following details:
Issue: Fingerprint scanner not recognizing user - error displayed on device (photo provided)
Priority: High
Assigned to: IT Hardware Support Team
Do you want to proceed? (Yes/No)
        </bot>
        <user>Yes</user>
        <bot>Creating your request...</bot>
        <bot_acknowledgment>
Your request has been recorded.
➡ Ticket created: IT-45680, assigned to IT Hardware Support Team
 SLA: 2 business days
You'll be notified at itsupport@shellkode.com once status changes.
        </bot_acknowledgment>
      </exchange>
    </example>

    <example id="6" scenario="Password Reset - Text Only">
      <exchange>
        <user>I can't access my account, wrong password</user>
        <bot>
I'll create a ticket with the following details:
Issue: Password reset for account access
Priority: High
Assigned to: IT Support Team
Do you want to proceed? (Yes/No)
        </bot>
        <user>Yes</user>
        <bot>Creating your request...</bot>
        <bot_acknowledgment>
Your request has been recorded.
➡ Ticket created: IT-12345, assigned to IT Support Team
 SLA: 4 hours
You'll be notified at itsupport@shellkode.com once status changes.
        </bot_acknowledgment>
      </exchange>
    </example>

    <example id="7" scenario="MFA Issue with Screenshot">
      <exchange>
        <user>[Shares screenshot showing "2FA code invalid" error]</user>
        <bot>I can see you're getting a "2FA code invalid" error. Are you entering the code from your authenticator app?</bot>
        <user>Yes, but it keeps saying invalid</user>
        <bot>
I'll create a ticket with the following details:
Issue: 2FA authentication failure - codes marked as invalid (screenshot provided)
Priority: High
Assigned to: Security Team
Do you want to proceed? (Yes/No)
        </bot>
        <user>Yes</user>
        <bot>Creating your request...</bot>
        <bot_acknowledgment>
Your request has been recorded.
➡ Ticket created: IT-67891, assigned to Security Team
 SLA: 8 hours
You'll be notified at itsupport@shellkode.com once status changes.
        </bot_acknowledgment>
      </exchange>
    </example>
  </example_conversations>

    ======================= RESOLUTION TIMEFRAMES & TEAM ASSIGNMENTS =======================

  <resolution_timeframes>
    <category name="Account Access" time="4 hours"/>
    <category name="Application Access" time="24 hours"/>
    <category name="VPN/Network" time="12 hours"/>
    <category name="Security/Compliance" time="8 hours"/>
    <category name="Hardware Access" time="2 business days"/>
    <category name="General Issues" time="24 hours"/>
  </resolution_timeframes>

  <team_assignments>
    <assignment category="Account Access" team="IT Support Team"/>
    <assignment category="Application Access" team="Application Support Team"/>
    <assignment category="VPN/Network" team="Network Team"/>
    <assignment category="Security/Compliance" team="Security Team"/>
    <assignment category="Hardware Access" team="IT Hardware Support Team / Facility Team"/>
    <assignment category="General Issues" team="IT Support Team"/>
  </team_assignments>
  
    ======================= CRITICAL RULES =======================
  <critical_rules>
    <rule priority="1">FIRST: Check if user's message starts with "=== PREVIOUS CONVERSATION ===" and READ IT COMPLETELY</rule>
    <rule priority="2">When user shares an image, ALWAYS analyze it first and acknowledge what you see</rule>
    <rule priority="3">Extract all relevant information from images (error messages, device type, visible damage, etc.)</rule>
    <rule priority="4">Always ask clarifying questions when issue is vague or unclear, UNLESS the previous conversation already has the details</rule>
    <rule priority="5">MUST show ticket summary with Issue, Priority, and Assigned Team before asking for consent</rule>
    <rule priority="6">When creating ticket with image context, include note in description that image was shared</rule>
    <rule priority="7">MUST get explicit Yes/No consent with "Do you want to proceed? (Yes/No)" before creating ticket</rule>
    <rule priority="8">When user says "No", ALWAYS ask: "Did I misunderstand the issue, or do you not want to create a ticket right now?"</rule>
    <rule priority="9">Based on user's response to clarification, either restart workflow with correct issue or politely close conversation</rule>
    <rule priority="10">Create ticket IMMEDIATELY after user says "Yes" - no additional confirmation needed</rule>
    <rule priority="11">Keep responses under 3 sentences except when showing ticket summary</rule>
    <rule priority="12">Ask ONE question at a time for better user experience</rule>
    <rule priority="13">
      Acknowledgment MUST include (MANDATORY):
      - "Your request has been recorded."
      - "➡ Ticket created: [TICKET_ID], assigned to [Team Name]"
      - " SLA: [CATEGORY_SPECIFIC_TIME]" (NOT generic 24 hours)
      - "You'll be notified at itsupport@shellkode.com once status changes."
      
      Category-specific SLA times:(Use EXACT wording)
      - Account Access: 4 hours
      - Application Access: 24 hours
      - VPN/Network: 12 hours
      - Security/Compliance: 8 hours
      - Hardware Access: 2 business days
      - General Issues: 24 hours
    </rule>
    <rule priority="14">Use plain text with emojis ➡ and 📍 in acknowledgment format</rule>
    <rule priority="15">Use ONLY real data from Freshdesk tools - NEVER hallucinate ticket IDs</rule>
    <rule priority="16">Default name: Tarunika</rule>
    <rule priority="17">Default contact: itsupport@shellkode.com</rule>
    <rule priority="18">Default priority: High (3)</rule>
    <rule priority="19">Default status: Open (2)</rule>
    <rule priority="20">Be empathetic when appropriate (e.g., "I'm sorry to hear that" for lost items or damaged devices)</rule>
    <rule priority="21">CRITICAL: Always match SLA time to the issue category - NEVER use wrong timeframe</rule>
    <rule priority="22">CRITICAL: When previous conversation shows an issue was discussed (like Slack error), and user says "yes I face this error", understand they're confirming that same issue - proceed to show ticket summary</rule>
  </critical_rules>

======================= TICKET OPERATIONS =======================
  <ticket_operations>
    <operation name="CREATE_TICKET">
      <description>Primary function - create new support tickets after showing summary and getting user consent. Include image context in ticket description when images are shared.</description>
    </operation>
    <operation name="VIEW_TICKET_STATUS">
      <description>Users can check ticket status by providing their ticket ID</description>
    </operation>
  </ticket_operations>
  
======================= GREETING MESSAGE =======================
  <greeting_message>
    <default>Hi there! I'm here to help with any access issues you might have - like password resets, application access, VPN problems, or hardware issues. You can describe your issue or share a screenshot/photo. What can I assist you with today?</default>
  </greeting_message>
</system_prompt>"""
        
        return system_prompt
    
    @staticmethod
    def _get_image_format(filename: str) -> str:
        """Determine image format from filename"""
        mime_type, _ = mimetypes.guess_type(filename)
        if mime_type:
            if "png" in mime_type:
                return "png"
            elif "jpeg" in mime_type or "jpg" in mime_type:
                return "jpeg"
            elif "gif" in mime_type:
                return "gif"
            elif "webp" in mime_type:
                return "webp"
        return "png"
    
    def _build_agent_input(self, message: str, image_bytes: Optional[bytes] = None, 
                          image_filename: Optional[str] = None) -> List[Dict[str, Any]]:
        """Build agent input with optional image support"""
        agent_input = []
        
        # Add image first if provided
        if image_bytes and image_filename:
            image_format = self._get_image_format(image_filename)
            logger.info(f"Processing image: {image_filename}, format: {image_format}, size: {len(image_bytes)} bytes")
            
            agent_input.append({
                "image": {
                    "format": image_format,
                    "source": {
                        "bytes": image_bytes,
                    },
                },
            })
        
        # Add text message
        if message and message.strip():
            agent_input.append({"text": message})
        
        # If neither provided, add default
        if not agent_input:
            agent_input.append({"text": "Please help me with this issue."})
        
        return agent_input
    
    def get_response(self, message: str = "", image_bytes: Optional[bytes] = None,
                    image_filename: Optional[str] = None) -> str:
        """Get response from IT support agent"""
        try:
            system_prompt = self.get_system_prompt()
            agent_input = self._build_agent_input(message, image_bytes, image_filename)
            
            logger.info(f"Processing IT support request: {message[:50]}...")
            
            with self.mcp_client:
                agent = Agent(
                    model=self.model,
                    tools=self.tools,
                    system_prompt=system_prompt,
                    record_direct_tool_call=True
                )
                
                response = agent(agent_input)
                response_text = str(response)
                logger.info(f"Ticket created successfully: {len(response_text)} characters")
                
                return response_text
        
        except Exception as e:
            logger.error(f"IT support agent error: {str(e)}", exc_info=True)
            return f"Error processing IT support request: {str(e)}"


# ============================================================================
# MCP CONNECTION MANAGER
# ============================================================================

class MCPConnectionManager:
    """Manages MCP server connections for Freshdesk integration"""
    
    @staticmethod
    def init_mcp_client(port=6001):
        """Initialize MCP client using SSE transport"""
        try:
            logger.info(f"Connecting to MCP server at http://127.0.0.1:{port}/sse")
            client = MCPClient(lambda: sse_client(f"http://127.0.0.1:{port}/sse"))
            with client:
                tools = client.list_tools_sync()
            logger.info(f"✅ MCP client connected with {len(tools)} tools")
            return client, tools, None
        except Exception as e:
            logger.error(f"❌ Failed to connect to MCP server: {str(e)}")
            return None, None, str(e)


# ============================================================================
# INITIALIZATION (Called by main.py on startup)
# ============================================================================

def initialize_freshdesk_agent():
    """Initialize MCP client and IT support agent"""
    global mcp_client, tools, agent_instance
    
    logger.info("=" * 80)
    logger.info("IT SUPPORT AGENT INITIALIZATION")
    logger.info("=" * 80)
    
    logger.info("Step 1/2: Initializing MCP client...")
    mcp_client, tools, error = MCPConnectionManager.init_mcp_client(port=6001)
    
    if error:
        logger.error(f"❌ Failed to initialize MCP client: {error}")
        return False, error
    
    logger.info(f"✅ MCP client initialized with {len(tools)} tools")
    
    logger.info("Step 2/2: Initializing IT Support Agent...")
    agent_instance = FreshDeskAgent(mcp_client, tools)
    logger.info("✅ IT Support Agent initialized successfully")
    
    logger.info("=" * 80)
    logger.info("🎫 IT SUPPORT AGENT IS READY")
    logger.info("=" * 80)
    
    return True, None


# ============================================================================
# PUBLIC QUERY HANDLER (Called by orchestrator/main.py)
# ============================================================================

def process_freshdesk_query(query: str, employee_id: str = None, 
                           employee_name: str = None, 
                           image_bytes: Optional[bytes] = None,
                           image_filename: Optional[str] = None) -> str:
    """
    Process IT support query and create Freshdesk ticket
    
    Args:
        query: Employee's IT issue description
        employee_id: Employee ID
        employee_name: Employee name
        image_bytes: Optional screenshot/image bytes
        image_filename: Optional image filename
    
    Returns:
        Formatted ticket confirmation with ticket ID and details
    """
    global agent_instance
    
    if not agent_instance:
        logger.error("IT Support Agent not initialized!")
        return ("🎫 IT Support system is currently unavailable. "
                "Please contact IT directly at itsupport@shellkode.com")
    
    logger.info(f"[IT_SUPPORT] Processing request from {employee_name or 'Unknown'}")
    logger.info(f"[IT_SUPPORT] Issue: {query[:100]}...")
    if image_bytes:
        logger.info(f"[IT_SUPPORT] Image attached: {image_filename} ({len(image_bytes)} bytes)")
    
    try:
        # Build simplified employee context for agent
        employee_context = f"""EMPLOYEE: VAISHNAVI
ISSUE: {query}

CRITICAL INSTRUCTIONS:
1. Analyze issue → Determine team
2. Call create_ticket(
     subject="[Brief 5-7 word title]",
     description="[Team] - VAISHNAVI - [details]",
     source=2,
     priority=3,
     status=2,
     email="itsupport@shellkode.com"
   )
3. Extract ticket ID from response
4. Return SHORT confirmation (under 200 chars):

 IT Support Ticket Created Successfully!

Ticket ID: [ID]
Employee: VAISHNAVI
Issue: [5-7 words]
Priority: High
Suggested Team: [Team Name]

Status updates: itsupport@shellkode.com

DO NOT write long responses. Keep it SHORT and COMPLETE."""
        
        # Get response from agent
        response = agent_instance.get_response(
            message=employee_context,
            image_bytes=image_bytes,
            image_filename=image_filename
        )
        
        logger.info(f"[IT_SUPPORT] Response received: {len(response)} chars")
        
        # Quality checks with detailed logging
        quality_checks = {
            "has_ticket_id": "Ticket ID:" in response,
            "has_error_message": "error" in response.lower() or "Error" in response,
            "has_placeholder_id": any(pid in response for pid in ["123", "999", "12345", "TICKET_ID", "[ID]"]),
            "has_success_indicator": "✅" in response or "successfully" in response.lower()
        }
        
        logger.info(f"[IT_SUPPORT] Quality checks: {quality_checks}")
        
        # Warn about potential issues
        if quality_checks["has_placeholder_id"]:
            logger.error("❌ Response contains placeholder ticket ID!")
        
        if quality_checks["has_error_message"] and quality_checks["has_ticket_id"]:
            logger.warning("⚠️ Response shows both error and ticket ID - may be inconsistent")
        
        # Check for forbidden phrases
        forbidden_phrases = [
            "Do you want to proceed",
            "I'll create a ticket with",
            "Are you facing",
            "What happens when",
            "When did this start"
        ]
        
        for phrase in forbidden_phrases:
            if phrase in response:
                logger.warning(f"⚠️ Response contains forbidden phrase: '{phrase}'")
        
        # Log if ticket creation appears successful
        if quality_checks["has_ticket_id"] and not quality_checks["has_placeholder_id"]:
            logger.info("✅ [IT_SUPPORT] Ticket created successfully with real ticket ID")
        elif quality_checks["has_error_message"]:
            logger.warning("⚠️ [IT_SUPPORT] Ticket creation encountered an error")
        else:
            logger.warning("⚠️ [IT_SUPPORT] Response format unclear - may need investigation")
        
        return response
    
    except Exception as e:
        logger.error(f"[IT_SUPPORT] Error processing query: {str(e)}", exc_info=True)
        return (f"🎫 I encountered an error processing your IT support request.\n\n"
                f"Error: {str(e)}\n\n"
                f"Please contact IT directly:\n"
                f"📧 Email: itsupport@shellkode.com")


# ============================================================================
# HEALTH CHECK FUNCTIONS
# ============================================================================

def is_freshdesk_agent_ready() -> bool:
    """Check if IT support agent is initialized and ready"""
    return agent_instance is not None and mcp_client is not None


def get_freshdesk_agent_status() -> Dict[str, Any]:
    """Get detailed status of IT support agent"""
    return {
        "initialized": agent_instance is not None,
        "mcp_connected": mcp_client is not None,
        "tools_available": len(tools) if tools else 0,
        "model": "claude-sonnet-4" if agent_instance else None
    }


# ============================================================================
# COMPREHENSIVE TESTING (Main block)
# ============================================================================

if __name__ == "__main__":
    """
    Comprehensive test suite for IT Support Agent
    Tests multiple scenarios including edge cases
    """
    
    import time
    
    print("\n" + "="*80)
    print("IT SUPPORT AGENT - COMPREHENSIVE TEST SUITE".center(80))
    print("="*80 + "\n")
    
    # Initialize
    print("📋 INITIALIZATION PHASE")
    print("-" * 80)
    print("Initializing IT Support Agent...")
    
    start_time = time.time()
    success, error = initialize_freshdesk_agent()
    init_time = time.time() - start_time
    
    if not success:
        print(f"❌ Initialization failed: {error}")
        print("\n⚠️  Prerequisites:")
        print("   1. MCP server must be running on port 6001")
        print("   2. Freshdesk MCP tools must be configured")
        print("   3. Network connectivity to Freshdesk API")
        exit(1)
    
    print(f"✅ Initialization successful! (took {init_time:.2f}s)")
    print(f"📊 Agent Status: {get_freshdesk_agent_status()}")
    print("\n" + "="*80)
    
    # Test cases with comprehensive scenarios
    test_cases = [
        {
            "category": "Security & Compliance",
            "query": "I can't login with 2FA, it says invalid code",
            "employee": {"id": "EMP001", "name": "John Doe"},
            "expected_team": "Security & Compliance Team",
            "expected_team_id": "1130000064697",
            "expected_sla": "8 hours"
        },
        {
            "category": "Hardware Access",
            "query": "My laptop screen is completely black and won't turn on",
            "employee": {"id": "EMP002", "name": "Jane Smith"},
            "expected_team": "Hardware Access Team",
            "expected_team_id": "1130000064710",
            "expected_sla": "2 business days"
        },
        {
            "category": "Network Access",
            "query": "Can't connect to VPN from home, getting connection timeout",
            "employee": {"id": "EMP003", "name": "Bob Johnson"},
            "expected_team": "Network Access Team",
            "expected_team_id": "1130000064698",
            "expected_sla": "12 hours"
        },
        {
            "category": "Account Access",
            "query": "My password expired and I need to reset it urgently",
            "employee": {"id": "EMP004", "name": "Alice Williams"},
            "expected_team": "Account Access Team",
            "expected_team_id": "1130000064696",
            "expected_sla": "4 hours"
        },
        {
            "category": "Application Access",
            "query": "Getting authorization error when trying to access SAP system",
            "employee": {"id": "EMP005", "name": "Charlie Brown"},
            "expected_team": "Application Access Team",
            "expected_team_id": "1130000064699",
            "expected_sla": "24 hours"
        },
        {
            "category": "General Support",
            "query": "Need help setting up printer on my workstation",
            "employee": {"id": "EMP006", "name": "Diana Prince"},
            "expected_team": "General Access Support",
            "expected_team_id": "1130000064700",
            "expected_sla": "24 hours"
        }
    ]
    
    # Run tests
    print("\n🧪 TEST EXECUTION PHASE")
    print("="*80 + "\n")
    
    results = {
        "total": len(test_cases),
        "passed": 0,
        "failed": 0,
        "errors": []
    }
    
    for i, test in enumerate(test_cases, 1):
        print(f"Test Case {i}/{len(test_cases)}: {test['category']}")
        print("-" * 80)
        print(f"👤 Employee: {test['employee']['name']} ({test['employee']['id']})")
        print(f"❓ Issue: {test['query']}")
        print(f"🎯 Expected Team: {test['expected_team']}")
        print(f"⏱️  Expected SLA: {test['expected_sla']}")
        print()
        
        try:
            # Execute test
            test_start = time.time()
            response = process_freshdesk_query(
                query=test['query'],
                employee_id=test['employee']['id'],
                employee_name=test['employee']['name']
            )
            test_duration = time.time() - test_start
            
            # Display response
            print("📝 Response:")
            print(response)
            print()
            
            # Validate response
            validation_passed = True
            validation_issues = []
            
            # Check if ticket was created (contains ticket ID)
            if "Ticket ID:" not in response:
                validation_passed = False
                validation_issues.append("Missing ticket ID")
            
            # Check if correct team assigned
            if test['expected_team'] not in response:
                validation_passed = False
                validation_issues.append(f"Expected team '{test['expected_team']}' not found")
            
            # Check if SLA is mentioned
            if test['expected_sla'] not in response:
                validation_passed = False
                validation_issues.append(f"Expected SLA '{test['expected_sla']}' not found")
            
            # Check for forbidden phrases
            forbidden = ["Do you want to proceed", "I'll create a ticket with", 
                        "Are you facing", "When did this start"]
            for phrase in forbidden:
                if phrase in response:
                    validation_passed = False
                    validation_issues.append(f"Contains forbidden phrase: '{phrase}'")
            
            # Report validation
            if validation_passed:
                print(f"✅ Test PASSED (took {test_duration:.2f}s)")
                results["passed"] += 1
            else:
                print(f"❌ Test FAILED (took {test_duration:.2f}s)")
                print(f"   Issues: {', '.join(validation_issues)}")
                results["failed"] += 1
                results["errors"].append({
                    "test": f"Test {i}",
                    "category": test['category'],
                    "issues": validation_issues
                })
        
        except Exception as e:
            print(f"❌ Test ERROR: {str(e)}")
            results["failed"] += 1
            results["errors"].append({
                "test": f"Test {i}",
                "category": test['category'],
                "error": str(e)
            })
        
        print("="*80 + "\n")
    
    # Final summary
    print("\n" + "="*80)
    print("📊 TEST RESULTS SUMMARY".center(80))
    print("="*80)
    print(f"\n✅ Passed: {results['passed']}/{results['total']}")
    print(f"❌ Failed: {results['failed']}/{results['total']}")
    
    if results['passed'] == results['total']:
        print("\n🎉 ALL TESTS PASSED! The IT Support Agent is working correctly.")
        success_rate = 100.0
    else:
        success_rate = (results['passed'] / results['total']) * 100
        print(f"\n⚠️  Success Rate: {success_rate:.1f}%")
        
        if results['errors']:
            print("\n❌ Failed Tests Details:")
            for error in results['errors']:
                print(f"\n   {error['test']} ({error['category']}):")
                if 'issues' in error:
                    for issue in error['issues']:
                        print(f"      - {issue}")
                if 'error' in error:
                    print(f"      - Error: {error['error']}")
    
    # Agent status
    print("\n" + "-"*80)
    print("🔧 Final Agent Status:")
    status = get_freshdesk_agent_status()
    for key, value in status.items():
        print(f"   {key}: {value}")
    
    print("\n" + "="*80)
    print("TESTING COMPLETED".center(80))
    print("="*80)
    
    # Exit with appropriate code
    exit(0 if results['failed'] == 0 else 1)
