# medi_claim_chatbot.py - Medical Claim Management Agent with Strands
import psycopg2
from datetime import datetime
from strands import tool, Agent

# DATABASE CONFIG
DB_HOST = "database-2.cmxu40wm2cc1.us-east-1.rds.amazonaws.com"
DB_PORT = 5432
DB_NAME = "emp_db1"
DB_USER = "postgres"
DB_PASSWORD = "#Sritarunika1131"

def run_query(query, params=None, fetch=True):
    """Execute database query with error handling"""
    try:
        conn = psycopg2.connect(
            host=DB_HOST, port=DB_PORT, database=DB_NAME,
            user=DB_USER, password=DB_PASSWORD
        )
        cur = conn.cursor()
        cur.execute(query, params)
        rows = cur.fetchall() if fetch else None
        conn.commit()
        cur.close()
        conn.close()
        return rows
    except Exception as e:
        return {"error": str(e)}

# =====================
# DATABASE HELPERS
# =====================
def get_employee_claim_info(employee_id):
    """Get employee's medical claim plan information"""
    query = """
        SELECT employee_id, department, designation, employee_code, 
               full_name, plan_name, amount_payable
        FROM medi_claim_agent
        WHERE employee_id = %s
    """
    result = run_query(query, (employee_id,))
    if isinstance(result, dict): 
        return result
    if not result: 
        return None
    row = result[0]
    return {
        "employee_id": row[0],
        "department": row[1],
        "designation": row[2],
        "employee_code": row[3],
        "full_name": row[4],
        "plan_name": row[5],
        "amount_payable": float(row[6])
    }

def get_all_plan_details():
    """Get all available medical claim plans"""
    query = """
        SELECT plan_id, plan_name, description, amount_monthly, total_claim
        FROM plan_details
        ORDER BY amount_monthly
    """
    result = run_query(query)
    if isinstance(result, dict): 
        return result
    if not result: 
        return []
    return [
        {
            "plan_id": r[0],
            "plan_name": r[1],
            "description": r[2],
            "amount_monthly": float(r[3]) if r[3] else 0,
            "total_claim": float(r[4]) if r[4] else 0
        } for r in result
    ]

def get_claim_transactions(employee_id):
    """Get employee's claim transaction history"""
    query = """
        SELECT id, employee_id, claim_amount, claim_date, description
        FROM claim_transactions
        WHERE employee_id = %s
        ORDER BY claim_date DESC
    """
    result = run_query(query, (employee_id,))
    if isinstance(result, dict): 
        return result
    if not result: 
        return []
    return [
        {
            "id": r[0],
            "employee_id": r[1],
            "claim_amount": float(r[2]),
            "claim_date": r[3],
            "description": r[4]
        } for r in result
    ]

def get_claim_balance(employee_id):
    """Get employee's claim balance information"""
    query = """
        SELECT employee_id, total_limit, total_claimed, 
               balance_remaining, last_updated_at
        FROM claim_balance
        WHERE employee_id = %s
    """
    result = run_query(query, (employee_id,))
    if isinstance(result, dict): 
        return result
    if not result: 
        return None
    row = result[0]
    return {
        "employee_id": row[0],
        "total_limit": float(row[1]),
        "total_claimed": float(row[2]),
        "balance_remaining": float(row[3]),
        "last_updated_at": row[4]
    }

def login_with_credentials(employee_code: str, full_name: str):
    """Login employee with code and name"""
    query = """
        SELECT employee_id, employee_code, full_name, department, designation, status
        FROM employees
        WHERE employee_code = %s AND LOWER(full_name)=LOWER(%s) AND status='Active'
    """
    result = run_query(query, (employee_code, full_name))
    if isinstance(result, dict): 
        return result
    if not result: 
        return None
    row = result[0]
    return {
        "employee_id": row[0],
        "employee_code": row[1],
        "full_name": row[2],
        "department": row[3],
        "designation": row[4],
        "status": row[5]
    }

# =====================
# STRANDS TOOLS
# =====================
@tool
def show_my_claim_plan(employee_id: int) -> str:
    """Display the employee's current medical claim plan information"""
    info = get_employee_claim_info(employee_id)
    if isinstance(info, dict) and "error" in info: 
        return f"DB Error: {info['error']}"
    if not info: 
        return "No medical claim plan found for your account."
    
    msg = f"Your Medical Claim Plan Information\n\n"
    msg += f"Employee Name: {info['full_name']}\n"
    msg += f"Employee Code: {info['employee_code']}\n"
    msg += f"Department: {info['department']}\n"
    msg += f"Designation: {info['designation']}\n"
    msg += f"Plan Name: {info['plan_name']}\n"
    msg += f"Total Coverage Amount: Rs. {info['amount_payable']:,.2f}\n"
    return msg

@tool
def show_all_plans() -> str:
    """Display all available medical claim plans with details"""
    plans = get_all_plan_details()
    if isinstance(plans, dict) and "error" in plans: 
        return f"DB Error: {plans['error']}"
    if not plans: 
        return "No plans available."
    
    msg = "Available Medical Claim Plans\n\n"
    for plan in plans:
        msg += f"Plan: {plan['plan_name']}\n"
        msg += f"Description: {plan['description']}\n"
        msg += f"Monthly Premium: Rs. {plan['amount_monthly']:,.2f}\n"
        msg += f"Total Claim Limit: Rs. {plan['total_claim']:,.2f}\n"
        msg += f"-" * 50 + "\n"
    return msg

@tool
def view_claim_history(employee_id: int) -> str:
    """View all claim transactions for the employee"""
    transactions = get_claim_transactions(employee_id)
    if isinstance(transactions, dict) and "error" in transactions: 
        return f"DB Error: {transactions['error']}"
    if not transactions: 
        return "No claim transactions found."
    
    msg = "Your Claim Transaction History\n\n"
    total = 0
    for txn in transactions:
        msg += f"Date: {txn['claim_date']}\n"
        msg += f"Amount: Rs. {txn['claim_amount']:,.2f}\n"
        msg += f"Description: {txn['description']}\n"
        msg += f"-" * 50 + "\n"
        total += txn['claim_amount']
    
    msg += f"\nTotal Claims Made: Rs. {total:,.2f}\n"
    return msg

@tool
def check_claim_balance(employee_id: int) -> str:
    """Check current claim balance and remaining limit"""
    balance = get_claim_balance(employee_id)
    if isinstance(balance, dict) and "error" in balance: 
        return f"DB Error: {balance['error']}"
    if not balance: 
        return "No claim balance information found. You may not have made any claims yet."
    
    msg = "Your Claim Balance Summary\n\n"
    msg += f"Total Claim Limit: Rs. {balance['total_limit']:,.2f}\n"
    msg += f"Total Claimed: Rs. {balance['total_claimed']:,.2f}\n"
    msg += f"Balance Remaining: Rs. {balance['balance_remaining']:,.2f}\n"
    msg += f"Last Updated: {balance['last_updated_at']}\n"
    
    # Calculate usage percentage
    usage_pct = (balance['total_claimed'] / balance['total_limit'] * 100) if balance['total_limit'] > 0 else 0
    msg += f"\nUsage: {usage_pct:.1f}% of total limit\n"
    
    return msg

@tool
def submit_claim(employee_id: int, claim_amount: float, description: str) -> str:
    """Submit a new medical claim for reimbursement"""
    # First check if employee has enough balance
    balance = get_claim_balance(employee_id)
    
    # If no balance record exists, get total limit from medi_claim_agent
    if not balance:
        emp_info = get_employee_claim_info(employee_id)
        if not emp_info:
            return "Error: Employee claim information not found."
        available_limit = emp_info['amount_payable']
    else:
        available_limit = balance['balance_remaining']
    
    # Validate claim amount
    if claim_amount <= 0:
        return "Error: Claim amount must be greater than zero."
    
    if claim_amount > available_limit:
        return f"Error: Claim amount Rs. {claim_amount:,.2f} exceeds your available balance of Rs. {available_limit:,.2f}"
    
    # Insert claim transaction (trigger will update balance automatically)
    query = """
        INSERT INTO claim_transactions (employee_id, claim_amount, description)
        VALUES (%s, %s, %s)
        RETURNING id, claim_date
    """
    result = run_query(query, (employee_id, claim_amount, description), fetch=True)
    
    if isinstance(result, dict) and "error" in result: 
        return f"Error submitting claim: {result['error']}"
    
    if result:
        claim_id = result[0][0]
        claim_date = result[0][1]
        msg = f"Claim Successfully Submitted\n\n"
        msg += f"Claim ID: {claim_id}\n"
        msg += f"Amount: Rs. {claim_amount:,.2f}\n"
        msg += f"Description: {description}\n"
        msg += f"Date: {claim_date}\n"
        msg += f"\nYour claim has been submitted for processing. The amount will be reimbursed after approval.\n"
        return msg
    
    return "Error: Failed to submit claim."

@tool
def show_employee_profile(employee: dict) -> str:
    """Display employee profile information"""
    msg = "Employee Profile\n\n"
    msg += f"Name: {employee['full_name']}\n"
    msg += f"Employee Code: {employee['employee_code']}\n"
    msg += f"Department: {employee['department']}\n"
    msg += f"Designation: {employee['designation']}\n"
    return msg

# =====================
# AGENT CREATION
# =====================
def create_medi_claim_agent(employee_data: dict) -> Agent:
    """Create Medical Claim Management Agent with comprehensive system prompt"""
    system_prompt = f"""<medical_claim_agent>

<CRITICAL_INSTRUCTION priority="ABSOLUTE">
YOU MUST NEVER USE EMOJIS OR UNICODE SYMBOLS IN ANY RESPONSE
This includes: 💊 🏥 💰 💳 📋 📊 ✅ ❌ ℹ️ ⚕️ or ANY other decorative characters.
Use only plain text, letters, numbers, and basic punctuation.
This is a NON-NEGOTIABLE business requirement.
VIOLATION OF THIS RULE IS UNACCEPTABLE.
</CRITICAL_INSTRUCTION>

<identity>
You are the Medical Claim Management Specialist for {employee_data['full_name']} (Employee Code: {employee_data['employee_code']}).
Your role is to help employees manage their medical claims, check balances, view claim history, and submit new claims.
YOU MUST COMMUNICATE IN PLAIN TEXT ONLY - NO EMOJIS ALLOWED.
</identity>

<employee_context>
<employee_id>{employee_data['employee_id']}</employee_id>
<employee_code>{employee_data['employee_code']}</employee_code>
<full_name>{employee_data['full_name']}</full_name>
<department>{employee_data['department']}</department>
<designation>{employee_data['designation']}</designation>
</employee_context>

<strict_rules>
<rule priority="ABSOLUTE">FORBIDDEN: Never use emojis (💊 🏥 💰 💳 📋 📊 ✅ ❌ ℹ️ ⚕️)</rule>
<rule priority="ABSOLUTE">FORBIDDEN: Never use markdown tables with | symbols</rule>
<rule priority="ABSOLUTE">FORBIDDEN: Never use bold (**text**) or italic formatting</rule>
<rule priority="ABSOLUTE">FORBIDDEN: Never use decorative unicode symbols</rule>
<rule priority="CRITICAL">REQUIRED: Use only plain text with simple formatting</rule>
<rule priority="CRITICAL">REQUIRED: Use dashes (-) for bullet points only</rule>
<rule priority="CRITICAL">REQUIRED: Be professional and maintain business communication standards</rule>
</strict_rules>

<core_responsibilities>
1. Display employee's medical claim plan information
2. Show all available medical claim plans
3. View claim transaction history
4. Check claim balance and remaining limit
5. Submit new medical claims
6. Provide clear information about claim status and limits
7. Format all responses in PLAIN TEXT only (no emojis, no tables, no markdown)
</core_responsibilities>

<claim_types>
Medical claims can include:
- Hospital bills
- Doctor consultation fees
- Prescription medicines
- Diagnostic tests
- Medical procedures
- Emergency treatment
- Preventive care
</claim_types>

<tools>

<tool name="show_my_claim_plan">
<description>Display employee's current medical claim plan</description>
<input>employee_id (automatically provided)</input>
<output>Plan name, coverage amount, employee details</output>
<when_to_use>User asks about "my plan", "my coverage", "what plan am I on"</when_to_use>
</tool>

<tool name="show_all_plans">
<description>Display all available medical claim plans</description>
<input>None</input>
<output>List of all plans with descriptions, premiums, and coverage limits</output>
<when_to_use>User asks about "all plans", "available plans", "plan options"</when_to_use>
</tool>

<tool name="view_claim_history">
<description>View all claim transactions</description>
<input>employee_id (automatically provided)</input>
<output>List of claims with dates, amounts, and descriptions</output>
<when_to_use>User asks about "claim history", "past claims", "previous claims"</when_to_use>
</tool>

<tool name="check_claim_balance">
<description>Check current claim balance</description>
<input>employee_id (automatically provided)</input>
<output>Total limit, claimed amount, remaining balance, usage percentage</output>
<when_to_use>User asks about "balance", "remaining limit", "how much left"</when_to_use>
</tool>

<tool name="submit_claim">
<description>Submit a new medical claim</description>
<parameters>
<param name="employee_id">Automatically provided</param>
<param name="claim_amount">Amount in rupees (positive number)</param>
<param name="description">Detailed description of medical expense</param>
</parameters>
<when_to_use>User wants to submit/apply for a new claim</when_to_use>
<validation>
- Amount must be greater than zero
- Amount cannot exceed available balance
- Description must be meaningful
</validation>
</tool>

<tool name="show_employee_profile">
<description>Display employee profile information</description>
<input>employee data from context</input>
<output>Employee name, code, department, designation</output>
<when_to_use>User asks about their profile or account info</when_to_use>
</tool>

</tools>

<claim_submission_workflow>

<step number="1">
<title>Gather Claim Information</title>
<required_fields>
- claim_amount (must be positive number)
- description (detailed explanation of expense)
</required_fields>
</step>

<step number="2">
<title>Validate Claim</title>
<checks>
- Amount is greater than zero
- Amount does not exceed available balance
- Description is provided and meaningful
</checks>
</step>

<step number="3">
<title>Confirm with User</title>
<format>
I'll submit a medical claim for Rs. [amount] for [description]. 
Shall I proceed?
</format>
<wait_for>User confirmation: yes/ok/confirm/proceed/sure</wait_for>
</step>

<step number="4">
<title>Submit Claim</title>
<action>Call submit_claim tool with validated parameters</action>
<success_message>Display claim ID, amount, date, and confirmation message</success_message>
</step>

</claim_submission_workflow>

<output_format_guidelines>
<guideline>Use double newlines (\n\n) between sections</guideline>
<guideline>Use simple dashes (-) for bullet points</guideline>
<guideline>NEVER use markdown tables with pipes (|)</guideline>
<guideline>NEVER use asterisks for bold (**text**)</guideline>
<guideline>Format monetary amounts with commas: Rs. 1,00,000.00</guideline>
<guideline>Keep responses clean and professional</guideline>
</output_format_guidelines>

<example_interactions>

<example name="Check Balance">
<user>What's my claim balance?</user>
<assistant_action>check_claim_balance(employee_id)</assistant_action>
<assistant_response>
Your Claim Balance Summary

Total Claim Limit: Rs. 3,00,000.00
Total Claimed: Rs. 1,000.00
Balance Remaining: Rs. 2,99,000.00
Last Updated: 2025-11-28 10:30:00

Usage: 0.3% of total limit

You have excellent balance remaining for medical claims.
</assistant_response>
</example>

<example name="Submit Claim - Complete Info">
<user>I want to submit a claim for Rs 5000 for hospital consultation</user>
<assistant_action>Validate and prepare submission</assistant_action>
<assistant_response>
I'll submit a medical claim for Rs. 5,000.00 for hospital consultation.
Shall I proceed?
</assistant_response>
<user>yes</user>
<assistant_action>submit_claim(employee_id, 5000, "hospital consultation")</assistant_action>
<assistant_response>
Claim Successfully Submitted

Claim ID: 12
Amount: Rs. 5,000.00
Description: hospital consultation
Date: 2025-12-01

Your claim has been submitted for processing. The amount will be reimbursed after approval.
</assistant_response>
</example>

<example name="Submit Claim - Missing Info">
<user>I want to submit a claim for 3000</user>
<assistant_response>
I can help you submit a medical claim for Rs. 3,000.00.

Please provide a description of the medical expense. For example: hospital bill, doctor consultation, medicines, diagnostic tests, etc.
</assistant_response>
<user>medicine for fever treatment</user>
<assistant_response>
I'll submit a medical claim for Rs. 3,000.00 for medicine for fever treatment.
Shall I proceed?
</assistant_response>
</example>

<example name="View Plan Info">
<user>What plan am I on?</user>
<assistant_action>show_my_claim_plan(employee_id)</assistant_action>
<assistant_response>
Your Medical Claim Plan Information

Employee Name: VAISHNAVI
Employee Code: EMP002
Department: HR
Designation: HR Executive
Plan Name: Basic Plan
Total Coverage Amount: Rs. 3,00,000.00

This is your current medical claim plan details.
</assistant_response>
</example>

<example name="View All Plans">
<user>Show me all available plans</user>
<assistant_action>show_all_plans()</assistant_action>
<assistant_response>
Available Medical Claim Plans

Plan: Basic Plan
Description: Basic coverage for employee + spouse
Monthly Premium: Rs. 500.00
Total Claim Limit: Rs. 3,00,000.00
--------------------------------------------------
Plan: Silver Plan
Description: Coverage for employee + family (2 children)
Monthly Premium: Rs. 800.00
Total Claim Limit: Rs. 4,00,000.00
--------------------------------------------------
Plan: Gold Plan
Description: Complete family + parents coverage
Monthly Premium: Rs. 1,200.00
Total Claim Limit: Rs. 5,00,000.00
--------------------------------------------------

These are all available medical claim plans. Contact HR to change your plan.
</assistant_response>
</example>

</example_interactions>

<mandatory_rules>
<rule>ABSOLUTELY NO EMOJIS - Critical business requirement</rule>
<rule>Use proper newlines for readability</rule>
<rule>ALWAYS validate claim amount before submission</rule>
<rule>ALWAYS check available balance before submitting claim</rule>
<rule>NEVER submit claim without user confirmation</rule>
<rule>Format all monetary amounts consistently with Rs. and commas</rule>
<rule>Provide clear success/error messages</rule>
<rule>Ask for missing information one piece at a time</rule>
</mandatory_rules>

<forbidden_actions>
<forbidden>Using ANY emojis: 💊 🏥 💰 💳 📋 📊 ✅ ❌ ℹ️ ⚕️</forbidden>
<forbidden>Creating markdown tables with | symbols</forbidden>
<forbidden>Using ** for bold or __ for underline</forbidden>
<forbidden>Using # for headers</forbidden>
<forbidden>Submitting claims without validation</forbidden>
<forbidden>Submitting claims without user confirmation</forbidden>
<forbidden>Processing claims that exceed available balance</forbidden>
</forbidden_actions>

<communication_style>
<guideline>Be professional, helpful, and clear</guideline>
<guideline>Use simple language without medical jargon</guideline>
<guideline>Keep responses concise and actionable</guideline>
<guideline>Ask ONE question at a time</guideline>
<guideline>Always confirm before submitting claims</guideline>
<guideline>Provide helpful context and next steps</guideline>
<guideline>Use natural, conversational tone WITHOUT emojis</guideline>
</communication_style>

<error_handling>
<database_error>
<action>Clearly state technical issue occurred</action>
<action>Suggest contacting HR or IT support</action>
</database_error>
<insufficient_balance>
<action>Inform user of available balance</action>
<action>Suggest reducing claim amount or contacting HR</action>
</insufficient_balance>
<invalid_amount>
<action>Explain amount must be positive number</action>
<action>Ask user to provide valid amount</action>
</invalid_amount>
</error_handling>

<critical_reminders>
<reminder priority="CRITICAL">ABSOLUTE RULE: NO EMOJIS EVER</reminder>
<reminder priority="CRITICAL">ABSOLUTE RULE: NO MARKDOWN TABLES</reminder>
<reminder priority="CRITICAL">ABSOLUTE RULE: NO BOLD TEXT</reminder>
<reminder priority="HIGHEST">Always validate claim amounts against balance</reminder>
<reminder priority="HIGHEST">Always confirm before submitting claims</reminder>
<reminder priority="HIGH">Format monetary amounts consistently</reminder>
<reminder priority="HIGH">Provide clear, actionable responses</reminder>
</critical_reminders>

<final_validation_checklist>
Before sending ANY response, verify:
[ ] Response contains ZERO emojis
[ ] Response contains NO markdown tables
[ ] Response contains NO bold text
[ ] Response uses plain text only
[ ] Response has proper newlines
[ ] Response is professional and clear
</final_validation_checklist>

</medical_claim_agent>"""
    
    return Agent(
        name="medical_claim_agent",
        system_prompt=system_prompt,
        tools=[
            show_my_claim_plan,
            show_all_plans,
            view_claim_history,
            check_claim_balance,
            submit_claim,
            show_employee_profile
        ]
    )

def run_claim_query(agent, employee_data, user_input: str) -> str:
    """Execute claim query through the agent"""
    response = agent(
        user_input,
        context_variables={
            "employee_id": employee_data["employee_id"],
            "employee_code": employee_data["employee_code"],
            "full_name": employee_data["full_name"],
            "department": employee_data["department"],
            "designation": employee_data["designation"],
        }
    )
    if hasattr(response, "text"): 
        return response.text
    return str(response)

# =====================
# MAIN CLI INTERFACE
# =====================
def main():
    """Main CLI interface for Medical Claim Management"""
    print("\n" + "="*60)
    print("   MEDICAL CLAIM MANAGEMENT SYSTEM")
    print("="*60 + "\n")
    
    # Login
    print("Please login to continue\n")
    employee_code = input("Enter Employee Code: ").strip()
    full_name = input("Enter Full Name: ").strip()
    
    print("\nAuthenticating...")
    employee_data = login_with_credentials(employee_code, full_name)
    
    if isinstance(employee_data, dict) and "error" in employee_data:
        print(f"\nError: {employee_data['error']}")
        return
    
    if not employee_data:
        print("\nLogin failed. Invalid credentials or inactive account.")
        return
    
    print(f"\nWelcome, {employee_data['full_name']}!")
    print(f"Department: {employee_data['department']}")
    print(f"Designation: {employee_data['designation']}\n")
    
    # Create agent
    agent = create_medi_claim_agent(employee_data)
    
    print("Medical Claim Agent initialized successfully.")
    print("\nYou can now:")
    print("- Check your claim balance")
    print("- View claim history")
    print("- See your plan details")
    print("- View all available plans")
    print("- Submit new claims")
    print("\nType 'exit' or 'quit' to end the session.\n")
    print("="*60 + "\n")
    
    # Chat loop
    while True:
        user_input = input("You: ").strip()
        
        if not user_input:
            continue
        
        if user_input.lower() in ['exit', 'quit', 'bye', 'goodbye']:
            print("\nThank you for using Medical Claim Management System!")
            print("Have a great day!\n")
            break
        
        try:
            response = run_claim_query(agent, employee_data, user_input)
            print(f"\nAgent: {response}\n")
        except Exception as e:
            print(f"\nError: {str(e)}\n")
            print("Please try again or contact support.\n")

if __name__ == "__main__":
    main()
