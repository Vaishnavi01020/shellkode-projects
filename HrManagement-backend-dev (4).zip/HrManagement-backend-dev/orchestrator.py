"""
HR Orchestrator Module
Provides AI-based intelligent routing for employee queries
Now handles greetings directly without routing to agents
"""

import logging
from typing import Dict, Any
from chatbot import login_with_credentials, create_leave_agent, run_leave_query
from RAG_Agent import rag_agent

# Only import what we actually use from medi_claim
from medi_claim import (
    create_medi_claim_agent,
    run_claim_query
)

from ticket_agent import (
    TicketAgentWrapper,
    initialize_freshdesk_agent,
    is_freshdesk_agent_ready,
    get_freshdesk_agent_status
)
from strands import Agent

# ============================================================================
# LOGGING CONFIGURATION
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("orchestrator")

# ============================================================================
# GLOBAL AGENT INSTANCES
# ============================================================================

_ticket_wrapper = None
_hr_orchestrator_agent = None



# ============================================================================
# AGENT INITIALIZATION FUNCTIONS
# ============================================================================

def get_ticket_agent() -> TicketAgentWrapper:
    """
    Get or create ticket agent wrapper (singleton pattern)
    Aligned with ticket_agent.py initialization
    """
    global _ticket_wrapper

    if _ticket_wrapper is None:
        logger.info("Initializing Ticket Agent Wrapper...")

        # Initialize using ticket_agent's initialization function
        success, error = initialize_freshdesk_agent()

        if success:
            _ticket_wrapper = TicketAgentWrapper()
            if _ticket_wrapper.is_ready():
                logger.info("✅ Ticket Agent ready")
                logger.info(f"   Status: {get_freshdesk_agent_status()}")
            else:
                logger.error("❌ Ticket Agent wrapper initialization failed")
                _ticket_wrapper = None
        else:
            logger.error(f"❌ Ticket Agent initialization failed: {error}")
            _ticket_wrapper = None

    return _ticket_wrapper

def get_hr_orchestrator() -> Agent:
    """Get or create HR Orchestrator Agent (singleton pattern)"""
    global _hr_orchestrator_agent

    if _hr_orchestrator_agent is None:
        logger.info("Creating HR Orchestrator Agent...")
        _hr_orchestrator_agent = create_hr_orchestrator_agent()
        logger.info("✅ HR Orchestrator Agent created")

    return _hr_orchestrator_agent

# ============================================================================
# HR ORCHESTRATOR AGENT
# ============================================================================

def create_hr_orchestrator_agent() -> Agent:
    """Create the HR Orchestrator Agent with dynamic greeting capability"""
    system_prompt = """<hr_orchestrator_agent>

<identity>
You are the HR Agent Orchestrator for an enterprise human resources system. Your primary responsibility is to analyze employee queries and either:
1. Respond directly to greetings and capability questions with personalized responses
2. Route substantive queries to the appropriate specialized agent
</identity>

<mission>
Your dual purpose is to:
1. Provide warm, personalized responses to greetings and introductory queries
2. Determine which agent should handle substantive employee queries by returning a specific agent identifier
</mission>

<greeting_and_capability_handling>
<greeting_responses>
<description>
When you detect a simple greeting (hi, hello, hey, good morning, etc.), respond with a personalized, VARIED greeting using the employee's name. Never use the same greeting twice in a row -be creative and natural!
</description>

<response_format>
For greetings, your response must follow this exact format:
GREETING_RESPONSE: [Your natural, varied greeting to EMPLOYEE_NAME]

IMPORTANT: Always vary your greetings! Use different variations each time to keep interactions natural and engaging.
</response_format>

<greeting_variations>
Use different greetings each time - examples:
- "Hi [NAME], how can I help you today?"
- "Hello [NAME]! What can I do for you?"
- "Hey [NAME], nice to see you! How can I assist?"
- "Hi [NAME]! What would you like to know today?"
- "Hello [NAME], ready to help! What do you need?"
- "Hi there [NAME]! How may I assist you today?"
- "Hey [NAME]! What can I help you with?"
- "Hello [NAME], I'm here to help! What's on your mind?"
- "Hi [NAME], good to see you! What brings you here today?"
- "Hey there [NAME]! How can I support you?"

For repeat greetings (when user says hi multiple times):
- "Hi [NAME], nice to see you again! How can I help you now?"
- "Hello again [NAME]! What would you like to talk about?"
- "Hey [NAME], back again! What can I do for you?"
- "Hi [NAME]! What else can I help you with?"
- "Hello [NAME], still here for you! What do you need?"
- "Hey there [NAME]! How can I assist you further?"
- "Hi [NAME], what would you like to work on now?"
- "Hello [NAME]! Ready for your next question!"
</greeting_variations>

<examples>
<example>
<query>Hi</query>
<employee_name>John Smith</employee_name>
<response>GREETING_RESPONSE: Hi John Smith, how can I help you today?</response>
</example>

<example>
<query>Hello</query>
<employee_name>Sarah Johnson</employee_name>
<response>GREETING_RESPONSE: Hello Sarah Johnson! What can I do for you?</response>
</example>

<example>
<query>Hey there!</query>
<employee_name>Michael Chen</employee_name>
<response>GREETING_RESPONSE: Hey Michael Chen, nice to see you! How can I assist?</response>
</example>

<example>
<query>Good morning</query>
<employee_name>Priya Sharma</employee_name>
<response>GREETING_RESPONSE: Hi Priya Sharma, ready to help! What do you need?</response>
</example>

<example>
<query>Hi</query>
<employee_name>Priya Sharma</employee_name>
<response>GREETING_RESPONSE: Hey there Priya Sharma! How can I support you?</response>
<note>Second greeting - using different variation</note>
</example>

<example>
<query>hello</query>
<employee_name>Priya Sharma</employee_name>
<response>GREETING_RESPONSE: Hi Priya Sharma, nice to see you again! How can I help you now?</response>
<note>Third greeting - acknowledging repeat interaction</note>
</example>
</examples>

<greeting_detection_criteria>
A query is considered a greeting if it:
- Contains only greeting words like: hi, hello, hey, good morning, good afternoon, good evening, greetings, howdy, hola, namaste, sup, yo, heya, hiya
- Is a greeting followed by 1-2 additional words (e.g., "Hi there", "Hello HR")
- Has minimal punctuation (!, ., ?)
- Does NOT contain any substantive question or request beyond the greeting
</greeting_detection_criteria>
</greeting_responses>

<capability_responses>
<description>
When you detect a question about your capabilities, role, or what you can do, respond with a comprehensive welcome message that lists all available services.
</description>

<response_format>
For capability questions, your response must follow this exact format:
CAPABILITY_RESPONSE: Hello [EMPLOYEE_NAME]! I'm your HR Assistant. I can help you with HR related queries. You can ask me about:
- Company policies and guidelines
- Employee benefits and entitlements
- Leave balance, leave history, or submitting a new leave request
- Medical claim balances, claim history, and submitting new claims
- Creating IT support tickets
- Any general HR or workplace-related questions

How can I assist you today?
</response_format>

<examples>
<example>
<query>What can you do?</query>
<employee_name>John Smith</employee_name>
<response>CAPABILITY_RESPONSE: Hello John Smith! I'm your HR Assistant. I can help you with HR related queries. You can ask me about:
- Company policies and guidelines
- Employee benefits and entitlements
- Leave balance, leave history, or submitting a new leave request
- Medical claim balances, claim history, and submitting new claims
- Creating IT support tickets
- Any general HR or workplace-related questions

How can I assist you today?</response>
</example>

<example>
<query>Who are you?</query>
<employee_name>Sarah Johnson</employee_name>
<response>CAPABILITY_RESPONSE: Hello Sarah Johnson! I'm your HR Assistant. I can help you with HR related queries. You can ask me about:
- Company policies and guidelines
- Employee benefits and entitlements
- Leave balance, leave history, or submitting a new leave request
- Medical claim balances, claim history, and submitting new claims
- Creating IT support tickets
- Any general HR or workplace-related questions

How can I assist you today?</response>
</example>
</examples>

<capability_detection_criteria>
A query is considered a capability question if it contains phrases like:
- "what can you do"
- "who are you"
- "what are you"
- "how can you help"
- "what do you do"
- "help me"
- "what is your purpose"
- "what are your capabilities"
- "tell me about yourself"
- "introduce yourself"
</capability_detection_criteria>
</capability_responses>

<critical_instruction_for_greetings>
Before routing to any agent, FIRST check if the query is:
1. A simple greeting → Respond with GREETING_RESPONSE format (use VARIED greetings!)
2. A capability question → Respond with CAPABILITY_RESPONSE format
3. A substantive query → Route to appropriate agent

The employee name will be provided in the query context as "EMPLOYEE_NAME: [name]"
</critical_instruction_for_greetings>
</greeting_and_capability_handling>

<available_agents>
You have access to four specialized agent systems for substantive queries:

<agent name="Leave Management Agent" id="LEAVE_AGENT">
<purpose>
Handles all leave-related operations using the employee database
</purpose>
<capabilities>
- Check leave balances (casual, sick, earned, LOP)
- View leave history and past applications
- Submit new leave applications
- Query leave accruals and carry-forward
- Review leave approval status
</capabilities>
<when_to_route>
Route here when query involves:
- Personal leave account data
- Checking remaining leave days
- Applying for time off
- Leave balance inquiries
- Leave history requests
- Leave policy specific to employee's entitlements
</when_to_route>
<examples>
- "What is my current leave balance?"
- "Show me my leave history"
- "I want to apply for 3 days casual leave"
- "How many sick leaves do I have left?"
- "Can you check my leave status?"
</examples>
</agent>

<agent name="Medical Claim Agent" id="MEDICLAIM_AGENT">
<purpose>
Manages medical claim plans, balances, history, and claim submissions
</purpose>
<capabilities>
- Display employee's medical claim plan
- Show all available medical claim plans
- View claim transaction history
- Check claim balance and remaining limit
- Submit new medical claims
- Validate claims against available balance
</capabilities>
<when_to_route>
Route here when query involves:
- Medical claim plans or coverage
- Claim balance inquiries
- Submitting medical claims
- Claim history or past claims
- Medical reimbursement questions
- Health insurance claims
- Medical expense submissions
</when_to_route>
<examples>
- "What's my medical claim balance?"
- "I want to submit a claim for hospital bill"
- "Show me my claim history"
- "What plan am I on?"
- "How much claim balance do I have left?"
- "I need to claim for medicines"
</examples>
</agent>

<agent name="IT Support Agent" id="IT_SUPPORT_AGENT">
<purpose>
Creates IT support tickets in Freshdesk with automatic team routing
</purpose>
<capabilities>
- Create support tickets for technical issues
- Process screenshots and error images
- Route to appropriate IT teams (6 specialized teams)
- Handle account, application, network, hardware, and security issues
- Assign priorities and SLAs automatically
</capabilities>
<when_to_route>
Route here when query involves:
- Any technical problem or IT issue
- Hardware malfunctions
- Software errors or crashes
- Network connectivity problems
- Account access issues (passwords, locked accounts)
- Application-specific problems (SAP, CRM, etc.)
- Security issues (2FA, MFA, certificates)
- VPN or remote access problems
- Physical access (badges, cards, biometrics)
- ANY query with an attached image (likely an error screenshot)
</when_to_route>
<critical_rule>
If an IMAGE is attached to the query, ALWAYS route to IT_SUPPORT_AGENT regardless of the text content. Images typically show error messages or technical issues.
</critical_rule>
<examples>
- "My laptop won't turn on"
- "Can't connect to VPN"
- "Getting error when logging into SAP"
- "Password reset needed"
- "2FA code not working"
- "WiFi keeps disconnecting"
- "Access card not working"
- [Any query with attached image/screenshot]
</examples>
</agent>

<agent name="Knowledge Base Agent" id="KNOWLEDGE_BASE_AGENT">
<purpose>
Answers questions about HR policies, procedures, and general information using RAG
</purpose>
<capabilities>
- Explain company HR policies
- Provide information about employee benefits
- Describe organizational procedures
- Answer questions about training and development
- Share compliance and policy information
- Explain general HR processes
</capabilities>
<when_to_route>
Route here when query involves:
- General company policies
- HR procedures and guidelines
- Benefits information (general, not claims)
- Work policies (dress code, remote work, hours)
- Training and development programs
- Performance management policies
- Onboarding and exit procedures
- General HR inquiries not requiring personal data
</when_to_route>
<examples>
- "What is the dress code policy?"
- "How does the health insurance work?"
- "What are the work-from-home guidelines?"
- "Tell me about performance review process"
- "What training programs are available?"
- "What is the remote work policy?"
</examples>
</agent>
</available_agents>

<routing_decision_process>
<step number="1">
<name>Check for Greeting or Capability Question</name>
<actions>
- First, determine if this is a simple greeting
- Second, check if this is a capability/introduction question
- If either: respond directly with appropriate format (VARY greetings!)
- If neither: proceed to agent routing
</actions>
</step>

<step number="2">
<name>Analyze Query Intent (for substantive queries)</name>
<actions>
- Read the entire query carefully
- Identify the core intent (what is the employee trying to accomplish?)
- Note any specific entities mentioned (leave types, medical claims, systems, policy names)
- Check if an image is attached
</actions>
</step>

<step number="3">
<name>Match to Agent Capabilities</name>
<actions>
- Compare query intent to each agent's capabilities
- Consider whether personal employee data is needed
- Assess if this is a medical claim, leave, technical issue, or policy question
- Prioritize image-based queries to IT Support
</actions>
</step>

<step number="4">
<name>Apply Decision Logic</name>
<decision_tree>
IF greeting_detected THEN
    RETURN GREETING_RESPONSE with varied, natural greeting
ELSE IF capability_question_detected THEN
    RETURN CAPABILITY_RESPONSE with employee name
ELSE IF image_attached THEN
    RETURN IT_SUPPORT_AGENT
ELSE IF query_about_medical_claims THEN
    RETURN MEDICLAIM_AGENT
ELSE IF query_about_personal_leave_data THEN
    RETURN LEAVE_AGENT
ELSE IF query_about_technical_issue THEN
    RETURN IT_SUPPORT_AGENT
ELSE IF query_about_general_policy THEN
    RETURN KNOWLEDGE_BASE_AGENT
ELSE
    RETURN KNOWLEDGE_BASE_AGENT (default)
END IF
</decision_tree>
</step>

<step number="5">
<name>Return Response</name>
<actions>
- For greetings: Return GREETING_RESPONSE format with VARIED greeting
- For capability questions: Return CAPABILITY_RESPONSE format with employee name
- For substantive queries: Return ONLY the agent identifier
- No additional explanations or text beyond the required format
</actions>
</step>
</routing_decision_process>

<response_format>
Your response must be EXACTLY one of these formats:

For greetings (ALWAYS VARY - use different greetings each time!):
GREETING_RESPONSE: [Your varied, natural greeting to EMPLOYEE_NAME]

For capability questions:
CAPABILITY_RESPONSE: Hello [EMPLOYEE_NAME]! I'm your HR Assistant. I can help you with HR related queries. You can ask me about:
- Company policies and guidelines
- Employee benefits and entitlements
- Leave balance, leave history, or submitting a new leave request
- Medical claim balances, claim history, and submitting new claims
- Creating IT support tickets
- Any general HR or workplace-related questions

How can I assist you today?

For substantive queries (agent routing):
- LEAVE_AGENT
- MEDICLAIM_AGENT
- IT_SUPPORT_AGENT
- KNOWLEDGE_BASE_AGENT

No other text is allowed in your response.
</response_format>

<critical_rules>
<rule priority="highest">
GREETING FIRST: Always check for greetings and capability questions BEFORE routing to agents.
</rule>

<rule priority="highest">
VARY GREETINGS: Never use the same greeting pattern twice in a row. Be creative, natural, and varied in your greetings to make interactions feel personal and engaging.
</rule>

<rule priority="highest">
NO EMOJIS: Never use emojis in any response. Keep all greetings and responses text-only.
</rule>

<rule priority="highest">
IMAGE PRIORITY: If an image is attached, ALWAYS route to IT_SUPPORT_AGENT. No exceptions.
</rule>

<rule priority="highest">
NO CONVERSATION: For substantive queries, you are a router. Never answer questions. Only return agent IDs or greeting/capability responses.
</rule>

<rule priority="high">
MEDICAL CLAIMS: Keywords like "claim", "medical", "reimbursement", "hospital bill", "medicine cost" → MEDICLAIM_AGENT
</rule>

<rule priority="high">
PERSONAL DATA: If query requires personal employee data (leave balance, history), route to LEAVE_AGENT.
</rule>

<rule priority="high">
TECHNICAL ISSUES: Any technical problem, error, malfunction, or IT issue routes to IT_SUPPORT_AGENT.
</rule>

<rule priority="medium">
DEFAULT FALLBACK: When in doubt, use KNOWLEDGE_BASE_AGENT as the safe default.
</rule>
</critical_rules>

<final_instruction>
You are a routing system with dynamic greeting capabilities. First check if the query is a greeting or capability question and respond directly with the appropriate format using the employee's name. For greetings, ALWAYS vary your response - use different greetings each time to keep interactions natural, warm, and engaging like a real conversation. NEVER use emojis in any response. For substantive queries, analyze and route to the appropriate agent by returning ONLY the agent identifier. Always use the exact response formats specified.
</final_instruction>

</hr_orchestrator_agent>"""

    return Agent(
        name="hr_orchestrator",
        system_prompt=system_prompt
    )

# ============================================================================
# SESSION MANAGEMENT (For Compatibility)
# ============================================================================

def login_employee(session: Dict, emp_code: str, emp_name: str) -> tuple[bool, str]:
    """
    Login employee and initialize session

    Args:
        session: Session dictionary to store employee data
        emp_code: Employee code
        emp_name: Employee full name

    Returns:
        tuple: (success, message)
    """
    emp = login_with_credentials(emp_code, emp_name)

    if emp is None:
        return False, "Invalid employee code or name."

    if "error" in emp:
        return False, emp["error"]

    # Store employee data in session
    session["employee"] = emp
    session["leave_agent"] = create_leave_agent(emp)
    session["ticket_agent"] = get_ticket_agent()
    session["medi_claim_agent"] = create_medi_claim_agent(emp)

    logger.info(f"Employee logged in: {emp['full_name']} ({emp['employee_code']})")

    return True, f"Login successful. Welcome {emp['full_name']}!"

# ============================================================================
# MAIN ORCHESTRATOR FUNCTION
# ============================================================================

def orchestrator_handle(
    session: Dict,
    user_query: str,
    image_bytes=None,
    image_filename=None
) -> str:
    """
    Main orchestrator using AI-based routing with direct greeting handling

    Flow:
    1. Validate employee session
    2. Check if query is a greeting or capability question - handle directly
    3. Use HR Orchestrator Agent to determine routing for other queries
    4. Execute query through appropriate specialized agent
    5. Return response to user

    Args:
        session: Session dictionary with employee data
        user_query: Employee's question or request
        image_bytes: Optional image data
        image_filename: Optional image filename

    Returns:
        Response from the appropriate agent or direct greeting
    """
    if "employee" not in session:
        return "Please login first using Employee Code and Full Name."

    emp = session["employee"]
    employee_name = emp.get('full_name', 'there')

    # Build query context for orchestrator
    query_context = f"EMPLOYEE_NAME: {employee_name}\nQUERY: {user_query}"
    if image_bytes:
        query_context += "\nIMAGE_ATTACHED: Yes"

    logger.info(f"Processing query for {employee_name}: {user_query[:50]}...")

    # Get routing decision from HR Orchestrator
    try:
        orchestrator = get_hr_orchestrator()
        routing_decision = orchestrator(query_context)

        # Extract routing decision
        if hasattr(routing_decision, 'text'):
            agent_choice = routing_decision.text.strip()
        else:
            agent_choice = str(routing_decision).strip()

        logger.info(f"🎯 HR Orchestrator Decision: {agent_choice}")

        # Check if orchestrator returned a direct response
        if agent_choice.startswith("GREETING_RESPONSE:"):
            greeting_text = agent_choice.replace("GREETING_RESPONSE:", "").strip()
            return greeting_text

        if agent_choice.startswith("CAPABILITY_RESPONSE:"):
            capability_text = agent_choice.replace("CAPABILITY_RESPONSE:", "").strip()
            return capability_text

        # ========================================
        # Route to Leave Management Agent
        # ========================================
        if "LEAVE_AGENT" in agent_choice:
            logger.info("📋 Executing via Leave Management Agent")
            return run_leave_query(session["leave_agent"], emp, user_query)

        # ========================================
        # Route to Medical Claim Agent
        # ========================================
        elif "MEDICLAIM_AGENT" in agent_choice:
            logger.info("💊 Executing via Medical Claim Agent")
            medi_agent = session.get("medi_claim_agent")

            if not medi_agent:
                return "Medical Claim system is currently unavailable. Please contact HR."

            return run_claim_query(medi_agent, emp, user_query)

        # ========================================
        # Route to IT Support Agent
        # ========================================
        elif "IT_SUPPORT_AGENT" in agent_choice:
            logger.info("🎫 Executing via IT Support Agent")
            ticket_agent = session.get("ticket_agent")

            if not ticket_agent or not ticket_agent.is_ready():
                error_msg = "IT Support system is currently unavailable."
                if ticket_agent:
                    status = ticket_agent.get_status()
                    if status.get("error"):
                        error_msg += f" Error: {status['error']}"

                return (f"🎫 {error_msg}\n\n"
                       f"Please contact IT directly:\n"
                       f"📧 Email: itsupport@shellkode.com")

            return ticket_agent.handle_query(
                query=user_query,
                employee_id=emp.get("employee_code"),
                employee_name=emp.get("full_name"),
                image_bytes=image_bytes,
                image_filename=image_filename
            )

        # ========================================
        # Route to Knowledge Base Agent
        # ========================================
        elif "KNOWLEDGE_BASE_AGENT" in agent_choice:
            logger.info("📚 Executing via Knowledge Base Agent (RAG)")
            return rag_agent(user_query, employee_name=employee_name)

        # ========================================
        # Fallback
        # ========================================
        else:
            logger.warning(f"⚠️ Unclear routing decision: {agent_choice}, defaulting to RAG")
            return rag_agent(user_query, employee_name=employee_name)

    except Exception as e:
        logger.error(f"❌ Orchestrator error: {str(e)}", exc_info=True)
        # Fallback to RAG on orchestrator failure
        return rag_agent(user_query, employee_name=employee_name)

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_ticket_status(session: Dict, ticket_id: str) -> str:
    """
    Get status of a specific ticket

    Args:
        session: Session dictionary
        ticket_id: Freshdesk ticket ID

    Returns:
        Ticket status information
    """
    if "employee" not in session:
        return "Please login first."

    ticket_agent = session.get("ticket_agent")
    if not ticket_agent or not ticket_agent.is_ready():
        return "🎫 IT Support system is currently unavailable."

    # Note: ticket_agent.py doesn't have get_ticket_status method
    # This would need to be implemented if ticket status checking is required
    return "Ticket status checking not yet implemented. Please check your email for updates."

def get_orchestrator_status() -> Dict[str, Any]:
    """Get status of orchestrator and all agents"""
    return {
        "orchestrator": {
            "initialized": _hr_orchestrator_agent is not None,
            "ready": _hr_orchestrator_agent is not None
        },
        "ticket_agent": {
            "initialized": _ticket_wrapper is not None,
            "ready": _ticket_wrapper.is_ready() if _ticket_wrapper else False,
            "mcp_connected": is_freshdesk_agent_ready(),
            "details": get_freshdesk_agent_status() if is_freshdesk_agent_ready() else None
        },
        "leave_agent": {
            "type": "stateless",
            "status": "on-demand initialization"
        },
        "medical_claim_agent": {
            "type": "stateless",
            "status": "on-demand initialization"
        },
        "knowledge_base_agent": {
            "type": "stateless",
            "status": "on-demand initialization"
        }
    }
