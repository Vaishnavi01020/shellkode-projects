# main.py - Token-Based Authentication with Streaming Support
"""
Employee Assistant API - JWT Token Authentication with SSE Streaming
Agents: Leave Management, IT Support, Medical Claims, Knowledge Base
"""

from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Header, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import logging
from datetime import datetime, timedelta
from dataclasses import dataclass, field
import jwt
import secrets
import json
import re

from chatbot import login_with_credentials, create_leave_agent, run_leave_query
from RAG_Agent import rag_agent
from ticket_agent import (
    TicketAgentWrapper, 
    initialize_freshdesk_agent,
    is_freshdesk_agent_ready,
    get_freshdesk_agent_status
)

# ============================================================================
# ORCHESTRATOR IMPORTS
# ============================================================================
from orchestrator import (
    get_hr_orchestrator
)

# ============================================================================
# MEDICAL CLAIM IMPORTS
# ============================================================================
from medi_claim import create_medi_claim_agent, run_claim_query

# ============================================================================
# CONFIGURATION
# ============================================================================

SECRET_KEY = secrets.token_urlsafe(32)
ALGORITHM = "HS256"
TOKEN_EXPIRE_HOURS = 8

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("employee-assistant-api")

security = HTTPBearer()

# ============================================================================
# TOKEN MANAGEMENT
# ============================================================================

def create_access_token(employee_data: Dict[str, Any]) -> str:
    """Create JWT token with employee information"""
    expire = datetime.utcnow() + timedelta(hours=TOKEN_EXPIRE_HOURS)
    to_encode = {
        "email": employee_data.get("email"),
        "employee_code": employee_data.get("employee_code"),
        "full_name": employee_data.get("full_name"),
        "department": employee_data.get("department"),
        "designation": employee_data.get("designation"),
        "employee_id": employee_data.get("employee_id"),
        "exp": expire
    }
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """Verify JWT token and return employee data"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        logger.warning("Token expired")
        return None
    except jwt.JWTError as e:
        logger.warning(f"Token validation error: {str(e)}")
        return None

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> Dict[str, Any]:
    """Dependency to extract and verify user from token"""
    token = credentials.credentials
    employee_data = verify_token(token)
    if not employee_data:
        raise HTTPException(
            status_code=401, 
            detail="Invalid or expired token. Please login again."
        )
    return employee_data

# ============================================================================
# SESSION MANAGEMENT
# ============================================================================

@dataclass
class Message:
    role: str
    content: str
    timestamp: datetime
    agent_used: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
            "agent_used": self.agent_used
        }

@dataclass
class ConversationSession:
    session_id: str
    employee_code: str
    employee_name: str
    email_id: str
    messages: List[Message] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    last_activity: datetime = field(default_factory=datetime.now)
    
    def add_message(self, role: str, content: str, agent_used: Optional[str] = None):
        message = Message(role=role, content=content, timestamp=datetime.now(), agent_used=agent_used)
        self.messages.append(message)
        self.last_activity = datetime.now()
    
    def get_context_for_ai(self, max_messages: int = 6) -> str:
        recent = self.messages[-max_messages:]
        if not recent:
            return ""
        
        context_lines = ["CONVERSATION HISTORY:"]
        for msg in recent:
            prefix = "User" if msg.role == "user" else f"Assistant[{msg.agent_used}]"
            context_lines.append(f"{prefix}: {msg.content}")
        
        return "\n".join(context_lines)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "employee_code": self.employee_code,
            "employee_name": self.employee_name,
            "email_id": self.email_id,
            "message_count": len(self.messages),
            "created_at": self.created_at.isoformat(),
            "last_activity": self.last_activity.isoformat(),
            "messages": [msg.to_dict() for msg in self.messages]
        }

class SessionManager:
    def __init__(self, session_timeout_minutes: int = 480):
        self.sessions: Dict[str, ConversationSession] = {}
        self.employee_sessions: Dict[str, str] = {}
        self.session_timeout = timedelta(minutes=session_timeout_minutes)
        self.last_cleanup = datetime.now()
    
    def _cleanup_expired_sessions(self):
        now = datetime.now()
        if now - self.last_cleanup < timedelta(minutes=30):
            return
        
        expired = [
            sid for sid, session in self.sessions.items()
            if now - session.last_activity > self.session_timeout
        ]
        
        for session_id in expired:
            session = self.sessions[session_id]
            if session.email_id in self.employee_sessions:
                del self.employee_sessions[session.email_id]
            del self.sessions[session_id]
        
        self.last_cleanup = now
    
    def get_or_create_session(self, email_id: str, employee_code: str, employee_name: str) -> ConversationSession:
        self._cleanup_expired_sessions()
        
        if email_id in self.employee_sessions:
            session_id = self.employee_sessions[email_id]
            if session_id in self.sessions:
                session = self.sessions[session_id]
                if datetime.now() - session.last_activity < self.session_timeout:
                    return session
        
        session_id = f"SESSION-{employee_code}-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        session = ConversationSession(
            session_id=session_id,
            employee_code=employee_code,
            employee_name=employee_name,
            email_id=email_id
        )
        
        self.sessions[session_id] = session
        self.employee_sessions[email_id] = session_id
        return session
    
    def clear_session(self, email_id: str) -> bool:
        if email_id in self.employee_sessions:
            session_id = self.employee_sessions[email_id]
            if session_id in self.sessions:
                del self.sessions[session_id]
                del self.employee_sessions[email_id]
                return True
        return False

# ============================================================================
# FASTAPI APP
# ============================================================================

app = FastAPI(
    title="Employee Assistant API",
    description="JWT Token-based HR chatbot with streaming support",
    version="7.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global instances
ticket_wrapper = None
hr_orchestrator = None
session_manager = SessionManager(session_timeout_minutes=480)

# ============================================================================
# STARTUP
# ============================================================================

@app.on_event("startup")
async def startup_event():
    global ticket_wrapper, hr_orchestrator
    
    logger.info("=" * 80)
    logger.info("EMPLOYEE ASSISTANT API - STREAMING WITH JWT AUTH")
    logger.info("=" * 80)
    
    try:
        success, error = initialize_freshdesk_agent()
        if success:
            ticket_wrapper = TicketAgentWrapper()
            logger.info("✓ IT Support Agent initialized")
        else:
            logger.warning(f"⚠ IT Support Agent unavailable: {error}")
    except Exception as e:
        logger.error(f"✗ IT Support error: {str(e)}")
    
    try:
        hr_orchestrator = get_hr_orchestrator()
        logger.info("✓ HR Orchestrator initialized")
    except Exception as e:
        logger.error(f"✗ Orchestrator error: {str(e)}")
    
    logger.info("✓ Medical Claim Agent ready")
    logger.info("=" * 80)

# ============================================================================
# ROUTING LOGIC
# ============================================================================

def route_query(
    employee_data: Dict[str, Any],
    query: str,
    conversation_history: str = "",
    image_bytes: Optional[bytes] = None, 
    image_filename: Optional[str] = None
) -> tuple[str, str, Dict[str, Any]]:
    """Route query using HR Orchestrator with Medical Claim support"""
    
    employee_name = employee_data.get('full_name', 'there')
    
    # Handle greetings directly (imported from orchestrator)

    
    # Build query context with employee name
    query_context = ""
    if conversation_history:
        query_context += f"{conversation_history}\n\n"
    query_context += f"EMPLOYEE_NAME: {employee_data['full_name']}\n"
    query_context += f"QUERY: {query}"
    if image_bytes:
        query_context += "\nIMAGE_ATTACHED: Yes"
    
    try:
        routing_decision = hr_orchestrator(query_context)
        agent_choice = routing_decision.text.strip() if hasattr(routing_decision, 'text') else str(routing_decision).strip()
        
        logger.info(f"🎯 Routing Decision: {agent_choice}")
        
        # Check if orchestrator returned a greeting or capability response
        if agent_choice.startswith("GREETING_RESPONSE:"):
            greeting_text = agent_choice.replace("GREETING_RESPONSE:", "").strip()
            return greeting_text, "Direct Response (Greeting)", {"routing_method": "orchestrator_greeting"}
        
        if agent_choice.startswith("CAPABILITY_RESPONSE:"):
            capability_text = agent_choice.replace("CAPABILITY_RESPONSE:", "").strip()
            return capability_text, "Direct Response (Capabilities)", {"routing_method": "orchestrator_capability"}
        
        # Medical Claim Agent (support both variations)
        if "MEDICLAIM_AGENT" in agent_choice or "MEDICAL_CLAIM_AGENT" in agent_choice:
            logger.info("🔹 → Medical Claim Agent")
            try:
                claim_agent = create_medi_claim_agent(employee_data)
                query_with_context = f"{conversation_history}\n\nCURRENT QUERY: {query}" if conversation_history else query
                response = run_claim_query(claim_agent, employee_data, query_with_context)
                return response, "Medical Claim Agent", {
                    "data_source": "medi_claim_database",
                    "employee_id": employee_data.get("employee_id")
                }
            except Exception as e:
                logger.error(f"Medical claim error: {str(e)}")
                return (
                    f"Medical Claim system error: {str(e)}\n\nPlease contact HR for assistance.",
                    "Medical Claim Agent (Error)",
                    {"error": str(e)}
                )
        
        # Leave Agent
        elif "LEAVE_AGENT" in agent_choice:
            logger.info("🔹 → Leave Management Agent")
            try:
                leave_agent = create_leave_agent(employee_data)
                query_with_context = f"{conversation_history}\n\nCURRENT QUERY: {query}" if conversation_history else query
                response = run_leave_query(leave_agent, employee_data, query_with_context)
                return response, "Leave Management Agent", {"data_source": "employee_database"}
            except Exception as e:
                logger.error(f"Leave agent error: {str(e)}")
                return f"Leave system error: {str(e)}", "Leave Agent (Error)", {"error": str(e)}
        
        # IT Support Agent
        elif "IT_SUPPORT_AGENT" in agent_choice:
            logger.info("🔹 → IT Support Agent")
            if not ticket_wrapper or not ticket_wrapper.is_ready():
                return (
                    "IT Support system is currently unavailable.\n\nPlease contact IT directly:\nEmail: itsupport@shellkode.com",
                    "IT Support Agent (Unavailable)",
                    {"status": "unavailable"}
                )
            
            try:
                query_for_ticket = f"Previous conversation:\n{conversation_history}\n\nCurrent issue: {query}" if conversation_history else query
                response = ticket_wrapper.handle_query(
                    query=query_for_ticket,
                    employee_id=employee_data["employee_code"],
                    employee_name=employee_data["full_name"],
                    image_bytes=image_bytes,
                    image_filename=image_filename
                )
                return response, "IT Support Agent", {"data_source": "freshdesk_api"}
            except Exception as e:
                logger.error(f"IT Support error: {str(e)}")
                return f"Error creating ticket: {str(e)}", "IT Support Agent (Error)", {"error": str(e)}
        
        # Knowledge Base Agent
        elif "KNOWLEDGE_BASE_AGENT" in agent_choice:
            logger.info("🔹 → Knowledge Base Agent")
            try:
                query_with_context = f"{conversation_history}\n\nCURRENT QUERY: {query}" if conversation_history else query
                response = rag_agent(query_with_context, employee_name=employee_name)
                return response, "Knowledge Base Agent", {"data_source": "bedrock_knowledge_base"}
            except Exception as e:
                logger.error(f"Knowledge base error: {str(e)}")
                return f"Knowledge base error: {str(e)}", "Knowledge Base Agent (Error)", {"error": str(e)}
        
        # Fallback
        else:
            logger.warning(f"⚠️ Unclear routing, defaulting to Knowledge Base")
            query_with_context = f"{conversation_history}\n\nCURRENT QUERY: {query}" if conversation_history else query
            response = rag_agent(query_with_context, employee_name=employee_name)
            return response, "Knowledge Base Agent (Fallback)", {"data_source": "bedrock_knowledge_base"}
    
    except Exception as e:
        logger.error(f"Routing error: {str(e)}", exc_info=True)
        try:
            response = rag_agent(query, employee_name=employee_name)
            return response, "Knowledge Base Agent (Emergency)", {"error": str(e)}
        except:
            return "System error. Please contact support.", "System Error", {"error": str(e)}

# ============================================================================
# AUTHENTICATION ENDPOINT
# ============================================================================

class LoginRequest(BaseModel):
    email: str
    password: str

class LoginResponse(BaseModel):
    success: bool
    token: Optional[str] = None
    employee_data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

@app.post("/api/login", response_model=LoginResponse)
async def login_endpoint(request: LoginRequest):
    """
    🔐 AUTHENTICATION ENDPOINT
    
    Authenticates user and returns JWT token
    """
    
    logger.info(f"[LOGIN] Attempt from {request.email}")
    
    try:
        if not request.email or not request.password:
            return LoginResponse(
                success=False,
                error="Email and password are required"
            )
        
        employee_data = login_with_credentials(request.email, request.password)
        
        if employee_data is None or "error" in employee_data:
            logger.warning(f"[LOGIN] Failed for {request.email}")
            return LoginResponse(
                success=False,
                error="Invalid email or password"
            )
        
        employee_data["email"] = request.email
        token = create_access_token(employee_data)
        
        logger.info(f"[LOGIN] ✓ Success: {employee_data['full_name']}")
        
        return LoginResponse(
            success=True,
            token=token,
            employee_data={
                "employee_id": employee_data.get("employee_id"),
                "employee_code": employee_data.get("employee_code"),
                "full_name": employee_data.get("full_name"),
                "email": request.email,
                "department": employee_data.get("department"),
                "designation": employee_data.get("designation"),
                "date_of_joining": employee_data.get("date_of_joining"),
                "reporting_manager": employee_data.get("reporting_manager"),
            }
        )
    
    except Exception as e:
        logger.error(f"[LOGIN] Error: {str(e)}", exc_info=True)
        return LoginResponse(
            success=False,
            error=f"Authentication error: {str(e)}"
        )

# ============================================================================
# STREAMING CHAT ENDPOINT
# ============================================================================

async def stream_response(
    query: str,
    current_user: Dict[str, Any],
    session: ConversationSession,
    conversation_history: str,
    image_bytes: Optional[bytes] = None,
    image_filename: Optional[str] = None,
    request_id: str = ""
):
    """Generator function for streaming response with SSE"""
    
    try:
        # Add user message to history
        session.add_message("user", query)
        
        # Send initial metadata
        yield f"data: {json.dumps({'type': 'metadata', 'request_id': request_id, 'status': 'processing'})}\n\n"
        
        # Route query and get response
        response, agent_name, metadata = route_query(
            employee_data=current_user,
            query=query,
            conversation_history=conversation_history,
            image_bytes=image_bytes,
            image_filename=image_filename
        )
        
        # Stream the response in chunks
        chunk_size = 50  # Characters per chunk
        for i in range(0, len(response), chunk_size):
            chunk = response[i:i + chunk_size]
            yield f"data: {json.dumps({'type': 'content', 'chunk': chunk})}\n\n"
        
        # Add assistant response to history
        session.add_message("assistant", response, agent_used=agent_name)
        
        # Send final metadata
        final_data = {
            'type': 'done',
            'agent_used': agent_name,
            'session': {
                "session_id": session.session_id,
                "employee_code": current_user["employee_code"],
                "employee_name": current_user["full_name"],
                "email": current_user["email"],
                "department": current_user.get('department', 'N/A'),
                "designation": current_user.get('designation', 'N/A'),
                "message_count": len(session.messages),
                "session_age_minutes": round((datetime.now() - session.created_at).total_seconds() / 60, 2),
                "last_activity": session.last_activity.isoformat()
            },
            'metadata': {
                "request_id": request_id,
                "timestamp": datetime.now().isoformat(),
                "routing_method": "ai_orchestrator",
                "used_conversation_history": bool(conversation_history),
                "history_messages_used": len(session.messages[-6:]) if conversation_history else 0,
                "image_attached": image_bytes is not None,
                "authentication_method": "jwt_token",
                **metadata
            }
        }
        yield f"data: {json.dumps(final_data)}\n\n"
        
    except Exception as e:
        logger.error(f"[{request_id}] Streaming error: {str(e)}", exc_info=True)
        yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"

@app.post("/api/chat")
async def chat_endpoint(
    query: str = Form(..., description="Employee's question"),
    action: str = Form("chat", description="Action: 'chat' or 'clear_history'"),
    image: Optional[UploadFile] = File(None, description="Optional image for IT support"),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    💬 STREAMING CHAT ENDPOINT WITH JWT AUTH
    
    Supports all agents with Server-Sent Events (SSE):
    - Leave Management
    - IT Support (with image upload)
    - Medical Claims
    - Knowledge Base
    
    Response Format (SSE):
    - data: {"type": "metadata", "status": "processing"}
    - data: {"type": "content", "chunk": "..."}
    - data: {"type": "done", "agent_used": "...", "session": {...}}
    """
    
    request_id = f"REQ-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    email = current_user["email"]
    employee_code = current_user["employee_code"]
    employee_name = current_user["full_name"]
    
    logger.info(f"[{request_id}] Request from {employee_name}: action={action}")
    
    try:
        # Handle clear history
        if action == "clear_history":
            cleared = session_manager.clear_session(email)
            return {
                "success": True,
                "response": "Your conversation history has been cleared.",
                "agent_used": "System",
                "session": {
                    "employee_code": employee_code,
                    "employee_name": employee_name,
                    "email": email,
                    "cleared": cleared
                },
                "conversation_history": [],
                "metadata": {
                    "action": "clear_history",
                    "timestamp": datetime.now().isoformat()
                }
            }
        
        # Validate query
        if not query or not query.strip():
            return {
                "success": False,
                "error": "Query cannot be empty"
            }
        
        # Get or create session
        session = session_manager.get_or_create_session(
            email_id=email,
            employee_code=employee_code,
            employee_name=employee_name
        )
        conversation_history = session.get_context_for_ai(max_messages=6)
        
        logger.info(f"[{request_id}] Session: {session.session_id}, Messages: {len(session.messages)}")
        
        # Process image if provided
        image_bytes = None
        image_filename = None
        if image:
            try:
                image_bytes = await image.read()
                image_filename = image.filename
                logger.info(f"[{request_id}] Image: {image_filename} ({len(image_bytes)} bytes)")
            except Exception as e:
                logger.error(f"[{request_id}] Image error: {str(e)}")
        
        # Return streaming response
        return StreamingResponse(
            stream_response(
                query=query,
                current_user=current_user,
                session=session,
                conversation_history=conversation_history,
                image_bytes=image_bytes,
                image_filename=image_filename,
                request_id=request_id
            ),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no"
            }
        )
    
    except Exception as e:
        logger.error(f"[{request_id}] Error: {str(e)}", exc_info=True)
        return {
            "success": False,
            "error": f"Error processing request: {str(e)}"
        }

# ============================================================================
# STATUS ENDPOINTS
# ============================================================================

@app.get("/")
async def root():
    """API information"""
    return {
        "service": "Employee Assistant API",
        "version": "7.0.0 - STREAMING WITH JWT AUTH",
        "status": "online",
        
        "agents": [
            "Leave Management Agent",
            "IT Support Agent (Freshdesk)",
            "Medical Claim Agent",
            "Knowledge Base Agent (RAG)"
        ],
        
        "authentication": {
            "method": "jwt_token",
            "token_expiry": f"{TOKEN_EXPIRE_HOURS} hours",
            "usage": [
                "1. POST /api/login to get token",
                "2. Use token in Authorization header: Bearer <token>",
                "3. Call /api/chat for streaming responses"
            ]
        },
        
        "streaming": {
            "format": "Server-Sent Events (SSE)",
            "content_type": "text/event-stream",
            "event_types": [
                "metadata - Initial processing status",
                "content - Response chunks (streaming)",
                "done - Final metadata and session info",
                "error - Error information"
            ]
        },
        
        "endpoints": {
            "login": "POST /api/login - Get JWT token",
            "chat": "POST /api/chat - Streaming chat with all agents",
            "health": "GET /health - System status"
        },
        
        "documentation": "/docs"
    }

@app.get("/health")
async def health_check():
    """Health check with all agents"""
    return {
        "status": "healthy",
        "version": "7.0.0",
        "timestamp": datetime.now().isoformat(),
        "components": {
            "session_manager": "operational",
            "hr_orchestrator": "operational" if hr_orchestrator else "unavailable",
            "it_support": "operational" if (ticket_wrapper and ticket_wrapper.is_ready()) else "unavailable",
            "leave_management": "operational",
            "medical_claims": "operational",
            "knowledge_base": "operational",
            "streaming": "operational"
        }
    }

# ============================================================================
# RUN
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="localhost",
        port=8000,
        reload=False,
        log_level="info"
    )
