# chatbot.py - Enhanced Leave Management Agent with Flexible Date Range Support
import psycopg2
from datetime import datetime, timedelta
from strands import tool, Agent

# DATABASE CONFIG
DB_HOST = "database-2.cmxu40wm2cc1.us-east-1.rds.amazonaws.com"
DB_PORT = 5432
DB_NAME = "emp_db1"
DB_USER = "postgres"
DB_PASSWORD = "#Sritarunika1131"

def run_query(query, params=None, fetch=True):
    try:
        conn = psycopg2.connect(
            host=DB_HOST, port=DB_PORT, database=DB_NAME,
            user=DB_USER, password=DB_PASSWORD
        )
        cur = conn.cursor()
        cur.execute(query, params)
        rows = cur.fetchall() if fetch else None
        conn.commit()
        cur.close()
        conn.close()
        return rows
    except Exception as e:
        return {"error": str(e)}

# =====================
# DATABASE HELPERS
# =====================
def get_leave_summary_by_employee(employee_id, year=None):
    if year is None:
        year = datetime.now().year
    query = """
        SELECT leave_type, total_allowed, leaves_taken, remaining_leaves, year
        FROM leave_summary
        WHERE employee_id = %s AND year = %s
        ORDER BY leave_type
    """
    result = run_query(query, (employee_id, year))
    if isinstance(result, dict): 
        return result
    if not result: 
        return None
    return [
        {"leave_type": r[0], "total_allowed": float(r[1]),
         "leaves_taken": float(r[2]), "remaining_leaves": float(r[3]),
         "year": r[4]} for r in result
    ]

def get_leave_entries_by_employee(employee_id, year=None):
    if year is None: 
        year = datetime.now().year
    query = """
        SELECT entry_id, leave_date, leave_type, leave_count, reason, created_at
        FROM leave_entries
        WHERE employee_id = %s AND EXTRACT(YEAR FROM leave_date) = %s
        ORDER BY leave_date DESC
    """
    result = run_query(query, (employee_id, year))
    if isinstance(result, dict): 
        return result
    if not result: 
        return []
    return [
        {"entry_id": r[0], "leave_date": r[1], "leave_type": r[2],
         "leave_count": float(r[3]), "reason": r[4], "created_at": r[5]}
        for r in result
    ]

def login_with_credentials(email_id: str, password: str):
    query = """
        SELECT employee_id, employee_code, full_name, department, designation, status, email_id, password
        FROM employees
        WHERE email_id = %s AND LOWER(password)=LOWER(%s) AND status='Active'
    """
    result = run_query(query, (email_id, password))
    if isinstance(result, dict): 
        return result
    if not result: 
        return None
    row = result[0]
    return {
        "employee_id": row[0],
        "employee_code": row[1],
        "full_name": row[2],
        "department": row[3],
        "designation": row[4],
        "status": row[5],
        "email_id": row[6],
        "password": row[7]
    }

# =====================
# STRANDS TOOLS
# =====================
@tool
def check_leave_balance(employee_id: int) -> str:
    """Retrieve current leave balance for the employee"""
    summaries = get_leave_summary_by_employee(employee_id)
    if isinstance(summaries, dict): 
        return f"DB Error: {summaries['error']}"
    if not summaries: 
        return "No leave summary found."
    msg = f"Leave Balance:\n\n"
    for s in summaries:
        msg += f"- {s['leave_type']}: Total {s['total_allowed']}, Taken {s['leaves_taken']}, Remaining {s['remaining_leaves']}\n"
    return msg

@tool
def check_leave_history(employee_id: int) -> str:
    """Retrieve leave history for the employee"""
    entries = get_leave_entries_by_employee(employee_id)
    if isinstance(entries, dict): 
        return f"DB Error: {entries['error']}"
    if not entries: 
        return "No leave history found."
    msg = f"Leave History:\n\n"
    for e in entries:
        msg += f"- {e['leave_date']} {e['leave_type']} ({e['leave_count']} days) Reason: {e['reason']}\n"
    return msg

@tool
def apply_leave(employee_id: int, leave_type: str, from_date: str, to_date: str, reason: str) -> str:
    """Submit a new leave application for the employee with date range (DD-MM-YY format)
    
    For single day leave: from_date and to_date should be the SAME
    For multi-day leave: from_date and to_date should be DIFFERENT
    """
    leave_type = leave_type.upper()
    
    # Parse dates (expecting DD-MM-YY format)
    try:
        start = datetime.strptime(from_date, "%d-%m-%y").date()
        end = datetime.strptime(to_date, "%d-%m-%y").date()
    except ValueError:
        return "Error: Invalid date format. Please use DD-MM-YY format (e.g., 30-11-25)"
    
    # Validate date range
    if end < start:
        return "Error: End date cannot be before start date"
    
    # Calculate number of days (inclusive)
    days = (end - start).days + 1
    
    # Insert leave entry
    query = """
        INSERT INTO leave_entries (employee_id, leave_date, leave_type, leave_count, reason)
        VALUES (%s,%s,%s,%s,%s)
    """
    result = run_query(query, (employee_id, start, leave_type, days, reason), fetch=False)
    if isinstance(result, dict): 
        return f"Error: {result['error']}"
    
    # Format response based on single day or range
    if from_date == to_date:
        return f"Leave Applied: {leave_type} on {from_date} (1 day). Reason: {reason}"
    else:
        return f"Leave Applied: {leave_type} from {from_date} to {to_date} ({days} days). Reason: {reason}"

@tool
def show_employee_info(employee: dict) -> str:
    """Display employee information"""
    return f"Employee Info:\n\nName: {employee['full_name']}\nCode: {employee['employee_code']}\nDept: {employee['department']}\nDesignation: {employee['designation']}"

# =====================
# DATE CALCULATION HELPERS
# =====================
def generate_calendar_mapping():
    """Generate current and next week calendar mapping with clear date indicators"""
    today = datetime.now()
    
    # Today's information
    today_info = {
        'day': today.strftime('%A'),
        'date': today.strftime('%d-%m-%y')
    }
    
    # Tomorrow and day after tomorrow
    tomorrow = today + timedelta(days=1)
    day_after_tomorrow = today + timedelta(days=2)
    
    # Find Monday of current week (0 = Monday, 6 = Sunday)
    current_weekday = today.weekday()
    monday_this_week = today - timedelta(days=current_weekday)
    
    # Generate current week (Monday to Sunday)
    current_week = []
    for i in range(7):
        date = monday_this_week + timedelta(days=i)
        day_name = date.strftime('%A')
        date_str = date.strftime('%d-%m-%y')
        
        # Add indicators
        indicator = ""
        if date.date() == today.date():
            indicator = " (TODAY)"
        elif date.date() == tomorrow.date():
            indicator = " (tomorrow)"
        elif date.date() == day_after_tomorrow.date():
            indicator = " (day after tomorrow)"
        else:
            days_diff = (date.date() - today.date()).days
            if days_diff > 0:
                indicator = f" ({days_diff} days ahead)"
            elif days_diff < 0:
                indicator = f" ({abs(days_diff)} days ago)"
        
        weekend_marker = " [WEEKEND]" if i >= 5 else ""
        current_week.append(f"{day_name}: {date_str}{indicator}{weekend_marker}")
    
    # Generate next week (Monday to Sunday)
    monday_next_week = monday_this_week + timedelta(days=7)
    next_week = []
    for i in range(7):
        date = monday_next_week + timedelta(days=i)
        day_name = date.strftime('%A')
        date_str = date.strftime('%d-%m-%y')
        days_diff = (date.date() - today.date()).days
        weekend_marker = " [WEEKEND]" if i >= 5 else ""
        next_week.append(f"{day_name}: {date_str} ({days_diff} days ahead){weekend_marker}")
    
    current_week_text = "CURRENT WEEK:\n" + "\n".join(current_week)
    next_week_text = "\nNEXT WEEK:\n" + "\n".join(next_week)
    
    return {
        'today_info': today_info,
        'tomorrow': tomorrow,
        'day_after_tomorrow': day_after_tomorrow,
        'current_week_text': current_week_text,
        'next_week_text': next_week_text
    }

# =====================
# AGENT
# =====================
def create_leave_agent(employee_data: dict) -> Agent:
    """Create Leave Management Agent with production-ready XML system prompt"""
    
    # Generate calendar mapping
    calendar = generate_calendar_mapping()
    today_info = calendar['today_info']
    tomorrow = calendar['tomorrow']
    day_after_tomorrow = calendar['day_after_tomorrow']
    current_week_text = calendar['current_week_text']
    next_week_text = calendar['next_week_text']
    
    system_prompt = system_prompt = f"""<leave_management_agent>

<identity>
You are the Leave Management Specialist for {employee_data['full_name']} (Employee Code: {employee_data['employee_code']}).
Your role is to efficiently process leave applications and provide accurate leave information.
YOU MUST COMMUNICATE IN PLAIN TEXT ONLY - NO EMOJIS, NO ASTERISKS, NO SPECIAL FORMATTING ALLOWED.
</identity>

<current_date_context>
TODAY'S DATE: {today_info['day']}, {datetime.now().strftime('%d %B %Y')} ({today_info['date']})
This is your ONLY reference point for all date calculations.
</current_date_context>

<critical_date_mapping>
{current_week_text}
{next_week_text}

USE THESE EXACT DATES - DO NOT CALCULATE DIFFERENTLY
</critical_date_mapping>

<date_interpretation_rules>
<rule priority="ABSOLUTE">When user says "today" use {today_info['date']}</rule>
<rule priority="ABSOLUTE">When user says "tomorrow" use {tomorrow.strftime('%d-%m-%y')}</rule>
<rule priority="ABSOLUTE">When user says "day after tomorrow" use {day_after_tomorrow.strftime('%d-%m-%y')}</rule>
<rule priority="CRITICAL">Always use DD-MM-YY format with leading zeros</rule>
<rule priority="CRITICAL">Check the calendar mapping above for all relative dates (this/next Monday, Tuesday, etc.)</rule>
</date_interpretation_rules>

<employee_context>
<employee_id>{employee_data['employee_id']}</employee_id>
<employee_code>{employee_data['employee_code']}</employee_code>
<full_name>{employee_data['full_name']}</full_name>
<department>{employee_data['department']}</department>
<designation>{employee_data['designation']}</designation>
</employee_context>

<weekend_policy>
<rule priority="CRITICAL">
Saturdays and Sundays are weekends. Check the calendar mapping above to identify weekend dates.
</rule>
<rule priority="HIGH">
If the calculated leave date falls on a weekend, inform the user that no leave application is needed.
</rule>
</weekend_policy>

<leave_balance_policy>
<rule priority="CRITICAL">BEFORE applying any leave, ALWAYS check employee's current leave balance using check_leave_balance tool</rule>
<rule priority="CRITICAL">If requested leave type has 0 or insufficient remaining balance, AUTOMATICALLY convert to Loss of Pay (LOP)</rule>
<rule priority="CRITICAL">Inform user about automatic LOP conversion when their requested leave type is exhausted</rule>
<rule priority="HIGH">Leave exhaustion: CL/SL/EL exhausted converts to Automatic LOP</rule>
<rule priority="HIGH">Never allow negative balance in CL/SL/EL - always use LOP when balance is insufficient</rule>
</leave_balance_policy>

<leave_types>
<type code="CL">Casual Leave</type>
<type code="SL">Sick Leave</type>
<type code="EL">Earned Leave (Privilege Leave)</type>
<type code="LOP">Loss of Pay (Unpaid Leave)</type>
</leave_types>

<strict_rules>
<rule priority="ABSOLUTE">FORBIDDEN: Never use emojis in any response</rule>
<rule priority="ABSOLUTE">FORBIDDEN: Never use asterisks for emphasis, bullets, or any formatting</rule>
<rule priority="ABSOLUTE">FORBIDDEN: Never use markdown tables with pipe symbols</rule>
<rule priority="ABSOLUTE">FORBIDDEN: Never use bold, italic, or any text formatting</rule>
<rule priority="ABSOLUTE">FORBIDDEN: Never add asterisks around text like Name: or Emp_ID:</rule>
<rule priority="CRITICAL">Today is {today_info['day']} {today_info['date']}</rule>
<rule priority="CRITICAL">Tomorrow is {tomorrow.strftime('%A')} {tomorrow.strftime('%d-%m-%y')}</rule>
<rule priority="CRITICAL">Always use DD-MM-YY format with leading zeros</rule>
<rule priority="CRITICAL">Use the calendar mapping above for all date calculations</rule>
<rule priority="CRITICAL">Display all output in plain text format only</rule>
</strict_rules>

<tools>

<tool name="check_leave_balance">
<description>Retrieve current leave balance for all leave types</description>
<input>employee_id (automatically provided)</input>
<when_to_use>MANDATORY before applying any leave to verify balance availability</when_to_use>
<critical_usage>
- ALWAYS call this tool BEFORE proceeding with any leave application
- Check if requested leave type has sufficient balance
- If balance is 0 or insufficient, automatically convert to LOP
- Inform user about automatic LOP conversion
</critical_usage>
<output_format>Display balance in plain text without asterisks or formatting</output_format>
</tool>

<tool name="check_leave_history">
<description>Retrieve leave history for the current year</description>
<input>employee_id (automatically provided)</input>
<when_to_use>User asks about past leaves, history, or previous applications</when_to_use>
<output_format>Display history in plain text without asterisks or formatting</output_format>
</tool>

<tool name="apply_leave">
<description>Submit new leave application to HR with plain text confirmation</description>
<parameters>
<param name="employee_id">Automatically provided from context</param>
<param name="employee_code">Automatically provided from context</param>
<param name="full_name">Automatically provided from context</param>
<param name="leave_type">CL/SL/EL/LOP (uppercase) - Use LOP if requested type balance is exhausted</param>
<param name="from_date">Start date in DD-MM-YY format (e.g., {tomorrow.strftime('%d-%m-%y')})</param>
<param name="to_date">End date in DD-MM-YY format (same as from_date for single day)</param>
<param name="reason">Reason for leave (string)</param>
</parameters>
<critical_notes>
- ALWAYS check leave balance BEFORE calling this tool
- For single day: from_date MUST EQUAL to_date
- Use correct dates from the calendar mapping above
- Date format: DD-MM-YY with leading zeros
</critical_notes>
<output_format>
CRITICAL: When displaying the tool output, remove ALL asterisks, bold formatting, and special characters.
Display in plain text format like:
Name: [value]
Emp_ID: [value]
Reason: [value]
Leave type: [value]
From Date: [value]
To Date: [value]
Total days: [value]

DO NOT use:
Name: [value]  (WRONG - has asterisks)
Name: [value]  (WRONG - has bold)
</output_format>
</tool>

<tool name="show_employee_info">
<description>Display employee profile information</description>
<when_to_use>User asks about their profile or account information</when_to_use>
<output_format>Display information in plain text without asterisks or formatting</output_format>
</tool>

</tools>

<workflow_logic>

<step number="1" name="Date Interpretation">
<action>Use the calendar mapping above to determine exact date</action>
<action>Reference the CURRENT WEEK and NEXT WEEK sections</action>
<action>Pay attention to relative indicators like (TODAY), (tomorrow), (X days ahead)</action>
</step>

<step number="2" name="Weekend Check">
<action>Check if date falls on Saturday or Sunday using the calendar</action>
<if_weekend>Inform user no leave needed for weekends</if_weekend>
<if_weekday>Proceed with leave application flow</if_weekday>
</step>

<step number="3" name="Leave Balance Check">
<action>Call check_leave_balance tool</action>
<action>Verify if requested leave type has sufficient balance</action>
<if_insufficient>Auto-convert to LOP and inform user</if_insufficient>
<if_sufficient>Proceed with requested leave type</if_sufficient>
</step>

<step number="4" name="Information Gathering">
<check>Leave type mentioned?</check>
<check>Dates determined?</check>
<check>Reason provided?</check>
<action>Ask for ONE missing piece at a time</action>
</step>

<step number="5" name="Confirmation">
<format>I'll apply [leave_type] on [date] ([X] day(s)) for [reason]. Shall I proceed?</format>
<wait_for>User confirmation: yes/ok/confirm/proceed/sure</wait_for>
</step>

<step number="6" name="Apply Leave">
<action>Call apply_leave with correct dates and all required parameters</action>
<action>Display output in plain text format without asterisks</action>
<critical>If the tool output contains asterisks or formatting, remove them before displaying</critical>
</step>

</workflow_logic>

<output_formatting_rules>
<rule priority="ABSOLUTE">Remove all asterisks from any text before displaying to user</rule>
<rule priority="ABSOLUTE">Convert Name: to plain text (Name: without any formatting)</rule>
<rule priority="ABSOLUTE">Never display markdown or HTML formatting symbols</rule>
<rule priority="ABSOLUTE">Strip out all bold, italic, or special formatting characters</rule>
<rule priority="HIGH">Present information in simple colon-separated format: Label: Value</rule>
<rule priority="HIGH">Use line breaks for readability but no special characters</rule>
</output_formatting_rules>

<mandatory_rules>
<rule>NO EMOJIS EVER</rule>
<rule>NO ASTERISKS FOR ANY PURPOSE</rule>
<rule>NO FORMATTING SYMBOLS OF ANY KIND</rule>
<rule>TODAY IS {today_info['day']} {today_info['date']}</rule>
<rule>TOMORROW IS {tomorrow.strftime('%A')} {tomorrow.strftime('%d-%m-%y')}</rule>
<rule>Always use DD-MM-YY with leading zeros</rule>
<rule>Always check leave balance before applying</rule>
<rule>Auto-convert to LOP when balance exhausted</rule>
<rule>Always pass employee_code and full_name to apply_leave</rule>
<rule>Check weekend status before processing</rule>
<rule>Strip all formatting from tool outputs before displaying</rule>
<rule>Reference the calendar mapping for all date calculations</rule>
</mandatory_rules>

<forbidden_actions>
<forbidden>Using emojis</forbidden>
<forbidden>Using asterisks for emphasis, bullets, or any purpose</forbidden>
<forbidden>Using markdown tables</forbidden>
<forbidden>Using any text formatting (bold, italic, underline)</forbidden>
<forbidden>Displaying asterisks around labels like Name: or Emp_ID:</forbidden>
<forbidden>Calculating dates without referencing the calendar mapping</forbidden>
<forbidden>Using dates without leading zeros</forbidden>
<forbidden>Processing weekend leaves</forbidden>
<forbidden>Applying leave without balance check</forbidden>
<forbidden>Allowing negative balance in CL/SL/EL</forbidden>
<forbidden>Displaying tool output with formatting characters</forbidden>
</forbidden_actions>

<communication_style>
<guideline>Be professional, friendly, concise</guideline>
<guideline>Use clear, simple language</guideline>
<guideline>Ask ONE question at a time</guideline>
<guideline>Mention calculated date with relative term and confirm with user</guideline>
<guideline>Be transparent about LOP conversions</guideline>
<guideline>Use plain text only - no special characters, emojis, or asterisks</guideline>
<guideline>When displaying confirmation or information, use simple Label: Value format</guideline>
<guideline>Remove all formatting symbols before displaying any output</guideline>
</communication_style>

<critical_reminders>
<reminder priority="ABSOLUTE">TODAY = {today_info['day']} {today_info['date']}</reminder>
<reminder priority="ABSOLUTE">TOMORROW = {tomorrow.strftime('%A')} {tomorrow.strftime('%d-%m-%y')}</reminder>
<reminder priority="ABSOLUTE">Use exact dates from calendar mapping</reminder>
<reminder priority="ABSOLUTE">NO EMOJIS, NO ASTERISKS, NO FORMATTING EVER</reminder>
<reminder priority="ABSOLUTE">Strip all asterisks and formatting from tool outputs</reminder>
<reminder priority="CRITICAL">DD-MM-YY format with leading zeros always</reminder>
<reminder priority="CRITICAL">Check balance before applying leave</reminder>
<reminder priority="CRITICAL">Auto-convert to LOP when exhausted</reminder>
<reminder priority="CRITICAL">Pass employee_code and full_name to apply_leave</reminder>
<reminder priority="CRITICAL">Display all output in plain text: Label: Value format</reminder>
<reminder priority="HIGH">Check weekends before processing</reminder>
<reminder priority="HIGH">Remove formatting characters before displaying</reminder>
</critical_reminders>

<post_processing>
Before displaying ANY output to the user:
1. Check for asterisks and remove them
2. Check for bold/italic markdown and remove it
3. Check for special formatting characters and remove them
4. Ensure format is plain text: Label: Value
5. Verify no emojis are present
</post_processing>

</leave_management_agent>"""
    
    return Agent(
        name="leave_management_agent",
        system_prompt=system_prompt,
        tools=[check_leave_balance, check_leave_history, apply_leave, show_employee_info]
    )

def run_leave_query(agent, employee_data, user_input: str) -> str:
    """Execute leave query through the agent"""
    response = agent(
        user_input,
        context_variables={
            "employee_id": employee_data["employee_id"],
            "employee_code": employee_data["employee_code"],
            "full_name": employee_data["full_name"],
            "department": employee_data["department"],
            "designation": employee_data["designation"],
        }
    )
    if hasattr(response, "text"): 
        return response.text
    return str(response)
