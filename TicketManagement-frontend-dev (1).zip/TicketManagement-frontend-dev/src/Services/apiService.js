import axios from "axios";
import { BASE_URL, CHAT_ENDPOINT, RESET_ENDPOINT } from "../Configurations/config";

// Create axios instance with base configuration
const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// API service functions
export const chatService = {
  sendMessage: async (message, chatHistory = []) => {
    try {
      const requestData = {
        message: message,
        chat_history: chatHistory,
      };

      const response = await apiClient.post(CHAT_ENDPOINT, requestData);
      return response.data;
    } catch (error) {
      console.error("API Error:", error);
      throw error;
    }
  },
  resetConversation: async () => {
    try {
      const response = await apiClient.post(RESET_ENDPOINT);
      return response.data;
    } catch (error) {
      console.error("Reset API Error:", error);
      throw error;
    }
  },
};

export default apiClient;

