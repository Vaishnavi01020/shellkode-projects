export const BASE_URL = "http://34.202.203.203:8600";
export const CHAT_ENDPOINT = "/chat";
export const RESET_ENDPOINT = "/reset";
