import "./chatbot.css";
import { useState, useEffect, useRef, useLayoutEffect } from "react";
import botIcon from "../../assets/images/shellkode_logo.png";
import botChatIcon from "../../assets/images/shellkode_icon.png";
import sendIcon from "../../assets/images/send-icon.svg";
import resetIcon from "../../assets/images/reset_icon.png";
import { chatService } from "../../Services/apiService";

function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null);
  const dropdownRef = useRef(null);
  const textAreaRef = useRef(null);
  const chatEndRef = useRef(null);
  const [typing, setTyping] = useState(false);
  const [loader, setLoader] = useState(false);
  const [inputValue, setInputValue] = useState("");


  const [sessionConversation, setSessionConversation] = useState([
    {
      type: "SYSTEM",
      body: (
        <>
          <p>
            👩🏻‍💼 Hello and welcome to <strong>Shellkode</strong>! I'm your smart
            assistant—here to help you.
          </p>
          <p>Just type your question to get started:</p>
        </>
      ),
    },
  ]);

  useLayoutEffect(() => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      console.log("Media Devices supported");
    } else {
      console.log("Media Devices unsupported");
    }
  }, []);

  // Scroll chat to bottom whenever conversation or loader changes
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [sessionConversation, loader]);

  // Close dropdown when clicking outside
  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleReset = async () => {
    try {
      setLoader(true);
      await chatService.resetConversation();
      
      // Reset conversation to initial state
      setSessionConversation([
        {
          type: "SYSTEM",
          body: (
            <>
              <p>
                👩🏻‍💼 Hello and welcome to <strong>Shellkode</strong>! I'm your smart
                assistant—here to help you.
              </p>
              <p>Just type your question to get started:</p>
            </>
          ),
        },
      ]);
      setLoader(false);
    } catch (err) {
      console.error("Error resetting conversation:", err);
      setLoader(false);
      setSessionConversation((prev) => [
        ...prev,
        {
          type: "SYSTEM",
          body: "⚠️ Failed to reset conversation. Please try again.",
        },
      ]);
    }
  };

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      const message = event.target.value;
      if (!message) return;
      handleSendMessage(message, uploadedImage || null);
    }
  };

  const sendRequest = () => {
    if (!inputValue) return;
    const message = inputValue;
    handleSendMessage(message, uploadedImage || null);
  };

  const handleSendMessage = async (query) => {
    setLoader(true);
    setInputValue("");
    setTyping(true);

    const userRequest = {
      type: "USER",
      body: query,
    };
    setSessionConversation((prev) => [...prev, userRequest]);

    try {
      // Convert sessionConversation to chat_history format
      // Exclude the initial welcome message and only include actual conversation exchanges
      const chatHistory = sessionConversation
        .slice(1) // Skip the initial welcome message
        .map((msg) => {
          if (msg.type === "USER") {
            return {
              role: "user",
              content: typeof msg.body === "string" ? msg.body : String(msg.body),
            };
          } else if (msg.type === "SYSTEM") {
            // Only include SYSTEM messages that are strings (actual assistant responses)
            const content = typeof msg.body === "string" ? msg.body : "";
            if (content) {
              return {
                role: "assistant",
                content: content,
              };
            }
            return null;
          }
          return null;
        })
        .filter((msg) => msg !== null && msg.content); // Remove null and empty messages

      const response = await chatService.sendMessage(query, chatHistory);
      console.log("API Response:", response);

      setLoader(false);
      setTyping(false);

      // Handle the new response format: {response: string, status: string}
      if (response.status === "success" && response.response) {
        const assistantMessage = {
          type: "SYSTEM",
          body: response.response,
        };
        setSessionConversation((prev) => [...prev, assistantMessage]);
      } else {
        throw new Error("Invalid response format");
      }
    } catch (err) {
      console.error("Error sending message:", err);
      setLoader(false);
      setTyping(false);
      setSessionConversation((prev) => [
        ...prev,
        {
          type: "SYSTEM",
          body: "⚠️ Something went wrong. Please try again.",
        },
      ]);
    }
  };


  return (
    <>
      <div className="bot-header-container d-flex justify-between">
        <div className="d-flex gap-10 align-items-center ">
          <img width="195" height="27" src={botIcon} alt="Bot Logo" />
        </div>
        <div className="rcw-header-buttons-container">
          <div
            onClick={handleReset}
            className="button-container reset-container"
            title="Reset Conversation"
          >
            <img src={resetIcon} className="reset-button" alt="Reset" />
          </div>
        </div>
      </div>

      <div className="bot-main-container">
        {sessionConversation?.map((message, index) => (
          <div key={index}>
            {message.type === "SYSTEM" ? (
              <div className="d-flex align-center mT-15">
               
                  <img width="65" height="45" src={botChatIcon} alt="Bot" />
             
                <div className="bot-block">
                  <div className="bot-msg">
                    {typeof message.body === "string" ? (
                      <div
                        dangerouslySetInnerHTML={{ __html: message.body }}
                      />
                    ) : (
                      message.body
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="d-flex justify-end mT-15">
                <div className="user-block">
                  <div className="bot-msg">{message.body}</div>
                </div>
              </div>
            )}
          </div>
        ))}

        {loader && (
          <div className="d-flex align-center mT-25">
            <div className="icon-container">
              <img width="65" height="45" src={botChatIcon} alt="Bot" />
            </div>
            <div className="bot-block">
              <div className="bot-loader"></div>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      <div className="chat-footer-input-v1 d-flex">
        <div className="chat-input-v1 d-flex">
          <textarea
            ref={textAreaRef}
            type="text"
            placeholder={typing ? "Agent is typing..." : "Send a message"}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
            value={inputValue}
            disabled={typing}
            className="chat-input-box"
          />
        </div>
        <div className="chat-footer-send-icon">
          <img
            className="icon-add"
            src={sendIcon}
            alt="sendIcon"
            onClick={sendRequest}
          />
        </div>
      </div>

      <div className="row-v2">
        <p className="poweredBy">Powered by Shellkode</p>
      </div>
    </>
  );
}

export default Chatbot;
