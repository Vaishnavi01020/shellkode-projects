export var backendURL =
  "https://hepruftmt4.execute-api.ap-south-1.amazonaws.com/text2sql/";
