import "./chatbot.css";
import { useState, useEffect, useRef, useLayoutEffect } from "react";
import { backendURL } from "../../Configurations/config";
import botIcon from "../../assets/images/Biocon-Logo-Main.png";
import botChatIcon from "../../assets/images/biocon-chat-logo.png";
import closeIcon from "../../assets/images/close-white.svg";
import sendIcon from "../../assets/images/send-icon.svg";
import axios from "axios";

function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null);
  const dropdownRef = useRef(null);
  const textAreaRef = useRef(null);
  const chatEndRef = useRef(null);
  const [typing, setTyping] = useState(false);
  const [loader, setLoader] = useState(false);
  const [inputValue, setInputValue] = useState("");


  const [sessionId, setSessionId] = useState("");
  const [sessionConversation, setSessionConversation] = useState([
    {
      type: "SYSTEM",
      body: (
        <>
          <p>
            👩🏻‍💼 Hello and welcome to <strong>Biocon</strong>! I'm your smart
            assistant—here to help you explore products, manage your account,
            track orders, get support, and much more.
          </p>
          <p>Just type your question to get started:</p>
        </>
      ),
    },
  ]);

  useLayoutEffect(() => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      console.log("Media Devices supported");
    } else {
      console.log("Media Devices unsupported");
    }
  }, []);

  // Scroll chat to bottom whenever conversation or loader changes
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [sessionConversation, loader]);

  // Close dropdown when clicking outside
  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const closeBot = () => {
    window.parent.postMessage({ msg: "chatbotClose" }, "*");
  };

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      const message = event.target.value;
      if (!message) return;
      handleSendMessage(message, uploadedImage || null);
    }
  };

  const sendRequest = () => {
    if (!inputValue) return;
    const message = inputValue;
    handleSendMessage(message, uploadedImage || null);
  };

 const handleSendMessage = async (query) => {
  setLoader(true);
  setInputValue("");
  setTyping(true);

  const userRequest = {
    type: "USER",
    body: query,
  };
  setSessionConversation((prev) => [...prev, userRequest]);

  try {
    const request = {
      query: query,
      sessionId: sessionId,
    };

    const response = await axios.post(backendURL, request);
    console.log(response);

    setSessionId(response.data.session_id);
    setLoader(false);
    setTyping(false);

    const steps = response?.data?.steps || {};
    const formattedResult = steps?.formatted_result;
    const waitingForClarification = response?.data?.waiting_for_clarification;
    const lastQuestion = response?.data?.last_question;
    const newMessages = [];

    if (waitingForClarification) {
      if (lastQuestion) {
        newMessages.push({
          type: "SYSTEM",
          body: `🤔 ${lastQuestion}`,
        });
      }
    } else {
      if (formattedResult) {
        newMessages.push({
          type: "SYSTEM",
          body: formattedResult,
        });
      }
    }

    if (newMessages.length > 0) {
      setSessionConversation((prev) => [...prev, ...newMessages]);
    }

  } catch (err) {
    console.error("Error sending message:", err);
    setLoader(false);
    setTyping(false);
    setSessionConversation((prev) => [
      ...prev,
      {
        type: "SYSTEM",
        body: "⚠️ Something went wrong. Please try again.",
      },
    ]);
  }
};


  return (
    <>
      <div className="bot-header-container d-flex justify-between">
        <div className="d-flex gap-10 align-items-center ">
          <img className="header-image" src={botIcon} alt="Bot Logo" />
        </div>
        <div className="rcw-header-buttons-container">
          <div
            onClick={() => closeBot()}
            className="button-container close-container"
          >
            <img src={closeIcon} className="close-button" alt="Close" />
          </div>
        </div>
      </div>

      <div className="bot-main-container">
        {sessionConversation?.map((message, index) => (
          <div key={index}>
            {message.type === "SYSTEM" ? (
              <div className="d-flex align-center mT-15">
                <div className="icon-container">
                  <img className="bot-icon-size" src={botChatIcon} alt="Bot" />
                </div>
                <div className="bot-block">
                  <div className="bot-msg">
                    {typeof message.body === "string" ? (
                      <div
                        dangerouslySetInnerHTML={{ __html: message.body }}
                      />
                    ) : (
                      message.body
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="d-flex justify-end mT-15">
                <div className="user-block">
                  <div className="bot-msg">{message.body}</div>
                </div>
              </div>
            )}
          </div>
        ))}

        {loader && (
          <div className="d-flex align-center mT-25">
            <div className="icon-container">
              <img className="bot-icon-size" src={botChatIcon} alt="Bot" />
            </div>
            <div className="bot-block">
              <div className="bot-loader"></div>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      <div className="chat-footer-input-v1 d-flex">
        <div className="chat-input-v1 d-flex">
          <textarea
            ref={textAreaRef}
            type="text"
            placeholder={typing ? "Agent is typing..." : "Send a message"}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
            value={inputValue}
            disabled={typing}
            className="chat-input-box"
          />
        </div>
        <div className="chat-footer-send-icon">
          <img
            className="icon-add"
            src={sendIcon}
            alt="sendIcon"
            onClick={sendRequest}
          />
        </div>
      </div>

      <div className="row-v2">
        <p className="poweredBy">Powered by Shellkode</p>
      </div>
    </>
  );
}

export default Chatbot;
