import React, { useState, useEffect, lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { loader } from "./Utilities/loader.jsx";
import Chatbot from "./Components/chatbot/chatbot.jsx";

function App() {
  // Lifecycle hook - useEffect
  useEffect(() => {
    loader("stop");
  }, []);

  return (
    <div>
      <BrowserRouter>
        <div id="spinner-loader">
          <div className="spinner"></div>
        </div>

        <div>
          <Suspense fallback={<p className="loading">"Loading..."</p>}>
            <Routes>
              <Route path="/" element={<Chatbot />} />
            </Routes>
          </Suspense>
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;
