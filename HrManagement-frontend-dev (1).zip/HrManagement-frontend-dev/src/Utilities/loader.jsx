import "./loader.css";
export const loader = (state) => {
  const loader = document.getElementById("spinner-loader");
  if (state === "start") {
    loader.classList.remove("fadeOut");
  } else {
    loader.classList.add("fadeOut");
  }
};
