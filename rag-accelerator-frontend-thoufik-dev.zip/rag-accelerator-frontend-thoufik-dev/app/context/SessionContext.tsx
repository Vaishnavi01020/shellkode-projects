"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";

interface User {
    id?: string;
    username: string;
    email?: string;
}

interface SessionContextType {
    user: User | null;
    token: string | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    login: (token: string, userData: User) => void;
    logout: () => void;
}

const SessionContext = createContext<SessionContextType | undefined>(undefined);

export function SessionProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [token, setToken] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const router = useRouter();
    const pathname = usePathname();

    useEffect(() => {
        // Initialize session from localStorage on mount
        const storedToken = localStorage.getItem("session_token");
        const storedUser = localStorage.getItem("user");

        if (storedToken && storedUser) {
            try {
                setToken(storedToken);
                setUser(JSON.parse(storedUser));
            } catch (e) {
                console.error("Failed to parse user session", e);
                logout();
            }
        }

        setIsLoading(false);
    }, []);

    // Simple route protection logic
    useEffect(() => {
        if (isLoading) return;

        const isAuthRoute = pathname?.startsWith("/auth");

        // Protect internal routes (e.g., /chat)
        if (!token && !isAuthRoute && pathname !== "/") {
            router.push("/auth/login");
        }

        // Redirect authenticated users away from auth pages
        if (token && isAuthRoute) {
            router.push("/chat");
        }
    }, [token, pathname, isLoading, router]);

    const login = (newToken: string, userData: User) => {
        // Clear any KB- or chat-specific localStorage so a new user
        // never sees the previous user's saved form values.
        const keysToClear = [
            "kb_with_bda_kb_id",
            "kb_with_bda_kb_name",
            "kb_with_bda_index_name",
            "kb_with_bda_messages",
            "kb_without_bda_kb_id",
            "kb_without_bda_kb_name",
            "kb_without_bda_index_name",
            "kb_without_bda_messages",
            "rag_pipeline_messages",
        ];
        keysToClear.forEach((key) => localStorage.removeItem(key));

        localStorage.setItem("session_token", newToken);
        localStorage.setItem("user", JSON.stringify(userData));
        setToken(newToken);
        setUser(userData);
        router.push("/chat");
    };

    const logout = () => {
        localStorage.removeItem("session_token");
        localStorage.removeItem("user");
        // Also clear KB/chat-specific data so the next user
        // never sees the previous user's values.
        const keysToClear = [
            "kb_with_bda_kb_id",
            "kb_with_bda_kb_name",
            "kb_with_bda_index_name",
            "kb_with_bda_messages",
            "kb_without_bda_kb_id",
            "kb_without_bda_kb_name",
            "kb_without_bda_index_name",
            "kb_without_bda_messages",
            "rag_pipeline_messages",
        ];
        keysToClear.forEach((key) => localStorage.removeItem(key));

        setToken(null);
        setUser(null);
        router.push("/auth/login");
    };

    return (
        <SessionContext.Provider value={{ user, token, isAuthenticated: !!token, isLoading, login, logout }}>
            {children}
        </SessionContext.Provider>
    );
}

export function useSession() {
    const context = useContext(SessionContext);
    if (context === undefined) {
        throw new Error("useSession must be used within a SessionProvider");
    }
    return context;
}
