"use client";

import { useState, useRef, useEffect } from "react";
import { flushSync } from "react-dom";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Inter, Outfit } from "next/font/google";
import MarkdownMessage from "../components/MarkdownMessage";

const inter = Inter({ subsets: ["latin"] });
const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit" });

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
}

type LLMModel =
  | "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  | "us.anthropic.claude-3-5-sonnet-20241022-v2:0"
  | "us.anthropic.claude-3-5-haiku-20241022-v1:0"
  | "us.anthropic.claude-3-sonnet-20240229-v1:0"
  | "us.anthropic.claude-3-haiku-20240307-v1:0";

const MODEL_NAMES: Record<LLMModel, string> = {
  "us.anthropic.claude-3-7-sonnet-20250219-v1:0": "Claude 3.7 Sonnet",
  "us.anthropic.claude-3-5-sonnet-20241022-v2:0": "Claude 3.5 Sonnet",
  "us.anthropic.claude-3-5-haiku-20241022-v1:0": "Claude 3.5 Haiku",
  "us.anthropic.claude-3-sonnet-20240229-v1:0": "Claude 3 Sonnet",
  "us.anthropic.claude-3-haiku-20240307-v1:0": "Claude 3 Haiku",
};

export default function KBWithoutBDAPage() {
  const router = useRouter();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [selectedModel, setSelectedModel] = useState<LLMModel>(
    "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  );
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [user, setUser] = useState<any>(null);

  // Check authentication on mount and load KB without BDA specific data
  useEffect(() => {
    const token = localStorage.getItem("session_token");
    const userData = localStorage.getItem("user");

    if (!token || !userData) {
      router.push("/auth/login");
      return;
    }

    setUser(JSON.parse(userData));

    // Load KB without BDA specific chat history
    const savedMessages = localStorage.getItem("kb_without_bda_messages");
    if (savedMessages) {
      try {
        const parsed = JSON.parse(savedMessages);
        setMessages(parsed.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        })));
      } catch (e) {
        console.error("Failed to load KB without BDA messages:", e);
      }
    }

    // Load KB ID if previously created
    const savedKbId = localStorage.getItem("kb_without_bda_kb_id");
    if (savedKbId) {
      setCreatedKbId(savedKbId);
    }

    // Load index name if previously set
    const savedIndexName = localStorage.getItem("kb_without_bda_index_name");
    if (savedIndexName) {
      setIndexName(savedIndexName);
    }
  }, [router]);

  // Save KB without BDA messages to localStorage whenever they change
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem("kb_without_bda_messages", JSON.stringify(messages));
    }
  }, [messages]);

  // KB Creation form state (simplified - without BDA)
  const [kbName, setKbName] = useState("");
  const [s3Uri, setS3Uri] = useState("");
  const [indexName, setIndexName] = useState("");
  const [vectorStore, setVectorStore] = useState<"OPENSEARCH_SERVERLESS" | "S3_VECTORS">("OPENSEARCH_SERVERLESS");
  const [embeddingModel, setEmbeddingModel] = useState("amazon.titan-embed-text-v2:0");
  const [isCreating, setIsCreating] = useState(false);
  const [createStatus, setCreateStatus] = useState<string>("");
  const [createdKbId, setCreatedKbId] = useState<string>("");  // Track created KB ID

  // S3 Upload form state
  const [s3BucketName, setS3BucketName] = useState("");
  const [s3FolderPath, setS3FolderPath] = useState("");
  const [s3SelectedFiles, setS3SelectedFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string>("");

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const s3FileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleLogout = () => {
    localStorage.removeItem("session_token");
    localStorage.removeItem("user");
    router.push("/auth/login");
  };

  const handleCreateKB = async () => {
    if (!kbName.trim() || !s3Uri.trim() || !indexName.trim()) {
      setCreateStatus("Please fill in all required fields");
      return;
    }

    setIsCreating(true);
    setCreateStatus("Creating Knowledge Base...");

    try {
      const token = localStorage.getItem("session_token");
      const endpoint = vectorStore === "OPENSEARCH_SERVERLESS"
        ? "/knowledge-base/create/opensearch"
        : "/knowledge-base/create/s3-vectors";

      const params = new URLSearchParams({
        region: "us-east-1",
        kb_name: kbName,
        s3_uri: s3Uri,
        embedding_model: embeddingModel,
        parsing_strategy: "FOUNDATION_MODEL",
        chunking_strategy: "DEFAULT",
        index_name: indexName,
      });

      const response = await fetch(`http://localhost:8000${endpoint}?${params}`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      if (!response.ok) throw new Error("KB creation failed");

      const result = await response.json();
      setCreateStatus(`✓ Success! Knowledge Base created: ${result.knowledge_base_id}`);
      setCreatedKbId(result.knowledge_base_id);  // Store KB ID for queries

      // Store KB info in localStorage for this pipeline
      localStorage.setItem("kb_without_bda_kb_id", result.knowledge_base_id);
      localStorage.setItem("kb_without_bda_index_name", indexName.trim().toLowerCase());

      setKbName("");
      setS3Uri("");
      setIndexName("");
    } catch (error) {
      console.error("KB creation error:", error);
      setCreateStatus("✗ Error: Failed to create Knowledge Base");
    } finally {
      setIsCreating(false);
    }
  };

  const handleS3Upload = async () => {
    if (!s3BucketName.trim() || s3SelectedFiles.length === 0) {
      setUploadStatus("Please provide bucket name and select files");
      return;
    }

    setIsUploading(true);
    setUploadStatus("Uploading files to S3...");

    try {
      const token = localStorage.getItem("session_token");
      const formData = new FormData();
      formData.append("bucket_name", s3BucketName);
      if (s3FolderPath.trim()) {
        formData.append("s3_folder", s3FolderPath);
      }

      s3SelectedFiles.forEach((file) => {
        formData.append("files", file);
      });

      const response = await fetch("http://localhost:8000/upload", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) throw new Error("S3 upload failed");

      const result = await response.json();
      setUploadStatus(
        `✓ Success! Uploaded ${result.summary.successful} of ${result.summary.total} files to ${result.s3_location}`
      );

      setS3SelectedFiles([]);
      setS3BucketName("");
      setS3FolderPath("");
      if (s3FileInputRef.current) s3FileInputRef.current.value = "";
    } catch (error) {
      console.error("S3 upload error:", error);
      setUploadStatus("✗ Error: Failed to upload files to S3");
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    setCreateStatus("✗ Error: Failed to create Knowledge Base");
  } finally {
    setIsCreating(false);
  }
};

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  if (!input.trim() || isLoading) return;

  const userMessage: Message = {
    id: Date.now().toString(),
    role: "user",
    content: input,
    timestamp: new Date(),
  };

  setMessages((prev) => [...prev, userMessage]);
  setInput("");
  setIsLoading(true);

  const assistantMessageId = (Date.now() + 1).toString();
  const assistantMessage: Message = {
    id: assistantMessageId,
    role: "assistant",
    content: "",
    timestamp: new Date(),
    isStreaming: true,
  };

  setMessages((prev) => [...prev, assistantMessage]);

  try {
    const token = localStorage.getItem("session_token");
    const formData = new FormData();
    formData.append("query", userMessage.content);
    formData.append("llm_model", selectedModel);

    // Send index_name for KB without BDA pipeline
    const savedIndexName = localStorage.getItem("kb_without_bda_index_name");
    if (savedIndexName) {
      formData.append("index_name", savedIndexName);
    }

    const response = await fetch("http://localhost:8000/query", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Failed to get response: ${response.status}`);
    }

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    if (reader) {
      while (true) {
        const { done, value } = await reader.read();

        if (value) {
          buffer += decoder.decode(value, { stream: !done });
        }

        if (done) {
          buffer += decoder.decode();
        }

        const lines = buffer.split("\n");
        buffer = done ? "" : lines.pop() || "";

        for (const line of lines) {
          if (line.trim().startsWith("data: ")) {
            try {
              const jsonStr = line.trim().slice(6);
              if (!jsonStr) continue;
              const data = JSON.parse(jsonStr);

              if (data.event === "token" && data.text) {
                flushSync(() => {
                  setMessages((prev) =>
                    prev.map((msg) =>
                      msg.id === assistantMessageId
                        ? { ...msg, content: data.text, isStreaming: true }
                        : msg
                    )
                  );
                });
              }
            } catch (e) {
              console.error("Parse error:", e);
            }
          }
        }

        if (done) {
          setMessages((prev) =>
            prev.map((msg) =>
              msg.id === assistantMessageId
                ? { ...msg, isStreaming: false }
                : msg
            )
          );
          break;
        }
      }
    }
  } catch (error) {
    console.error("Error:", error);
    setMessages((prev) =>
      prev.map((msg) =>
        msg.id === assistantMessageId
          ? {
            ...msg,
            content: "Sorry, I encountered an error. Please try again.",
            isStreaming: false,
          }
          : msg
      )
    );
  } finally {
    setIsLoading(false);
  }
};

const handleKeyDown = (e: React.KeyboardEvent) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    handleSubmit(e as any);
  }
};

return (
  <div
    className={`${inter.className} ${outfit.variable} flex h-screen bg-white overflow-hidden`}
  >
    {/* Sidebar */}
    <aside
      className={`${sidebarOpen ? "w-80" : "w-0"
        } flex-shrink-0 border-r border-gray-200 bg-gray-50 transition-all duration-300 ease-in-out overflow-hidden`}
    >
      <div className="flex h-full w-80 flex-col p-4">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="font-[family-name:var(--font-outfit)] text-lg font-bold text-gray-900">
            Create KB Without BDA
          </h2>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto">
          <div>
            <label className="mb-2 block text-xs font-semibold text-gray-700">
              Knowledge Base Name *
            </label>
            <input
              type="text"
              value={kbName}
              onChange={(e) => setKbName(e.target.value)}
              placeholder="e.g., my-knowledge-base"
              className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              required
            />
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-gray-700">
              S3 Folder Name *
            </label>
            <input
              type="text"
              value={s3Uri}
              onChange={(e) => setS3Uri(e.target.value)}
              placeholder="e.g., documents/reports"
              className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              required
            />
            <p className="mt-1 text-xs text-gray-500">
              Example: FolderName/FileName
            </p>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-gray-700">
              Index Name *
            </label>
            <input
              type="text"
              value={indexName}
              onChange={(e) => setIndexName(e.target.value)}
              placeholder="e.g., my-index"
              className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              required
            />
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-gray-700">
              Vector Store
            </label>
            <select
              value={vectorStore}
              onChange={(e) => setVectorStore(e.target.value as any)}
              className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="OPENSEARCH_SERVERLESS">OpenSearch Serverless</option>
              <option value="S3_VECTORS">S3 Vectors</option>
            </select>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-gray-700">
              Embedding Model
            </label>
            <select
              value={embeddingModel}
              onChange={(e) => setEmbeddingModel(e.target.value)}
              className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option>Titan Text v2</option>
              <option value="cohere.embed-english-v3">Cohere English v3</option>
            </select>
          </div>

          <button
            onClick={handleCreateKB}
            disabled={isCreating || !kbName.trim() || !s3Uri.trim() || !indexName.trim()}
            className="w-full rounded-lg bg-blue-600 px-4 py-2.5 font-[family-name:var(--font-outfit)] text-sm font-semibold text-white transition-colors hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isCreating ? "Creating..." : "Create Knowledge Base"}
          </button>

          {createStatus && (
            <div
              className={`rounded-lg p-3 text-xs ${createStatus.startsWith("✓")
                  ? "bg-green-50 text-green-700"
                  : createStatus.startsWith("✗")
                    ? "bg-red-50 text-red-700"
                    : "bg-blue-50 text-blue-700"
                }`}
            >
              {createStatus}
            </div>
          )}

          <div className="rounded-lg bg-white p-3">
            <h3 className="mb-2 text-xs font-semibold text-gray-700">
              Simple Setup
            </h3>
            <p className="text-xs leading-relaxed text-gray-500">
              Quick KB creation with default settings and standard embedding models
            </p>
          </div>

          {/* Divider */}
          <div className="border-t border-gray-300 my-4"></div>

          {/* S3 Upload Section */}
          <div className="space-y-4">
            <h2 className="font-[family-name:var(--font-outfit)] text-lg font-bold text-gray-900">
              Upload to S3
            </h2>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                S3 Bucket Name *
              </label>
              <input
                type="text"
                value={s3BucketName}
                onChange={(e) => setS3BucketName(e.target.value)}
                placeholder="e.g., my-bucket"
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                required
              />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                S3 Folder Path (Optional)
              </label>
              <input
                type="text"
                value={s3FolderPath}
                onChange={(e) => setS3FolderPath(e.target.value)}
                placeholder="e.g., documents/reports"
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                Upload Files *
              </label>
              <input
                ref={s3FileInputRef}
                type="file"
                multiple
                onChange={(e) => {
                  if (e.target.files) {
                    const newFiles = Array.from(e.target.files);
                    setS3SelectedFiles(prev => [...prev, ...newFiles]);
                    if (s3FileInputRef.current) s3FileInputRef.current.value = "";
                  }
                }}
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm file:mr-4 file:rounded-md file:border-0 file:bg-blue-50 file:px-4 file:py-1 file:text-sm file:font-semibold file:text-blue-700 hover:file:bg-blue-100"
              />
              {s3SelectedFiles.length > 0 && (
                <div className="mt-2 space-y-1">
                  <p className="text-xs font-semibold text-gray-700">
                    {s3SelectedFiles.length} file(s) selected:
                  </p>
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {s3SelectedFiles.map((file, index) => (
                      <div key={index} className="flex items-center justify-between rounded bg-gray-50 px-2 py-1">
                        <span className="text-xs text-gray-600 truncate flex-1">{file.name}</span>
                        <button
                          onClick={() => setS3SelectedFiles(prev => prev.filter((_, i) => i !== index))}
                          className="ml-2 text-red-500 hover:text-red-700 text-xs font-semibold"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={handleS3Upload}
              disabled={isUploading || !s3BucketName.trim() || s3SelectedFiles.length === 0}
              className="w-full rounded-lg bg-purple-600 px-4 py-2.5 font-[family-name:var(--font-outfit)] text-sm font-semibold text-white transition-colors hover:bg-purple-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isUploading ? "Uploading..." : "Upload to S3"}
            </button>

            {uploadStatus && (
              <div
                className={`rounded-lg p-3 text-xs ${uploadStatus.startsWith("✓")
                    ? "bg-green-50 text-green-700"
                    : uploadStatus.startsWith("✗")
                      ? "bg-red-50 text-red-700"
                      : "bg-blue-50 text-blue-700"
                  }`}
              >
                {uploadStatus}
              </div>
            )}
          </div>
        </div>
      </div>
    </aside>

    {/* Main Chat Area */}
    <div className="flex flex-1 flex-col min-w-0">
      <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.push("/chat")}
              className="rounded-lg p-2 text-gray-600 transition-all hover:bg-gray-100 active:scale-95"
            >
              <svg
                className="h-5 w-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
            </button>
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="rounded-lg p-2 text-gray-600 transition-all hover:bg-gray-100 active:scale-95"
            >
              <svg
                className="h-5 w-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                {sidebarOpen ? (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M11 19l-7-7 7-7m8 14l-7-7 7-7"
                  />
                ) : (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                )}
              </svg>
            </button>
            <Image
              src="/logo.svg"
              alt="KB without BDA"
              width={120}
              height={32}
              className="h-7 w-auto"
            />
            <span className="text-sm font-semibold text-gray-600">KB without BDA</span>
          </div>

          <div className="flex items-center gap-3">
            {user && (
              <div className="hidden sm:flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-semibold">
                  {user.username.charAt(0).toUpperCase()}
                </div>
                <span className="text-sm font-medium text-gray-700">{user.username}</span>
              </div>
            )}

            <div className="relative">
              <button
                onClick={() => setShowModelDropdown(!showModelDropdown)}
                className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
              >
                <svg
                  className="h-4 w-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                  />
                </svg>
                {MODEL_NAMES[selectedModel]}
                <svg
                  className="h-4 w-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>

              {showModelDropdown && (
                <div className="absolute right-0 top-full z-10 mt-2 w-64 rounded-lg border border-gray-200 bg-white shadow-lg">
                  {Object.entries(MODEL_NAMES).map(([value, name]) => (
                    <button
                      key={value}
                      onClick={() => {
                        setSelectedModel(value as LLMModel);
                        setShowModelDropdown(false);
                      }}
                      className={`w-full px-4 py-2.5 text-left text-sm transition-colors hover:bg-gray-50 ${selectedModel === value
                          ? "bg-blue-50 font-semibold text-blue-700"
                          : "text-gray-700"
                        }`}
                    >
                      {name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => {
                setMessages([]);
                localStorage.removeItem("kb_without_bda_messages");
              }}
              className="rounded-lg border border-gray-300 bg-white px-4 py-1.5 font-[family-name:var(--font-outfit)] text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
            >
              New Chat
            </button>

            <button
              onClick={handleLogout}
              className="rounded-lg border border-red-300 bg-white px-4 py-1.5 font-[family-name:var(--font-outfit)] text-sm font-medium text-red-600 transition-colors hover:bg-red-50"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl px-4 py-8">
          {messages.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="mb-8 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400">
                <svg
                  className="h-8 w-8 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                  />
                </svg>
              </div>
              <h2 className="mb-2 font-[family-name:var(--font-outfit)] text-2xl font-bold text-gray-900">
                How can I help you today?
              </h2>
              <p className="text-sm text-gray-500">
                Ask me anything about your documents
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-4 ${message.role === "user" ? "justify-end" : "justify-start"
                    }`}
                >
                  {message.role === "assistant" && (
                    <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400">
                      <svg
                        className="h-5 w-5 text-white"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                        />
                      </svg>
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${message.role === "user"
                        ? "bg-blue-600 text-white"
                        : "bg-gray-100 text-gray-900"
                      }`}
                  >
                    {message.role === "user" ? (
                      <p className="whitespace-pre-wrap text-sm leading-relaxed">
                        {message.content}
                      </p>
                    ) : message.content === "" && message.isStreaming ? (
                      <div className="flex items-center gap-1 py-1">
                        <div
                          className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                          style={{ animationDelay: "0ms" }}
                        />
                        <div
                          className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                          style={{ animationDelay: "150ms" }}
                        />
                        <div
                          className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                          style={{ animationDelay: "300ms" }}
                        />
                      </div>
                    ) : (
                      <div className="text-sm leading-relaxed">
                        <MarkdownMessage content={message.content} />
                        {message.isStreaming && (
                          <span className="ml-0.5 inline-block h-4 w-[2px] animate-blink-cursor bg-gray-900" />
                        )}
                      </div>
                    )}
                  </div>
                  {message.role === "user" && (
                    <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-gray-800">
                      <svg
                        className="h-5 w-5 text-white"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                        />
                      </svg>
                    </div>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-gray-200 bg-white">
        <div className="mx-auto max-w-3xl px-4 py-4">
          <form onSubmit={handleSubmit} className="relative">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask me anything about your documents..."
              rows={1}
              className="w-full resize-none rounded-2xl border border-gray-300 bg-white px-4 py-3 pr-14 text-sm text-gray-900 placeholder-gray-400 transition-all focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              style={{ minHeight: "52px", maxHeight: "200px" }}
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="absolute bottom-3 right-3 flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white shadow-md transition-all hover:bg-blue-700 hover:shadow-lg hover:scale-105 active:scale-95 disabled:cursor-not-allowed disabled:bg-gray-300 disabled:shadow-none"
            >
              {isLoading ? (
                <svg
                  className="h-4 w-4 animate-spin"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
              ) : (
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
                </svg>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
);
}
