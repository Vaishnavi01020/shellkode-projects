"use client";

import { useState, useRef, useEffect } from "react";
import { flushSync } from "react-dom";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Inter, Outfit } from "next/font/google";
import { useSession } from "@/app/context/SessionContext";
import MarkdownMessage from "../components/MarkdownMessage";

const inter = Inter({ subsets: ["latin"] });
const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit" });

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
}

type LLMModel =
  | "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  | "us.anthropic.claude-3-5-sonnet-20241022-v2:0"
  | "us.anthropic.claude-3-5-haiku-20241022-v1:0"
  | "us.anthropic.claude-3-sonnet-20240229-v1:0"
  | "us.anthropic.claude-3-haiku-20240307-v1:0";

const MODEL_NAMES: Record<LLMModel, string> = {
  "us.anthropic.claude-3-7-sonnet-20250219-v1:0": "Claude 3.7 Sonnet",
  "us.anthropic.claude-3-5-sonnet-20241022-v2:0": "Claude 3.5 Sonnet",
  "us.anthropic.claude-3-5-haiku-20241022-v1:0": "Claude 3.5 Haiku",
  "us.anthropic.claude-3-sonnet-20240229-v1:0": "Claude 3 Sonnet",
  "us.anthropic.claude-3-haiku-20240307-v1:0": "Claude 3 Haiku",
};

export default function KBWithoutBDAPage() {
  const router = useRouter();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [selectedModel, setSelectedModel] = useState<LLMModel>(
    "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  );
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const { user, token, logout } = useSession();

  // KB selection state
  const [availableKBs, setAvailableKBs] = useState<Array<{ id: string, name: string }>>([]);
  const [selectedKBForChat, setSelectedKBForChat] = useState<string>("");
  const [showKBDropdown, setShowKBDropdown] = useState(false);
  const [kbSearchQuery, setKbSearchQuery] = useState("");

  // Delete KB state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [kbToDelete, setKbToDelete] = useState<string>("");
  const [isDeleting, setIsDeleting] = useState(false);

  // Check authentication on mount and load KB without BDA specific data
  useEffect(() => {
    // Load KB without BDA specific chat history
    const savedMessages = localStorage.getItem("kb_without_bda_messages");
    if (savedMessages) {
      try {
        const parsed = JSON.parse(savedMessages);
        setMessages(parsed.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        })));
      } catch (e) {
        console.error("Failed to load KB without BDA messages:", e);
      }
    }

    // Load KB ID if previously created
    const savedKbId = localStorage.getItem("kb_without_bda_kb_id");
    if (savedKbId) {
      setCreatedKbId(savedKbId);
    }

    // Fetch available Knowledge Bases (will validate saved KB name)
    if (token) {
      fetchAvailableKBs();
    }
  }, [router, token]);

  const fetchAvailableKBs = async () => {
    if (!token) {
      console.warn("Cannot fetch KBs: No authentication token available");
      return;
    }

    try {
      console.log("Fetching available KBs with token:", token.substring(0, 10) + "...");

      const response = await fetch("http://localhost:8000/knowledge-bases/list?region=us-east-1", {
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      console.log("KB list response status:", response.status);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ detail: "Unknown error" }));
        console.error("Failed to fetch KBs:", response.status, errorData);
        return;
      }

      if (response.ok) {
        const data = await response.json();

        // Handle different response formats
        let kbList = [];
        if (data.knowledge_bases && Array.isArray(data.knowledge_bases)) {
          kbList = data.knowledge_bases;
        } else if (Array.isArray(data)) {
          kbList = data;
        } else if (data.knowledgeBases && Array.isArray(data.knowledgeBases)) {
          kbList = data.knowledgeBases;
        }

        if (kbList.length > 0) {
          const kbs = kbList.map((kb: any) => ({
            id: kb.id || kb.knowledgeBaseId || kb.knowledge_base_id || "unknown",
            name: kb.name || kb.knowledgeBaseName || kb.knowledge_base_name || "Unnamed KB"
          }));
          setAvailableKBs(kbs);

          // Validate saved KB name - only set if it exists in the list
          const savedKbName = localStorage.getItem("kb_without_bda_kb_name");
          if (savedKbName) {
            const kbExists = kbs.some((kb: any) => kb.name === savedKbName);
            if (kbExists) {
              setSelectedKBForChat(savedKbName);
            } else {
              // KB doesn't exist anymore, clear it
              localStorage.removeItem("kb_without_bda_kb_name");
              setSelectedKBForChat("");
            }
          }
        }
      }
    } catch (error) {
      console.error("Error fetching Knowledge Bases:", error);
    }
  };

  // Save KB without BDA messages to localStorage whenever they change
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem("kb_without_bda_messages", JSON.stringify(messages));
    }
  }, [messages]);

  // KB Creation form state (simplified - without BDA)
  const [kbName, setKbName] = useState("");
  const [s3Uri, setS3Uri] = useState("");
  const [indexName, setIndexName] = useState("");
  const [indexAction, setIndexAction] = useState<"new" | "existing">("new");
  const [vectorStore, setVectorStore] = useState<"OPENSEARCH_SERVERLESS" | "S3_VECTORS">("OPENSEARCH_SERVERLESS");
  const [embeddingModel, setEmbeddingModel] = useState("amazon.titan-embed-text-v2:0");
  const [parsingStrategy, setParsingStrategy] = useState("BEDROCK_DEFAULT");
  const [chunkingStrategy, setChunkingStrategy] = useState("NONE");

  // Additional parameters
  const [datasourceName, setDatasourceName] = useState("");
  const [fixedMaxTokens, setFixedMaxTokens] = useState(300);
  const [fixedOverlapPercentage, setFixedOverlapPercentage] = useState(20);
  const [hierMaxParentTokens, setHierMaxParentTokens] = useState(1500);
  const [hierMaxChildTokens, setHierMaxChildTokens] = useState(300);
  const [hierOverlapTokens, setHierOverlapTokens] = useState(60);
  const [semanticBufferSize, setSemanticBufferSize] = useState(0);
  const [semanticBreakpointPercentile, setSemanticBreakpointPercentile] = useState(95);
  const [semanticMaxTokens, setSemanticMaxTokens] = useState(300);

  const [isCreating, setIsCreating] = useState(false);
  const [createStatus, setCreateStatus] = useState<string>("");
  const [createdKbId, setCreatedKbId] = useState<string>("");  // Track created KB ID

  // S3 Upload form state
  const [s3BucketName, setS3BucketName] = useState("");
  const [s3FolderPath, setS3FolderPath] = useState("");
  const [s3SelectedFiles, setS3SelectedFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string>("");

  // Create S3 Bucket state
  const [newBucketName, setNewBucketName] = useState("");
  const [newBucketRegion, setNewBucketRegion] = useState("us-east-1");
  const [isCreatingBucket, setIsCreatingBucket] = useState(false);
  const [bucketCreateStatus, setBucketCreateStatus] = useState<string>("");

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const s3FileInputRef = useRef<HTMLInputElement>(null);

  // Dropdown refs
  const kbDropdownRef = useRef<HTMLDivElement>(null);
  const modelDropdownRef = useRef<HTMLDivElement>(null);

  // Handle click outside to close dropdowns
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (kbDropdownRef.current && !kbDropdownRef.current.contains(event.target as Node)) {
        setShowKBDropdown(false);
      }
      if (modelDropdownRef.current && !modelDropdownRef.current.contains(event.target as Node)) {
        setShowModelDropdown(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleLogout = () => {
    logout();
  };

  const handleCreateKB = async () => {
    if (!kbName.trim() || !s3Uri.trim() || !indexName.trim()) {
      setCreateStatus("Please fill in all required fields");
      return;
    }

    setIsCreating(true);
    setCreateStatus("Creating Knowledge Base...");

    try {

      const endpoint = vectorStore === "OPENSEARCH_SERVERLESS"
        ? "/knowledge-base/create/opensearch"
        : "/knowledge-base/create/s3-vectors";

      const params = new URLSearchParams({
        region: "us-east-1",
        kb_name: kbName,
        s3_uri: s3Uri,
        embedding_model: embeddingModel,
        parsing_strategy: parsingStrategy,
        chunking_strategy: chunkingStrategy,
        index_action: indexAction,
        index_name: indexName,
      });

      if (datasourceName.trim()) {
        params.append("datasource_name", datasourceName.trim());
      }

      if (chunkingStrategy === "FIXED_SIZE") {
        params.append("fixed_max_tokens", fixedMaxTokens.toString());
        params.append("fixed_overlap_percentage", fixedOverlapPercentage.toString());  // Backend expects 'percentage'
      } else if (chunkingStrategy === "HIERARCHICAL") {
        params.append("hier_max_parent_tokens", hierMaxParentTokens.toString());
        params.append("hier_max_child_tokens", hierMaxChildTokens.toString());
        params.append("hier_overlap_tokens", hierOverlapTokens.toString());
      } else if (chunkingStrategy === "SEMANTIC") {
        params.append("semantic_buffer_size", semanticBufferSize.toString());
        params.append("semantic_breakpoint_percentile", semanticBreakpointPercentile.toString());  // Backend expects 'breakpoint_percentile'
        params.append("semantic_max_tokens", semanticMaxTokens.toString());
      }

      console.log("Creating KB with endpoint:", `http://localhost:8000${endpoint}`);
      console.log("KB creation params:", Object.fromEntries(params));

      const response = await fetch(`http://localhost:8000${endpoint}?${params}`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      console.log("KB creation response status:", response.status);
      console.log("KB creation response headers:", Object.fromEntries(response.headers.entries()));

      if (!response.ok) {
        // Try to get error details from response
        const responseText = await response.text();
        console.error("KB creation failed - Status:", response.status);
        console.error("KB creation failed - Response text:", responseText);
        
        let errorData: any = {};
        try {
          errorData = JSON.parse(responseText);
        } catch (e) {
          errorData = { detail: responseText || `HTTP ${response.status}: ${response.statusText}` };
        }
        
        console.error("KB creation failed - Parsed error:", errorData);
        setCreateStatus(`✗ Error: ${errorData.detail || errorData.message || `HTTP ${response.status}: ${response.statusText}`}`);
        setIsCreating(false);
        return;
      }

      const result = await response.json();
      console.log("KB created successfully:", result);
      setCreateStatus(`✓ Success! Knowledge Base created: ${result.knowledge_base_id}`);
      setCreatedKbId(result.knowledge_base_id);  // Store KB ID for queries

      // Store KB info in localStorage for this pipeline
      localStorage.setItem("kb_without_bda_kb_id", result.knowledge_base_id);
      localStorage.setItem("kb_without_bda_index_name", indexName.trim().toLowerCase());

      // Refresh KB dropdown so newly created KB appears
      fetchAvailableKBs();

      setKbName("");
      setS3Uri("");
      setIndexName("");
    } catch (error: any) {
      console.error("KB creation error:", error);
      setCreateStatus(`✗ Error: ${error.message || "Failed to create Knowledge Base"}`);
    } finally {
      setIsCreating(false);
    }
  };

  const handleS3Upload = async () => {
    if (!s3BucketName.trim() || s3SelectedFiles.length === 0) {
      setUploadStatus("Please provide bucket name and select files");
      return;
    }

    setIsUploading(true);
    setUploadStatus("Uploading files to S3...");

    try {

      const formData = new FormData();
      formData.append("bucket_name", s3BucketName);
      if (s3FolderPath.trim()) {
        formData.append("s3_folder", s3FolderPath);
      }

      s3SelectedFiles.forEach((file) => {
        formData.append("files", file);
      });

      const response = await fetch("http://localhost:8000/upload", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        setUploadStatus("✗ Error: S3 upload failed");
        setIsUploading(false);
        return;
      }

      const result = await response.json();
      setUploadStatus(
        `✓ Success! Uploaded ${result.summary.successful} of ${result.summary.total} files to ${result.s3_location}`
      );

      setS3SelectedFiles([]);
      setS3BucketName("");
      setS3FolderPath("");
      if (s3FileInputRef.current) s3FileInputRef.current.value = "";
    } catch (error) {
      console.error("S3 upload error:", error);
      setUploadStatus("✗ Error: Failed to upload files to S3");
    } finally {
      setIsUploading(false);
    }
  };

  const handleCreateBucket = async () => {
    if (!newBucketName.trim()) {
      setBucketCreateStatus("Please enter a bucket name");
      return;
    }

    setIsCreatingBucket(true);
    setBucketCreateStatus("Creating S3 bucket...");

    try {
      const response = await fetch("http://localhost:8000/s3/buckets", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          bucket_name: newBucketName.trim(),
          region: newBucketRegion,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        setBucketCreateStatus(`✗ Error: ${errorData.detail || "Bucket creation failed"}`);
        return;
      }

      const result = await response.json();
      setBucketCreateStatus(`✓ Bucket "${newBucketName}" created successfully!`);
      // Pre-fill the upload bucket name for convenience
      setS3BucketName(newBucketName.trim());
      setNewBucketName("");
    } catch (error) {
      setBucketCreateStatus("✗ Error: Failed to create S3 bucket");
    } finally {
      setIsCreatingBucket(false);
    }
  };

  const handleDeleteKB = async () => {
    if (!kbToDelete) return;

    setIsDeleting(true);

    try {
      // Find the KB ID from the available KBs list
      const kbEntry = availableKBs.find(kb => kb.name === kbToDelete);

      const params = new URLSearchParams({
        kb_name: kbToDelete,
        region: "us-east-1",
        delete_data_sources: "true",
      });

      // Step 1: Delete from AWS Bedrock
      const response = await fetch(`http://localhost:8000/knowledge-base/delete?${params}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        alert(`Failed to delete KB: ${errorData.detail || "Unknown error"}`);
        setIsDeleting(false);
        return;
      }

      const result = await response.json();

      // Step 2: Also remove from chat_storage (PostgreSQL) using KB ID
      if (kbEntry?.id) {
        await fetch(`http://localhost:8000/knowledge-bases/${kbEntry.id}`, {
          method: "DELETE",
          headers: { "Authorization": `Bearer ${token}` },
        }).catch(() => {}); // Non-fatal if this fails
      }

      alert(`✓ ${result.message}`);

      // Refresh KB list
      fetchAvailableKBs();

      // Clear selection if deleted KB was selected
      if (selectedKBForChat === kbToDelete) {
        setSelectedKBForChat("");
        localStorage.removeItem("kb_without_bda_kb_name");
      }

      setShowDeleteConfirm(false);
      setKbToDelete("");
    } catch (error) {
      alert("✗ Error: Failed to delete Knowledge Base");
    } finally {
      setIsDeleting(false);
    }
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    const assistantMessageId = (Date.now() + 1).toString();
    const assistantMessage: Message = {
      id: assistantMessageId,
      role: "assistant",
      content: "",
      timestamp: new Date(),
      isStreaming: true,
    };

    setMessages((prev) => [...prev, assistantMessage]);

    try {


      // Get KB name from selected dropdown or localStorage
      const kbNameToUse = selectedKBForChat || localStorage.getItem("kb_without_bda_kb_name") || "";

      // Use /chat/stream endpoint with kb_name in request body
      const requestBody = {
        kb_name: kbNameToUse,
        query: userMessage.content
      };

      const response = await fetch("http://localhost:8000/chat/stream", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === assistantMessageId
              ? {
                ...msg,
                content: `Failed to get response: ${response.status}`,
                isStreaming: false,
              }
              : msg
          )
        );
        setIsLoading(false);
        return;
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let accumulatedContent = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();

          if (value) {
            buffer += decoder.decode(value, { stream: !done });
          }

          if (done) {
            buffer += decoder.decode();
          }

          const lines = buffer.split("\n");
          buffer = done ? "" : lines.pop() || "";

          for (const line of lines) {
            if (line.trim().startsWith("data: ")) {
              try {
                const jsonStr = line.trim().slice(6);
                if (!jsonStr || jsonStr === "[DONE]") continue;
                const data = JSON.parse(jsonStr);

                // Backend sends full accumulated text in each event
                if (data.text) {
                  accumulatedContent += data.text;
                  flushSync(() => {
                    setMessages((prev) =>
                      prev.map((msg) =>
                        msg.id === assistantMessageId
                          ? { ...msg, content: accumulatedContent, isStreaming: true }
                          : msg
                      )
                    );
                  });
                } else if (data.error) {
                  setMessages((prev) =>
                    prev.map((msg) =>
                      msg.id === assistantMessageId
                        ? {
                          ...msg,
                          content: data.error,
                          isStreaming: false,
                        }
                        : msg
                    )
                  );
                  setIsLoading(false);
                  return;
                }
              } catch (e: any) {
                if (e.message && e.message !== "Unexpected end of JSON input") {
                  console.error("Parse error:", e);
                }
              }
            }
          }

          if (done) {
            setMessages((prev) =>
              prev.map((msg) =>
                msg.id === assistantMessageId
                  ? { ...msg, isStreaming: false }
                  : msg
              )
            );
            break;
          }
        }
      }
    } catch (error: any) {
      console.error("Error:", error);
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMessageId
            ? {
              ...msg,
              content: error.message || "Sorry, I encountered an error. Please try again.",
              isStreaming: false,
            }
            : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any);
    }
  };

  return (
    <div
      className={`${inter.className} ${outfit.variable} flex h-screen bg-white overflow-hidden`}
    >
      {/* Sidebar */}
      <aside
        className={`${sidebarOpen ? "w-80" : "w-0"
          } flex-shrink-0 border-r border-gray-200 bg-gray-50 transition-all duration-300 ease-in-out overflow-hidden`}
      >
        <div className="flex h-full w-80 flex-col p-4">
          <div className="mb-6 flex items-center justify-between">
            <h2 className="font-[family-name:var(--font-outfit)] text-lg font-bold text-gray-900">
              Create KB Without BDA
            </h2>
          </div>

          <div className="flex-1 space-y-4 overflow-y-auto">
            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                Knowledge Base Name *
              </label>
              <input
                type="text"
                value={kbName}
                onChange={(e) => setKbName(e.target.value)}
                placeholder="e.g., my-knowledge-base"
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                required
              />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                S3 Folder Name *
              </label>
              <input
                type="text"
                value={s3Uri}
                onChange={(e) => setS3Uri(e.target.value)}
                placeholder="e.g., documents/reports"
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                required
              />
              <p className="mt-1 text-xs text-gray-500">
                Example: FolderName/FileName
              </p>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                Index Action *
              </label>
              <div className="flex gap-4">
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    value="new"
                    checked={indexAction === "new"}
                    onChange={(e) => setIndexAction(e.target.value as "new" | "existing")}
                    className="mr-2"
                  />
                  <span className="text-sm text-gray-700">Create New Index</span>
                </label>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    value="existing"
                    checked={indexAction === "existing"}
                    onChange={(e) => setIndexAction(e.target.value as "new" | "existing")}
                    className="mr-2"
                  />
                  <span className="text-sm text-gray-700">Use Existing Index</span>
                </label>
              </div>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                Index Name *
              </label>
              <input
                type="text"
                value={indexName}
                onChange={(e) => setIndexName(e.target.value)}
                placeholder={indexAction === "new" ? "index-new" : "existing-index"}
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                required
              />
              <p className="mt-1 text-xs text-gray-500">
                {indexAction === "new"
                  ? "Enter a name for the new index to be created"
                  : "Enter the name of an existing index"}
              </p>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                Data Source Name (Optional)
              </label>
              <input
                type="text"
                value={datasourceName}
                onChange={(e) => setDatasourceName(e.target.value)}
                placeholder="Defaults to datasource"
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                Vector Store
              </label>
              <select
                value={vectorStore}
                onChange={(e) => setVectorStore(e.target.value as any)}
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              >
                <option value="OPENSEARCH_SERVERLESS">OpenSearch Serverless</option>
                <option value="S3_VECTORS">S3 Vectors</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                Embedding Model
              </label>
              <select
                value={embeddingModel}
                onChange={(e) => setEmbeddingModel(e.target.value)}
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              >
                <option value="amazon.titan-embed-text-v2:0">Titan Text v2</option>
                <option value ="amazon.nova-2-multimodal-embeddings-v1:0">Nova 2 Multimodel</option>
                <option value="amazon.titan-embed-text-v1">Titan Text v1</option>
                <option value="amazon.nova-2-multimodal-embeddings-v1:0">Nova Multimodal v2</option>
                <option value="cohere.embed-english-v3">Cohere English v3</option>
                <option value="cohere.embed-multilingual-v3">Cohere Multilingual v3</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                Parsing Strategy
              </label>
              <select
                value={parsingStrategy}
                onChange={(e) => setParsingStrategy(e.target.value)}
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              >
                <option value="BEDROCK_DEFAULT">Bedrock Default</option>
                <option value="BEDROCK_FOUNDATION_MODEL">Bedrock Foundation Model</option>
                <option value="BEDROCK_DATA_AUTOMATION">Bedrock Data Automation</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">
                Chunking Strategy
              </label>
              <select
                value={chunkingStrategy}
                onChange={(e) => setChunkingStrategy(e.target.value)}
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              >
                <option value="NONE">None</option>
                <option value="DEFAULT">Default</option>
                <option value="FIXED_SIZE">Fixed Size</option>
                <option value="HIERARCHICAL">Hierarchical</option>
                <option value="SEMANTIC">Semantic</option>
              </select>
            </div>

            {/* FIXED_SIZE Parameters */}
            {chunkingStrategy === "FIXED_SIZE" && (
              <div className="space-y-3 rounded-lg bg-blue-50 p-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-700">
                    Max Tokens (20-8192)
                  </label>
                  <input
                    type="number"
                    min="20"
                    max="8192"
                    value={fixedMaxTokens}
                    onChange={(e) => setFixedMaxTokens(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-700">
                    Overlap Percentage (1-99)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="99"
                    value={fixedOverlapPercentage}
                    onChange={(e) => setFixedOverlapPercentage(Math.min(99, Math.max(1, Number(e.target.value) || 1)))}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>
            )}

            {/* HIERARCHICAL Parameters */}
            {chunkingStrategy === "HIERARCHICAL" && (
              <div className="space-y-3 rounded-lg bg-blue-50 p-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-700">
                    Parent Max Tokens (1-8192)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="8192"
                    value={hierMaxParentTokens}
                    onChange={(e) => setHierMaxParentTokens(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-700">
                    Child Max Tokens (1-8192)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="8192"
                    value={hierMaxChildTokens}
                    onChange={(e) => setHierMaxChildTokens(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-700">
                    Overlap Tokens (≥1)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={hierOverlapTokens}
                    onChange={(e) => setHierOverlapTokens(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>
            )}

            {/* SEMANTIC Parameters */}
            {chunkingStrategy === "SEMANTIC" && (
              <div className="space-y-3 rounded-lg bg-blue-50 p-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-700">
                    Buffer Size (0-1)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="1"
                    step="0.01"
                    value={semanticBufferSize}
                    onChange={(e) => setSemanticBufferSize(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-700">
                    Threshold (50-99)
                  </label>
                  <input
                    type="number"
                    min="50"
                    max="99"
                    value={semanticBreakpointPercentile}
                    onChange={(e) => setSemanticBreakpointPercentile(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-gray-700">
                    Max Tokens (20-8192)
                  </label>
                  <input
                    type="number"
                    min="20"
                    max="8192"
                    value={semanticMaxTokens}
                    onChange={(e) => setSemanticMaxTokens(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>
            )}

            <button
              onClick={handleCreateKB}
              disabled={isCreating || !kbName.trim() || !s3Uri.trim() || !indexName.trim()}
              className="w-full rounded-lg bg-blue-600 px-4 py-2.5 font-[family-name:var(--font-outfit)] text-sm font-semibold text-white transition-colors hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isCreating ? "Creating..." : "Create Knowledge Base"}
            </button>

            {createStatus && (
              <div
                className={`rounded-lg p-3 text-xs ${createStatus.startsWith("✓")
                  ? "bg-green-50 text-green-700"
                  : createStatus.startsWith("✗")
                    ? "bg-red-50 text-red-700"
                    : "bg-blue-50 text-blue-700"
                  }`}
              >
                {createStatus}
              </div>
            )}

            <div className="rounded-lg bg-white p-3">
              <h3 className="mb-2 text-xs font-semibold text-gray-700">
                Simple Setup
              </h3>
              <p className="text-xs leading-relaxed text-gray-500">
                Quick KB creation with default settings and standard embedding models
              </p>
            </div>

            {/* Divider */}
            <div className="border-t border-gray-300 my-4"></div>

            {/* Create S3 Bucket Section */}
            <div className="space-y-4">
              <h2 className="font-[family-name:var(--font-outfit)] text-lg font-bold text-gray-900">
                Create S3 Bucket
              </h2>

              <div>
                <label className="mb-2 block text-xs font-semibold text-gray-700">
                  Bucket Name *
                </label>
                <input
                  type="text"
                  value={newBucketName}
                  onChange={(e) => setNewBucketName(e.target.value)}
                  placeholder="e.g., my-rag-bucket"
                  className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="mb-2 block text-xs font-semibold text-gray-700">
                  Region
                </label>
                <select
                  value={newBucketRegion}
                  onChange={(e) => setNewBucketRegion(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                >
                  <option value="us-east-1">us-east-1</option>
                  <option value="us-east-2">us-east-2</option>
                  <option value="us-west-1">us-west-1</option>
                  <option value="us-west-2">us-west-2</option>
                  <option value="ap-south-1">ap-south-1</option>
                  <option value="ap-southeast-1">ap-southeast-1</option>
                  <option value="eu-west-1">eu-west-1</option>
                </select>
              </div>

              <button
                onClick={handleCreateBucket}
                disabled={isCreatingBucket || !newBucketName.trim()}
                className="w-full rounded-lg bg-green-600 px-4 py-2.5 font-[family-name:var(--font-outfit)] text-sm font-semibold text-white transition-colors hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isCreatingBucket ? "Creating..." : "Create S3 Bucket"}
              </button>

              {bucketCreateStatus && (
                <div
                  className={`rounded-lg p-3 text-xs ${bucketCreateStatus.startsWith("✓")
                    ? "bg-green-50 text-green-700"
                    : bucketCreateStatus.startsWith("✗")
                      ? "bg-red-50 text-red-700"
                      : "bg-blue-50 text-blue-700"
                    }`}
                >
                  {bucketCreateStatus}
                </div>
              )}
            </div>

            {/* Divider */}
            <div className="border-t border-gray-300 my-4"></div>

            {/* S3 Upload Section */}
            <div className="space-y-4">
              <h2 className="font-[family-name:var(--font-outfit)] text-lg font-bold text-gray-900">
                Upload to S3
              </h2>

              <div>
                <label className="mb-2 block text-xs font-semibold text-gray-700">
                  S3 Bucket Name *
                </label>
                <input
                  type="text"
                  value={s3BucketName}
                  onChange={(e) => setS3BucketName(e.target.value)}
                  placeholder="e.g., my-bucket"
                  className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  required
                />
              </div>

              <div>
                <label className="mb-2 block text-xs font-semibold text-gray-700">
                  S3 Folder Path (Optional)
                </label>
                <input
                  type="text"
                  value={s3FolderPath}
                  onChange={(e) => setS3FolderPath(e.target.value)}
                  placeholder="e.g., documents/reports"
                  className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="mb-2 block text-xs font-semibold text-gray-700">
                  Upload Files *
                </label>
                <input
                  ref={s3FileInputRef}
                  type="file"
                  multiple
                  onChange={(e) => {
                    if (e.target.files) {
                      const newFiles = Array.from(e.target.files);
                      setS3SelectedFiles(prev => [...prev, ...newFiles]);
                      if (s3FileInputRef.current) s3FileInputRef.current.value = "";
                    }
                  }}
                  className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm file:mr-4 file:rounded-md file:border-0 file:bg-blue-50 file:px-4 file:py-1 file:text-sm file:font-semibold file:text-blue-700 hover:file:bg-blue-100"
                />
                {s3SelectedFiles.length > 0 && (
                  <div className="mt-2 space-y-1">
                    <p className="text-xs font-semibold text-gray-700">
                      {s3SelectedFiles.length} file(s) selected:
                    </p>
                    <div className="max-h-32 overflow-y-auto space-y-1">
                      {s3SelectedFiles.map((file, index) => (
                        <div key={index} className="flex items-center justify-between rounded bg-gray-50 px-2 py-1">
                          <span className="text-xs text-gray-600 truncate flex-1">{file.name}</span>
                          <button
                            onClick={() => setS3SelectedFiles(prev => prev.filter((_, i) => i !== index))}
                            className="ml-2 text-red-500 hover:text-red-700 text-xs font-semibold"
                          >
                            ✕
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <button
                onClick={handleS3Upload}
                disabled={isUploading || !s3BucketName.trim() || s3SelectedFiles.length === 0}
                className="w-full rounded-lg bg-purple-600 px-4 py-2.5 font-[family-name:var(--font-outfit)] text-sm font-semibold text-white transition-colors hover:bg-purple-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isUploading ? "Uploading..." : "Upload to S3"}
              </button>

              {uploadStatus && (
                <div
                  className={`rounded-lg p-3 text-xs ${uploadStatus.startsWith("✓")
                    ? "bg-green-50 text-green-700"
                    : uploadStatus.startsWith("✗")
                      ? "bg-red-50 text-red-700"
                      : "bg-blue-50 text-blue-700"
                    }`}
                >
                  {uploadStatus}
                </div>
              )}
            </div>
          </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <div className="flex flex-1 flex-col min-w-0">
        <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="rounded-lg p-2 text-gray-600 transition-all hover:bg-gray-100 active:scale-95"
              >
                <svg
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  {sidebarOpen ? (
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M11 19l-7-7 7-7m8 14l-7-7 7-7"
                    />
                  ) : (
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  )}
                </svg>
              </button>
              <span className="text-sm font-semibold text-gray-600">KB without BDA</span>
            </div>

            <div className="flex items-center gap-3">
              {user && (
                <div className="hidden sm:flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-semibold">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-sm font-medium text-gray-700">{user.username}</span>
                </div>
              )}

              {/* Knowledge Base Selection Dropdown */}
              <div className="relative" ref={kbDropdownRef}>
                <button
                  onClick={() => setShowKBDropdown(!showKBDropdown)}
                  className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                >
                  <svg
                    className="h-4 w-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
                    />
                  </svg>
                  {selectedKBForChat || "Select KB"}
                  <svg
                    className="h-4 w-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>

                {showKBDropdown && (
                  <div className="absolute right-0 top-full z-10 mt-2 w-72 rounded-lg border border-gray-200 bg-white shadow-lg">
                    {/* Clear Selection Option */}
                    {selectedKBForChat && (
                      <div className="border-b border-gray-200 p-3">
                        <button
                          onClick={() => {
                            setSelectedKBForChat("");
                            localStorage.removeItem("kb_without_bda_kb_name");
                            setShowKBDropdown(false);
                          }}
                          className="w-full rounded bg-gray-100 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200 transition-colors"
                        >
                          Clear Selection
                        </button>
                      </div>
                    )}

                    {/* Manual Input Option */}
                    <div className="border-b border-gray-200 p-3">
                      <label className="mb-1 block text-xs font-semibold text-gray-700">
                        Enter KB Name Manually:
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="e.g., kbtia"
                          className="flex-1 rounded border border-gray-300 px-2 py-1 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              const value = (e.target as HTMLInputElement).value.trim();
                              if (value) {
                                setSelectedKBForChat(value);
                                localStorage.setItem("kb_without_bda_kb_name", value);
                                setShowKBDropdown(false);
                                (e.target as HTMLInputElement).value = "";
                              }
                            }
                          }}
                        />
                        <button
                          onClick={(e) => {
                            const input = e.currentTarget.previousElementSibling as HTMLInputElement;
                            const value = input.value.trim();
                            if (value) {
                              setSelectedKBForChat(value);
                              localStorage.setItem("kb_without_bda_kb_name", value);
                              setShowKBDropdown(false);
                              input.value = "";
                            }
                          }}
                          className="rounded bg-blue-600 px-3 py-1 text-xs font-semibold text-white hover:bg-blue-700"
                        >
                          Set
                        </button>
                      </div>
                    </div>

                    {/* Search Filter */}
                    {availableKBs.length > 0 && (
                      <div className="border-b border-gray-200 p-3">
                        <input
                          type="text"
                          placeholder="Search Knowledge Bases..."
                          value={kbSearchQuery}
                          onChange={(e) => setKbSearchQuery(e.target.value)}
                          className="w-full rounded border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                    )}

                    {/* Available KBs List */}
                    <div className="max-h-48 overflow-y-auto">
                      {availableKBs.length === 0 ? (
                        <div className="px-4 py-3 text-sm text-gray-500 text-center">
                          No Knowledge Bases found from API
                        </div>
                      ) : (
                        availableKBs
                          .filter((kb) =>
                            kb.name.toLowerCase().includes(kbSearchQuery.toLowerCase()) ||
                            kb.id.toLowerCase().includes(kbSearchQuery.toLowerCase())
                          )
                          .map((kb) => (
                            <div
                              key={kb.id}
                              className={`flex items-center justify-between px-4 py-2.5 transition-colors hover:bg-gray-50 ${selectedKBForChat === kb.name
                                ? "bg-green-50"
                                : ""
                                }`}
                            >
                              <button
                                onClick={() => {
                                  setSelectedKBForChat(kb.name);
                                  localStorage.setItem("kb_without_bda_kb_name", kb.name);
                                  setShowKBDropdown(false);
                                  setKbSearchQuery("");
                                }}
                                className="flex-1 text-left"
                              >
                                <div className={`font-medium text-sm ${selectedKBForChat === kb.name
                                  ? "text-green-700 font-semibold"
                                  : "text-gray-700"
                                  }`}>{kb.name}</div>
                                <div className="text-xs text-gray-500 truncate">{kb.id}</div>
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setKbToDelete(kb.name);
                                  setShowDeleteConfirm(true);
                                  setShowKBDropdown(false);
                                  setKbSearchQuery("");
                                }}
                                className="ml-2 rounded p-1.5 text-red-600 hover:bg-red-50 transition-colors"
                                title="Delete KB"
                              >
                                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                              </button>
                            </div>
                          ))
                      )}
                      {availableKBs.length > 0 &&
                        availableKBs.filter((kb) =>
                          kb.name.toLowerCase().includes(kbSearchQuery.toLowerCase()) ||
                          kb.id.toLowerCase().includes(kbSearchQuery.toLowerCase())
                        ).length === 0 && (
                          <div className="px-4 py-3 text-sm text-gray-500 text-center">
                            No matching Knowledge Bases found
                          </div>
                        )}
                    </div>
                  </div>
                )}
              </div>

              <div className="relative" ref={modelDropdownRef}>
                <button
                  onClick={() => setShowModelDropdown(!showModelDropdown)}
                  className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                >
                  <svg
                    className="h-4 w-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                    />
                  </svg>
                  {MODEL_NAMES[selectedModel]}
                  <svg
                    className="h-4 w-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>

                {showModelDropdown && (
                  <div className="absolute right-0 top-full z-10 mt-2 w-64 rounded-lg border border-gray-200 bg-white shadow-lg">
                    {Object.entries(MODEL_NAMES).map(([value, name]) => (
                      <button
                        key={value}
                        onClick={() => {
                          setSelectedModel(value as LLMModel);
                          setShowModelDropdown(false);
                        }}
                        className={`w-full px-4 py-2.5 text-left text-sm transition-colors hover:bg-gray-50 ${selectedModel === value
                          ? "bg-blue-50 font-semibold text-blue-700"
                          : "text-gray-700"
                          }`}
                      >
                        {name}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <button
                onClick={() => {
                  setMessages([]);
                  localStorage.removeItem("kb_without_bda_messages");
                }}
                className="rounded-lg border border-gray-300 bg-white px-4 py-1.5 font-[family-name:var(--font-outfit)] text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
              >
                New Chat
              </button>

              <button
                onClick={handleLogout}
                className="rounded-lg border border-red-300 bg-white px-4 py-1.5 font-[family-name:var(--font-outfit)] text-sm font-medium text-red-600 transition-colors hover:bg-red-50"
              >
                Logout
              </button>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-3xl px-4 py-8">
            {messages.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center text-center">
                <div className="mb-8 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400">
                  <svg
                    className="h-8 w-8 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                    />
                  </svg>
                </div>
                <h2 className="mb-2 font-[family-name:var(--font-outfit)] text-2xl font-bold text-gray-900">
                  How can I help you today?
                </h2>
                <p className="text-sm text-gray-500">
                  Ask me anything about your documents
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-4 ${message.role === "user" ? "justify-end" : "justify-start"
                      }`}
                  >
                    {message.role === "assistant" && (
                      <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400">
                        <svg
                          className="h-5 w-5 text-white"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                          />
                        </svg>
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-3 ${message.role === "user"
                        ? "bg-blue-600 text-white"
                        : "bg-gray-100 text-gray-900"
                        }`}
                    >
                      {message.role === "user" ? (
                        <p className="whitespace-pre-wrap text-sm leading-relaxed">
                          {message.content}
                        </p>
                      ) : message.content === "" && message.isStreaming ? (
                        <div className="flex items-center gap-1 py-1">
                          <div
                            className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                            style={{ animationDelay: "0ms" }}
                          />
                          <div
                            className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                            style={{ animationDelay: "150ms" }}
                          />
                          <div
                            className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                            style={{ animationDelay: "300ms" }}
                          />
                        </div>
                      ) : (
                        <div className="text-sm leading-relaxed">
                          <MarkdownMessage content={message.content} />
                          {message.isStreaming && (
                            <span className="ml-0.5 inline-block h-4 w-[2px] animate-blink-cursor bg-gray-900" />
                          )}
                        </div>
                      )}
                    </div>
                    {message.role === "user" && (
                      <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-gray-800">
                        <svg
                          className="h-5 w-5 text-white"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                          />
                        </svg>
                      </div>
                    )}
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-gray-200 bg-white">
          <div className="mx-auto max-w-3xl px-4 py-4">
            <form onSubmit={handleSubmit} className="relative">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask me anything about your documents..."
                rows={1}
                className="w-full resize-none rounded-2xl border border-gray-300 bg-white px-4 py-3 pr-14 text-sm text-gray-900 placeholder-gray-400 transition-all focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                style={{ minHeight: "52px", maxHeight: "200px" }}
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="absolute bottom-3 right-3 flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white shadow-md transition-all hover:bg-blue-700 hover:shadow-lg hover:scale-105 active:scale-95 disabled:cursor-not-allowed disabled:bg-gray-300 disabled:shadow-none"
              >
                {isLoading ? (
                  <svg
                    className="h-4 w-4 animate-spin"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                ) : (
                  <svg
                    className="h-5 w-5"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
                  </svg>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Delete Knowledge Base</h3>
            <p className="text-sm text-gray-600 mb-4">
              Are you sure you want to delete <span className="font-semibold">{kbToDelete}</span>?
              This will also delete all associated data sources. This action cannot be undone.
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setKbToDelete("");
                }}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteKB}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 disabled:opacity-50"
              >
                {isDeleting ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
