"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Image from "next/image";
import { Inter, Outfit } from "next/font/google";

const inter = Inter({ subsets: ["latin"] });
const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit" });

import { useSession } from "@/app/context/SessionContext";

export default function ChatPage() {
  const router = useRouter();
  const { user, logout } = useSession();

  const handleLogout = () => {
    logout();
  };

  const navigateTo = (path: string) => {
    router.push(path);
  };

  return (
    <div className={`${inter.className} ${outfit.variable} flex h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50`}>
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-3">
              <Image
                src="/logo.svg"
                alt="RAG Accelerator"
                width={140}
                height={36}
                className="h-8 w-auto"
              />
            </div>

            <div className="flex items-center gap-3">
              {user && (
                <div className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white text-sm font-semibold">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-sm font-medium text-gray-700">{user.username}</span>
                </div>
              )}

              <button
                onClick={handleLogout}
                className="rounded-lg border border-red-300 bg-white px-4 py-2 font-[family-name:var(--font-outfit)] text-sm font-medium text-red-600 transition-colors hover:bg-red-50"
              >
                Logout
              </button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-6xl w-full">
            <div className="text-center mb-12">
              <h1 className="font-[family-name:var(--font-outfit)] text-4xl font-bold text-gray-900 mb-4">
                Choose Your Workflow
              </h1>
              <p className="text-lg text-gray-600">
                Select the option that best fits your needs
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* RAG Pipeline Card */}
              <div
                onClick={() => navigateTo("/chat/rag-pipeline")}
                className="group cursor-pointer bg-white rounded-2xl border-2 border-gray-200 p-8 transition-all hover:border-blue-500 hover:shadow-xl hover:-translate-y-1"
              >
                <div className="flex flex-col items-center text-center">
                  <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 group-hover:scale-110 transition-transform">
                    <svg
                      className="h-8 w-8 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                      />
                    </svg>
                  </div>
                  <h3 className="font-[family-name:var(--font-outfit)] text-xl font-bold text-gray-900 mb-3">
                    RAG Pipeline
                  </h3>
                  <p className="text-sm text-gray-600 mb-6">
                    Upload documents, process them, and chat with your data using vector databases
                  </p>
                  <div className="mt-auto">
                    <span className="inline-flex items-center text-sm font-semibold text-blue-600 group-hover:gap-2 transition-all">
                      Get Started
                      <svg
                        className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </span>
                  </div>
                </div>
              </div>

              {/* Knowledge Base with BDA Card */}
              <div
                onClick={() => navigateTo("/chat/kb-with-bda")}
                className="group cursor-pointer bg-white rounded-2xl border-2 border-gray-200 p-8 transition-all hover:border-purple-500 hover:shadow-xl hover:-translate-y-1"
              >
                <div className="flex flex-col items-center text-center">
                  <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-500 to-pink-400 group-hover:scale-110 transition-transform">
                    <svg
                      className="h-8 w-8 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
                      />
                    </svg>
                  </div>
                  <h3 className="font-[family-name:var(--font-outfit)] text-xl font-bold text-gray-900 mb-3">
                    Knowledge Base with BDA
                  </h3>
                  <p className="text-sm text-gray-600 mb-6">
                    Create and manage AWS Bedrock Knowledge Bases with advanced data analysis
                  </p>
                  <div className="mt-auto">
                    <span className="inline-flex items-center text-sm font-semibold text-purple-600 group-hover:gap-2 transition-all">
                      Get Started
                      <svg
                        className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </span>
                  </div>
                </div>
              </div>

              {/* Knowledge Base without BDA Card */}
              <div
                onClick={() => navigateTo("/chat/kb-without-bda")}
                className="group cursor-pointer bg-white rounded-2xl border-2 border-gray-200 p-8 transition-all hover:border-green-500 hover:shadow-xl hover:-translate-y-1"
              >
                <div className="flex flex-col items-center text-center">
                  <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-green-500 to-emerald-400 group-hover:scale-110 transition-transform">
                    <svg
                      className="h-8 w-8 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z"
                      />
                    </svg>
                  </div>
                  <h3 className="font-[family-name:var(--font-outfit)] text-xl font-bold text-gray-900 mb-3">
                    Knowledge Base without BDA
                  </h3>
                  <p className="text-sm text-gray-600 mb-6">
                    Simple knowledge base setup without Bedrock Data Automation features
                  </p>
                  <div className="mt-auto">
                    <span className="inline-flex items-center text-sm font-semibold text-green-600 group-hover:gap-2 transition-all">
                      Get Started
                      <svg
                        className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
