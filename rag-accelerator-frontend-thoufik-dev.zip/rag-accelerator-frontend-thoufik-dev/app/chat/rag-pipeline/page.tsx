"use client";

import { useState, useRef, useEffect } from "react";
import { flushSync } from "react-dom";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Inter, Outfit } from "next/font/google";
import MarkdownMessage from "../components/MarkdownMessage";
import { useSession } from "@/app/context/SessionContext";

const inter = Inter({ subsets: ["latin"] });
const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit" });

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
  isWaiting?: boolean; // ← true while waiting for first token → shows typing dots
}

type VectorDB = "opensearch" | "pgvector" | "s3vectors";
type LLMModel =
  | "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
  | "us.anthropic.claude-3-5-sonnet-20241022-v2:0"
  | "us.anthropic.claude-3-5-haiku-20241022-v1:0"
  | "us.anthropic.claude-3-sonnet-20240229-v1:0"
  | "us.anthropic.claude-3-haiku-20240307-v1:0";

const MODEL_NAMES: Record<LLMModel, string> = {
  "us.anthropic.claude-3-7-sonnet-20250219-v1:0": "Claude 3.7 Sonnet",
  "us.anthropic.claude-3-5-sonnet-20241022-v2:0": "Claude 3.5 Sonnet",
  "us.anthropic.claude-3-5-haiku-20241022-v1:0": "Claude 3.5 Haiku",
  "us.anthropic.claude-3-sonnet-20240229-v1:0": "Claude 3 Sonnet",
  "us.anthropic.claude-3-haiku-20240307-v1:0": "Claude 3 Haiku",
};

// ── Typing Indicator ───────────────────────────────────────────────────────
function TypingIndicator() {
  return (
    <div className="flex items-center gap-1 py-1 px-1">
      {[0, 200, 400].map((delay) => (
        <div
          key={delay}
          className="h-2 w-2 rounded-full bg-gray-400 animate-bounce"
          style={{ animationDelay: `${delay}ms`, animationDuration: "1s" }}
        />
      ))}
    </div>
  );
}

export default function RAGPipelinePage() {
  const router = useRouter();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [selectedModel, setSelectedModel] = useState<LLMModel>("us.anthropic.claude-3-7-sonnet-20250219-v1:0");
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const { user, token, logout } = useSession();

  // Dropdown ref
  const modelDropdownRef = useRef<HTMLDivElement>(null);

  // Handle click outside to close dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (modelDropdownRef.current && !modelDropdownRef.current.contains(event.target as Node)) {
        setShowModelDropdown(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // ── Streaming ref ─────────────────────────────────────────────────────────
  const streamingIdRef = useRef<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem("rag_pipeline_messages");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setMessages(parsed.map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) })));
      } catch (e) { console.error("Failed to load messages:", e); }
    }
  }, []);

  useEffect(() => {
    if (messages.length > 0)
      localStorage.setItem("rag_pipeline_messages", JSON.stringify(messages));
  }, [messages]);

  // Ingest state
  const [vectorDB, setVectorDB] = useState<VectorDB>("opensearch");
  const [s3FolderName, setS3FolderName] = useState("");
  const [indexName, setIndexName] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isIngesting, setIsIngesting] = useState(false);
  const [ingestStatus, setIngestStatus] = useState("");

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const handleLogout = () => {
    logout();
  };

  const handleIngest = async () => {
    if (!selectedFiles.length || !s3FolderName.trim() || !indexName.trim()) {
      setIngestStatus("Please select files, provide a folder name, and index name");
      return;
    }
    setIsIngesting(true);
    setIngestStatus("Uploading and processing documents...");
    try {
      const formData = new FormData();
      formData.append("vector_db", vectorDB);
      formData.append("s3_folder_name", s3FolderName);
      formData.append("index_name", indexName);
      selectedFiles.forEach((f) => formData.append("files", f));
      const res = await fetch("http://localhost:8000/ingest", {
        method: "POST", headers: { Authorization: `Bearer ${token}` }, body: formData,
      });
      if (!res.ok) throw new Error("Ingestion failed");
      const result = await res.json();
      setIngestStatus(`✓ Success! Processed ${result.files_processed} files, created ${result.chunks_created} chunks`);
      setSelectedFiles([]); setS3FolderName(""); setIndexName("");
      if (fileInputRef.current) fileInputRef.current.value = "";
    } catch { setIngestStatus("✗ Error: Failed to ingest documents"); }
    finally { setIsIngesting(false); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { id: Date.now().toString(), role: "user", content: input, timestamp: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    const asstId = (Date.now() + 1).toString();
    streamingIdRef.current = asstId;

    // ── Assistant placeholder with isWaiting=true → typing dots show ────────
    setMessages((prev) => [...prev, {
      id: asstId, role: "assistant", content: "",
      timestamp: new Date(), isStreaming: true, isWaiting: true,
    }]);

    try {
      const formData = new FormData();
      formData.append("query", userMsg.content);
      formData.append("llm_model", selectedModel);
      if (indexName.trim()) formData.append("index_name", indexName.trim().toLowerCase());

      const response = await fetch("http://localhost:8000/query", {
        method: "POST", headers: { Authorization: `Bearer ${token}` }, body: formData,
      });

      if (!response.ok) {
        setMessages((prev) => prev.map((m) =>
          m.id === asstId
            ? { ...m, content: `Failed to get response: ${response.status}`, isStreaming: false, isWaiting: false }
            : m
        ));
        return;
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      let accumulated = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (value) buf += decoder.decode(value, { stream: !done });
          if (done) buf += decoder.decode();

          const lines = buf.split("\n");
          buf = done ? "" : lines.pop() || "";

          for (const line of lines) {
            if (!line.trim().startsWith("data: ")) continue;
            try {
              const jsonStr = line.trim().slice(6);
              if (!jsonStr || jsonStr === "[DONE]") continue;
              const data = JSON.parse(jsonStr);

              // Support both formats:
              //   { event: "token", text: "..." }  (event-based)
              //   { text: "..." }                  (simple, no event field)
              const hasText = 'text' in data && data.event !== "metadata";
              const isDone = data.event === "done" || data.event === "messageStop";
              const isError = data.event === "error" || !!data.error;

              if (hasText && !isDone && !isError) {
                const textChunk = data.text || "";
                accumulated += textChunk;
                const snapshot = accumulated;
                console.log(`[Stream] Received chunk: "${textChunk}" | Total len: ${snapshot.length}`);

                flushSync(() => {
                  setMessages((prev) => prev.map((m) =>
                    m.id === asstId
                      ? { ...m, content: snapshot, isStreaming: true, isWaiting: false }
                      : m
                  ));
                });

                // Yield to the browser paint thread.
                // If the backend or proxy bursts multiple tokens in a single network chunk,
                // this ensures the UI actually animates the stream instead of freezing and rendering it all at once.
                await new Promise(resolve => setTimeout(resolve, 15));
              } else if (isDone) {
                const finalText = data.full_text || accumulated;
                setMessages((prev) => prev.map((m) =>
                  m.id === asstId
                    ? { ...m, content: finalText, isStreaming: false, isWaiting: false }
                    : m
                ));

              } else if (isError) {
                setMessages((prev) => prev.map((m) =>
                  m.id === asstId
                    ? { ...m, content: data.detail || data.error || "An error occurred", isStreaming: false, isWaiting: false }
                    : m
                ));
                return;
              }
            } catch (e: any) {
              if (e.message !== "Unexpected end of JSON input") console.error("Parse error:", e);
            }
          }

          if (done) {
            setMessages((prev) => prev.map((m) =>
              m.id === asstId ? { ...m, isStreaming: false, isWaiting: false } : m
            ));
            break;
          }
        }
      }
    } catch (err: any) {
      setMessages((prev) => prev.map((m) =>
        m.id === asstId
          ? { ...m, content: err.message || "Sorry, I encountered an error. Please try again.", isStreaming: false, isWaiting: false }
          : m
      ));
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSubmit(e as any); }
  };

  return (
    <div className={`${inter.className} ${outfit.variable} flex h-screen bg-white overflow-hidden`}>

      {/* ── Sidebar ── */}
      <aside className={`${sidebarOpen ? "w-80" : "w-0"} flex-shrink-0 border-r border-gray-200 bg-gray-50 transition-all duration-300 ease-in-out overflow-hidden`}>
        <div className="flex h-full w-80 flex-col p-4">
          <div className="mb-6"><h2 className="font-[family-name:var(--font-outfit)] text-lg font-bold text-gray-900">RAG Pipline</h2></div>
          <div className="flex-1 space-y-4 overflow-y-auto">
            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">Vector Database</label>
              <select value={vectorDB} onChange={(e) => setVectorDB(e.target.value as VectorDB)} className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20">
                <option value="opensearch">OpenSearch</option>
                <option value="pgvector">PGVector</option>
                <option value="s3vectors">S3 Vectors</option>
              </select>
            </div>
            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">Index Name</label>
              <input type="text" value={indexName} onChange={(e) => setIndexName(e.target.value)} placeholder="e.g., my-index" className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
            </div>
            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">Folder Name</label>
              <input type="text" value={s3FolderName} onChange={(e) => setS3FolderName(e.target.value)} placeholder="e.g., project-docs" className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
            </div>
            <div>
              <label className="mb-2 block text-xs font-semibold text-gray-700">Upload Documents</label>
              <input ref={fileInputRef} type="file" multiple
                onChange={(e) => { if (e.target.files) { setSelectedFiles((p) => [...p, ...Array.from(e.target.files!)]); if (fileInputRef.current) fileInputRef.current.value = ""; } }}
                className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm file:mr-4 file:rounded-md file:border-0 file:bg-blue-50 file:px-4 file:py-1 file:text-sm file:font-semibold file:text-blue-700 hover:file:bg-blue-100"
              />
              {selectedFiles.length > 0 && (
                <div className="mt-2 space-y-1">
                  <p className="text-xs font-semibold text-gray-700">{selectedFiles.length} file(s) selected:</p>
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {selectedFiles.map((file, i) => (
                      <div key={i} className="flex items-center justify-between rounded bg-gray-50 px-2 py-1">
                        <span className="text-xs text-gray-600 truncate flex-1">{file.name}</span>
                        <button onClick={() => setSelectedFiles((p) => p.filter((_, idx) => idx !== i))} className="ml-2 text-red-500 hover:text-red-700 text-xs font-semibold">✕</button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <button onClick={handleIngest} disabled={isIngesting || !selectedFiles.length || !s3FolderName.trim() || !indexName.trim()} className="w-full rounded-lg bg-blue-600 px-4 py-2.5 font-[family-name:var(--font-outfit)] text-sm font-semibold text-white transition-colors hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50">
              {isIngesting ? "Processing..." : "Ingest Documents"}
            </button>
            {ingestStatus && (
              <div className={`rounded-lg p-3 text-xs ${ingestStatus.startsWith("✓") ? "bg-green-50 text-green-700" : ingestStatus.startsWith("✗") ? "bg-red-50 text-red-700" : "bg-blue-50 text-blue-700"}`}>{ingestStatus}</div>
            )}
            <div className="rounded-lg bg-white p-3">
              <h3 className="mb-2 text-xs font-semibold text-gray-700">Supported Formats</h3>
              <p className="text-xs leading-relaxed text-gray-500">PDF, DOCX, XLSX, CSV, PPTX, HTML, JSON, XML, TXT, MD, Images (OCR), and more</p>
            </div>
          </div>
        </div>
      </aside>

      {/* ── Main ── */}
      <div className="flex flex-1 flex-col min-w-0">

        {/* Header */}
        <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(!sidebarOpen)} className="rounded-lg p-2 text-gray-600 transition-all hover:bg-gray-100 active:scale-95">
                <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  {sidebarOpen
                    ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
                    : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
                </svg>
              </button>
            </div>

            <div className="flex items-center gap-3">
              {user && (
                <div className="hidden sm:flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-600 text-white text-xs font-semibold">{user.username.charAt(0).toUpperCase()}</div>
                  <span className="text-sm font-medium text-gray-700">{user.username}</span>
                </div>
              )}
              <div className="relative" ref={modelDropdownRef}>
                <button onClick={() => setShowModelDropdown(!showModelDropdown)} className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50">
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                  {MODEL_NAMES[selectedModel]}
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                </button>
                {showModelDropdown && (
                  <div className="absolute right-0 top-full z-10 mt-2 w-64 rounded-lg border border-gray-200 bg-white shadow-lg">
                    {Object.entries(MODEL_NAMES).map(([val, name]) => (
                      <button key={val} onClick={() => { setSelectedModel(val as LLMModel); setShowModelDropdown(false); }}
                        className={`w-full px-4 py-2.5 text-left text-sm transition-colors hover:bg-gray-50 ${selectedModel === val ? "bg-blue-50 font-semibold text-blue-700" : "text-gray-700"}`}>
                        {name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <button onClick={() => { setMessages([]); localStorage.removeItem("rag_pipeline_messages"); }} className="rounded-lg border border-gray-300 bg-white px-4 py-1.5 font-[family-name:var(--font-outfit)] text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50">New Chat</button>
              <button onClick={handleLogout} className="rounded-lg border border-red-300 bg-white px-4 py-1.5 font-[family-name:var(--font-outfit)] text-sm font-medium text-red-600 transition-colors hover:bg-red-50">Logout</button>
            </div>
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-3xl px-4 py-8">
            {messages.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center text-center">
                <div className="mb-8 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400">
                  <svg className="h-8 w-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
                </div>
                <h2 className="mb-2 font-[family-name:var(--font-outfit)] text-2xl font-bold text-gray-900">How can I help you today?</h2>
                <p className="text-sm text-gray-500">Ask me anything about your documents</p>
              </div>
            ) : (
              <div className="space-y-6">
                {messages.map((message) => (
                  <div key={message.id} className={`flex gap-4 ${message.role === "user" ? "justify-end" : "justify-start"}`}>

                    {message.role === "assistant" && (
                      <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400">
                        <svg className="h-5 w-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                      </div>
                    )}

                    <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${message.role === "user" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-900"}`}>
                      {message.role === "user" ? (
                        <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</p>

                      ) : message.isWaiting ? (
                        // ── Phase 1: waiting for first token → bouncing dots ──
                        <TypingIndicator />
                      ) : (
                        // ── Phase 2: streaming content ──────
                        <div className="text-sm leading-relaxed">
                          <MarkdownMessage content={message.content} />
                          {message.isStreaming && (
                            <div className="mt-2 inline-block"><TypingIndicator /></div>
                          )}
                        </div>
                      )}
                    </div>

                    {message.role === "user" && (
                      <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-gray-800">
                        <svg className="h-5 w-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                      </div>
                    )}
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>
        </div>

        {/* Input */}
        <div className="border-t border-gray-200 bg-white">
          <div className="mx-auto max-w-3xl px-4 py-4">
            <form onSubmit={handleSubmit} className="relative">
              <textarea ref={textareaRef} value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={handleKeyDown}
                placeholder="Ask me anything about your documents..." rows={1}
                className="w-full resize-none rounded-2xl border border-gray-300 bg-white px-4 py-3 pr-14 text-sm text-gray-900 placeholder-gray-400 transition-all focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                style={{ minHeight: "52px", maxHeight: "200px" }}
              />
              <button type="submit" disabled={!input.trim() || isLoading}
                className="absolute bottom-3 right-3 flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white shadow-md transition-all hover:bg-blue-700 hover:shadow-lg hover:scale-105 active:scale-95 disabled:cursor-not-allowed disabled:bg-gray-300 disabled:shadow-none">
                {isLoading ? (
                  <svg className="h-4 w-4 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                ) : (
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" /></svg>
                )}
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  );
}