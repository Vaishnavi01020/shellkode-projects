import React from 'react';

interface MarkdownMessageProps {
  content: string;
}

export default function MarkdownMessage({ content }: MarkdownMessageProps) {
  if (!content || content.trim() === '') {
    return null;
  }

  // Simple markdown parser for common patterns
  const parseMarkdown = (text: string) => {
    const lines = text.split('\n');
    const elements: React.ReactNode[] = [];
    let inCodeBlock = false;
    let codeBlockContent: string[] = [];
    let codeBlockLang = '';
    let listItems: React.ReactNode[] = [];
    let listType: 'ul' | 'ol' | null = null;

    const flushList = () => {
      if (listItems.length > 0) {
        const ListTag = listType === 'ol' ? 'ol' : 'ul';
        elements.push(
          <ListTag key={`list-${elements.length}`} className="my-2 ml-4 space-y-1">
            {listItems}
          </ListTag>
        );
        listItems = [];
        listType = null;
      }
    };

    lines.forEach((line, index) => {
      // Code blocks
      if (line.startsWith('```')) {
        flushList();
        if (inCodeBlock) {
          // End code block
          elements.push(
            <pre key={`code-${index}`} className="my-3 overflow-x-auto rounded-lg bg-gray-900 p-4">
              <code className="text-sm text-gray-100">{codeBlockContent.join('\n')}</code>
            </pre>
          );
          codeBlockContent = [];
          inCodeBlock = false;
        } else {
          // Start code block
          codeBlockLang = line.slice(3).trim();
          inCodeBlock = true;
        }
        return;
      }

      if (inCodeBlock) {
        codeBlockContent.push(line);
        return;
      }

      // Headers - only if complete (not just ##)
      if (line.match(/^###\s+.+/)) {
        flushList();
        elements.push(
          <h3 key={index} className="mt-4 mb-2 text-base font-bold text-gray-900">
            {line.slice(4)}
          </h3>
        );
        return;
      }
      if (line.match(/^##\s+.+/)) {
        flushList();
        elements.push(
          <h2 key={index} className="mt-4 mb-2 text-lg font-bold text-gray-900">
            {line.slice(3)}
          </h2>
        );
        return;
      }
      if (line.match(/^#\s+.+/)) {
        flushList();
        elements.push(
          <h1 key={index} className="mt-4 mb-2 text-xl font-bold text-gray-900">
            {line.slice(2)}
          </h1>
        );
        return;
      }

      // Lists - bullet
      if (line.match(/^[\*\-]\s+.+/)) {
        if (listType !== 'ul') {
          flushList();
          listType = 'ul';
        }
        listItems.push(
          <li key={index} className="list-disc">
            {parseInlineMarkdown(line.slice(2))}
          </li>
        );
        return;
      }

      // Lists - numbered
      if (line.match(/^\d+\.\s+.+/)) {
        if (listType !== 'ol') {
          flushList();
          listType = 'ol';
        }
        listItems.push(
          <li key={index} className="list-decimal">
            {parseInlineMarkdown(line.replace(/^\d+\.\s+/, ''))}
          </li>
        );
        return;
      }

      // If we have a non-list line, flush any pending list
      if (listType) {
        flushList();
      }

      // Blockquotes
      if (line.startsWith('> ')) {
        elements.push(
          <blockquote key={index} className="my-2 border-l-4 border-blue-500 pl-4 italic text-gray-700">
            {parseInlineMarkdown(line.slice(2))}
          </blockquote>
        );
        return;
      }

      // Empty lines
      if (line.trim() === '') {
        elements.push(<div key={index} className="h-2" />);
        return;
      }

      // Skip incomplete markdown markers
      if (line.trim().match(/^#{1,3}$/)) {
        return;
      }

      // Regular paragraphs
      elements.push(
        <p key={index} className="my-1">
          {parseInlineMarkdown(line)}
        </p>
      );
    });

    // Flush any remaining list
    flushList();

    return elements;
  };

  const parseInlineMarkdown = (text: string) => {
    const parts: (string | React.ReactNode)[] = [];
    let remaining = text;
    let key = 0;

    // Process in order: code, bold, italic, links
    const patterns: Array<{
      regex: RegExp;
      render: (...args: string[]) => React.ReactNode;
    }> = [
      { regex: /`([^`]+)`/g, render: (match: string) => (
        <code key={`code-${key++}`} className="rounded bg-gray-200 px-1.5 py-0.5 text-sm font-mono text-gray-800">
          {match}
        </code>
      )},
      { regex: /\*\*([^*]+)\*\*/g, render: (match: string) => (
        <strong key={`bold-${key++}`} className="font-bold">
          {match}
        </strong>
      )},
      { regex: /\*([^*]+)\*/g, render: (match: string) => (
        <em key={`italic-${key++}`} className="italic">
          {match}
        </em>
      )},
      { regex: /\[([^\]]+)\]\(([^)]+)\)/g, render: (text: string, url: string) => (
        <a
          key={`link-${key++}`}
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 underline hover:text-blue-800"
        >
          {text}
        </a>
      )},
    ];

    // Simple approach: just replace patterns with React elements
    let result: (string | React.ReactNode)[] = [remaining];
    
    patterns.forEach(({ regex, render }) => {
      const newResult: (string | React.ReactNode)[] = [];
      
      result.forEach(part => {
        if (typeof part === 'string') {
          const matches = [...part.matchAll(regex)];
          if (matches.length === 0) {
            newResult.push(part);
          } else {
            let lastIndex = 0;
            matches.forEach(match => {
              if (match.index! > lastIndex) {
                newResult.push(part.slice(lastIndex, match.index));
              }
              if (match.length === 3) {
                // Link with text and URL
                newResult.push(render(match[1], match[2]));
              } else {
                // Other patterns
                newResult.push(render(match[1]));
              }
              lastIndex = match.index! + match[0].length;
            });
            if (lastIndex < part.length) {
              newResult.push(part.slice(lastIndex));
            }
          }
        } else {
          newResult.push(part);
        }
      });
      
      result = newResult;
    });

    return result;
  };

  return <div className="markdown-content">{parseMarkdown(content)}</div>;
}
