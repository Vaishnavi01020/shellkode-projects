"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { useSession } from "@/app/context/SessionContext";
import { Inter, Outfit } from "next/font/google";

const inter = Inter({ subsets: ["latin"] });
const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit" });

export default function LoginPage() {
  const router = useRouter();
  const { login } = useSession();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const response = await fetch("http://localhost:8000/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Login failed");
      }

      // Use the global Session Context to login
      login(data.session_token, data.user);
    } catch (err: any) {
      setError(err.message || "Login failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`${inter.className} ${outfit.variable} flex min-h-screen bg-[#060D14] text-white selection:bg-cyan-500/30`}>
      {/* ── Left Side: Brand Visual ── */}
      <div className="relative hidden w-1/2 flex-col justify-between overflow-hidden border-r border-white/5 bg-[#0A131F] p-12 lg:flex">
        {/* Dynamic Abstract Background Elements */}
        <div className="absolute -left-1/4 -top-1/4 h-[800px] w-[800px] rounded-full bg-blue-600/10 blur-[120px]" />
        <div className="absolute -bottom-1/4 right-0 h-[600px] w-[600px] rounded-full bg-cyan-400/10 blur-[100px]" />

        <div className="relative z-10">
          <Link href="/">
            <div className="inline-flex items-center gap-3 rounded-2xl bg-white/5 p-3 pr-6 shadow-2xl backdrop-blur-md ring-1 ring-white/10 transition-transform hover:scale-105">
              <div className="flex items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 p-2">
                <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <span className="font-[family-name:var(--font-outfit)] text-xl font-bold tracking-tight text-white">
                RAG Accelerator
              </span>
            </div>
          </Link>
        </div>

        <div className="relative z-10 max-w-md">
          <h1 className="mb-6 font-[family-name:var(--font-outfit)] text-5xl font-medium leading-[1.1] tracking-tight">
            Agentic AI <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
              unleashed.
            </span>
          </h1>
          <p className="text-lg leading-relaxed text-slate-400">
            Transform your enterprise data into actionable decisions. Domain-grade outcomes shipped faster, on time, and completely secure.
          </p>
        </div>

        <div className="relative z-10 text-sm font-medium text-slate-500">
          © {new Date().getFullYear()} AI Labs. All rights reserved.
        </div>
      </div>

      {/* ── Right Side: Form ── */}
      <div className="relative flex w-full flex-col items-center justify-center p-8 sm:p-12 lg:w-1/2">
        {/* Top Right Navigation for Mobile */}
        <div className="absolute right-8 top-8 lg:hidden">
          <Link href="/auth/signup" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">
            Sign up instead →
          </Link>
        </div>

        <div className="w-full max-w-[400px]">
          <div className="mb-10 text-center lg:text-left">
            <h2 className="mb-2 font-[family-name:var(--font-outfit)] text-3xl font-bold tracking-tight text-white">
              Welcome back
            </h2>
            <p className="text-slate-400">
              Enter your credentials to access your workspace.
            </p>
          </div>

          {error && (
            <div className="mb-6 animate-in fade-in slide-in-from-top-2 rounded-xl border border-red-500/20 bg-red-500/10 p-4 text-sm text-red-400">
              <div className="flex items-center gap-2">
                <svg className="h-5 w-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {error}
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="group">
              <label className="mb-2 block text-sm font-medium text-slate-300 transition-colors group-focus-within:text-cyan-400">
                Username
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3.5 pl-11 text-white placeholder-slate-500 outline-none ring-1 ring-transparent transition-all hover:bg-white/10 focus:border-cyan-500/50 focus:bg-white/10 focus:ring-cyan-500/20"
                  placeholder="Enter your username"
                  required
                />
                <div className="pointer-events-none absolute left-0 top-0 flex h-full items-center justify-center pl-4 text-slate-500 transition-colors group-focus-within:text-cyan-400">
                  <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
              </div>
            </div>

            <div className="group">
              <div className="mb-2 flex items-center justify-between">
                <label className="block text-sm font-medium text-slate-300 transition-colors group-focus-within:text-cyan-400">
                  Password
                </label>
                <a href="#" className="text-xs font-semibold text-cyan-400 transition-colors hover:text-cyan-300">
                  Forgot password?
                </a>
              </div>
              <div className="relative">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3.5 pl-11 text-white placeholder-slate-500 outline-none ring-1 ring-transparent transition-all hover:bg-white/10 focus:border-cyan-500/50 focus:bg-white/10 focus:ring-cyan-500/20"
                  placeholder="••••••••"
                  required
                />
                <div className="pointer-events-none absolute left-0 top-0 flex h-full items-center justify-center pl-4 text-slate-500 transition-colors group-focus-within:text-cyan-400">
                  <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="group relative mt-2 w-full overflow-hidden rounded-xl bg-white px-4 py-3.5 font-[family-name:var(--font-outfit)] text-sm font-bold text-slate-900 transition-all hover:bg-slate-100 disabled:cursor-not-allowed disabled:bg-white/50"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="h-5 w-5 animate-spin text-slate-900" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Authenticating...
                </span>
              ) : (
                "Sign In to Workspace"
              )}
            </button>
          </form>

          <p className="hidden mt-10 text-center text-sm font-medium text-slate-400 lg:block">
            Don't have an account?{" "}
            <Link href="/auth/signup" className="text-cyan-400 transition-colors hover:text-cyan-300">
              Create one now
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
